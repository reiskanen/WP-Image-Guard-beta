<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_Heading_Case {
    public static function fix_content_headings($content) {
        $content = (string) $content;

        $content = preg_replace_callback('/(<h([1-6])\b[^>]*>)(.*?)(<\/h\2>)/is', function ($matches) {
            return $matches[1] . self::fix_inline_html($matches[3]) . $matches[4];
        }, $content);

        $content = preg_replace_callback('/(^|\n)(\s{0,3}#{1,6}\s+)([^\n]+)/u', function ($matches) {
            return $matches[1] . $matches[2] . self::sentence_case_heading($matches[3]);
        }, $content);

        return $content;
    }

    public static function fix_plain_headings($text) {
        $text = (string) $text;

        if (preg_match('/<h[1-6]\b/i', $text)) {
            return self::fix_content_headings($text);
        }

        $lines = preg_split('/(\r\n|\r|\n)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        foreach ($lines as $index => $line) {
            if (preg_match('/^\s*$/', $line) || preg_match('/^(\r\n|\r|\n)$/', $line)) {
                continue;
            }

            if (self::looks_like_title_case_heading($line)) {
                $lines[$index] = self::sentence_case_heading($line);
            }
        }

        return implode('', $lines);
    }

    public static function count_title_case_headings($content) {
        $content = (string) $content;
        $count = 0;

        if (preg_match_all('/<h[1-6]\b[^>]*>(.*?)<\/h[1-6]>/is', $content, $matches)) {
            foreach ($matches[1] as $heading_html) {
                $heading_text = trim(wp_strip_all_tags($heading_html));
                if (self::looks_like_title_case_heading($heading_text)) {
                    $count++;
                }
            }
        }

        if (preg_match_all('/(^|\n)\s{0,3}#{1,6}\s+([^\n]+)/u', $content, $markdown_matches)) {
            foreach ($markdown_matches[2] as $heading_text) {
                if (self::looks_like_title_case_heading($heading_text)) {
                    $count++;
                }
            }
        }

        return $count;
    }

    private static function fix_inline_html($html) {
        $parts = preg_split('/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $seen_letter = false;

        foreach ($parts as $index => $part) {
            if (preg_match('/^<[^>]+>$/', $part)) {
                continue;
            }

            $parts[$index] = self::sentence_case_fragment($part, $seen_letter);
        }

        return implode('', $parts);
    }

    private static function sentence_case_heading($heading) {
        $heading = (string) $heading;
        $seen_letter = false;
        return self::sentence_case_fragment($heading, $seen_letter);
    }

    private static function sentence_case_fragment($text, &$seen_letter) {
        return preg_replace_callback('/[\p{L}\p{N}][\p{L}\p{N}\'’._-]*/u', function ($matches) use (&$seen_letter) {
            $word = $matches[0];

            if (self::is_numeric_or_numbered_token($word)) {
                return $word;
            }

            $known_term = self::known_term($word);
            if ($known_term !== '') {
                if (!$seen_letter) {
                    $seen_letter = true;
                }
                return $known_term;
            }

            if (self::should_preserve_word($word)) {
                if (!$seen_letter) {
                    $seen_letter = true;
                }
                return $word;
            }

            $lower = self::lower($word);

            if (!$seen_letter) {
                $seen_letter = true;
                return self::mb_ucfirst($lower);
            }

            return $lower;
        }, $text);
    }

    private static function is_numeric_or_numbered_token($word) {
        return preg_match('/^\d[\d.,:;\)\]_-]*$/u', (string) $word) === 1;
    }

    private static function known_term($word) {
        $word = trim((string) $word);
        if ($word === '') {
            return '';
        }

        $map = self::known_terms_map();
        $key = self::lower(str_replace('.', '', $word));
        if (isset($map[$key])) {
            return $map[$key];
        }

        if (strpos($word, '-') !== false) {
            $parts = explode('-', $word);
            $changed = false;
            foreach ($parts as $index => $part) {
                $part_key = self::lower(str_replace('.', '', $part));
                if (isset($map[$part_key])) {
                    $parts[$index] = $map[$part_key];
                    $changed = true;
                } else {
                    $parts[$index] = self::lower($part);
                }
            }
            if ($changed) {
                return implode('-', $parts);
            }
        }

        return '';
    }

    private static function known_terms_map() {
        $defaults = array(
            'AI', 'API', 'B2B', 'B2C', 'BKT', 'BR', 'BRC', 'CPC', 'CRM', 'CTA', 'CTR', 'DNS', 'EAN', 'EU', 'FAQ', 'GDPR', 'GTIN', 'HTML', 'HTTP', 'HTTPS', 'IP', 'IT', 'JSON', 'KPI', 'PDF', 'PHP', 'ROI', 'RSS', 'SEO', 'SKU', 'SSL', 'TLS', 'UI', 'URL', 'UX', 'VAT', 'XML', 'WordPress', 'WooCommerce', 'ChatGPT', 'OpenAI'
        );
        $map = array();
        foreach ($defaults as $term) {
            $map[self::lower(str_replace('.', '', $term))] = $term;
        }
        if (class_exists('HumanTone_Settings') && method_exists('HumanTone_Settings', 'get_heading_preserve_terms_map')) {
            $custom = HumanTone_Settings::get_heading_preserve_terms_map();
            if (is_array($custom)) {
                foreach ($custom as $key => $term) {
                    $map[self::lower(str_replace('.', '', (string) $key))] = (string) $term;
                }
            }
        }
        return $map;
    }

    private static function should_preserve_word($word) {
        if (self::is_numeric_or_numbered_token($word)) {
            return true;
        }

        if (preg_match('/\d/u', $word)) {
            return true;
        }

        if (preg_match('/^[\p{Lu}]{2,}$/u', $word)) {
            return true;
        }

        if (preg_match('/[\p{Ll}].*[\p{Lu}]|[\p{Lu}].*[\p{Ll}].*[\p{Lu}]/u', $word)) {
            return true;
        }

        return false;
    }

    private static function looks_like_title_case_heading($text) {
        $text = trim(wp_strip_all_tags((string) $text));
        if ($text === '') {
            return false;
        }

        if (self::length($text) > 140) {
            return false;
        }

        if (!preg_match_all('/[\p{L}][\p{L}\'’_-]*/u', $text, $matches)) {
            return false;
        }

        $words = $matches[0];
        if (count($words) < 3) {
            return false;
        }

        $capitalized = 0;
        $eligible = 0;
        foreach ($words as $word) {
            if (self::should_preserve_word($word)) {
                continue;
            }
            $eligible++;
            $first = self::substr($word, 0, 1);
            $rest = self::substr($word, 1);
            if ($first === self::upper($first) && $rest === self::lower($rest)) {
                $capitalized++;
            }
        }

        return $eligible >= 3 && $capitalized >= 3 && ($capitalized / max(1, $eligible)) >= 0.7;
    }

    private static function mb_ucfirst($text) {
        if ($text === '') {
            return $text;
        }
        return self::upper(self::substr($text, 0, 1)) . self::substr($text, 1);
    }

    private static function length($text) {
        return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    }

    private static function substr($text, $start, $length = null) {
        if (function_exists('mb_substr')) {
            return $length === null ? mb_substr($text, $start, null, 'UTF-8') : mb_substr($text, $start, $length, 'UTF-8');
        }
        return $length === null ? substr($text, $start) : substr($text, $start, $length);
    }

    private static function lower($text) {
        if (function_exists('mb_strtolower')) {
            return mb_strtolower($text, 'UTF-8');
        }
        return strtr(strtolower($text), array('Ä' => 'ä', 'Ö' => 'ö', 'Å' => 'å'));
    }

    private static function upper($text) {
        if (function_exists('mb_strtoupper')) {
            return mb_strtoupper($text, 'UTF-8');
        }
        return strtr(strtoupper($text), array('ä' => 'Ä', 'ö' => 'Ö', 'å' => 'Å'));
    }

}
