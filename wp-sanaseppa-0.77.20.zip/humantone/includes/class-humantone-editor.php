<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_Editor {
    public function __construct() {
        add_action('enqueue_block_editor_assets', array($this, 'enqueue_editor_assets'));
    }

    public function enqueue_editor_assets() {
        if (!HumanTone_Settings::current_user_can_use_ai()) {
            return;
        }

        wp_enqueue_script(
            'humantone-editor',
            HUMANTONE_PLUGIN_URL . 'assets/editor.js',
            array('wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-api-fetch'),
            HUMANTONE_VERSION,
            true
        );

        wp_localize_script('humantone-editor', 'HumanToneEditor', array(
            'profiles' => HumanTone_Settings::get_profile_options(),
            'defaultProfile' => HumanTone_Settings::get_default_profile_id(),
            'apiStatus' => array(
                'blocking' => HumanTone_Settings::is_api_status_blocking(),
                'message' => HumanTone_Settings::get_api_status_notice_message(),
                'settingsUrl' => esc_url_raw(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api')),
            ),
        ));

        wp_enqueue_style(
            'humantone-editor',
            HUMANTONE_PLUGIN_URL . 'assets/editor.css',
            array(),
            HUMANTONE_VERSION
        );
    }
}
