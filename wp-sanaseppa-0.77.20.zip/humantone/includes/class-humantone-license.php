<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_License {
    const OPTION_KEY = 'humantone_license_key';
    const STATUS_OPTION_KEY = 'humantone_license_status';
    const MAX_STALE_DAYS = 30;
    const API_URL_OPTION_KEY = 'humantone_license_api_url';
    const DEFAULT_API_URL = 'https://wpplugi.com/wp-json/wp-sanaseppa-license/v1';
    const GRACE_DAYS = 7;

    public function __construct() {
        add_action('admin_post_humantone_license_save', array($this, 'handle_save'));
        add_action('admin_post_humantone_license_activate', array($this, 'handle_activate'));
        add_action('admin_post_humantone_license_check', array($this, 'handle_check'));
        add_action('admin_post_humantone_license_deactivate', array($this, 'handle_deactivate'));
        add_action('admin_init', array($this, 'maybe_periodic_check'));
    }

    public static function get_key() {
        return trim((string) get_option(self::OPTION_KEY, ''));
    }

    public static function set_key($key) {
        $key = trim(sanitize_text_field($key));
        if ($key === '') {
            delete_option(self::OPTION_KEY);
            self::set_status('missing', 'Lisenssiavainta ei ole asetettu.');
            return;
        }
        update_option(self::OPTION_KEY, $key, false);
        $status = self::get_status();
        if (empty($status['status']) || in_array($status['status'], array('missing', 'invalid', 'deactivated'), true)) {
            self::set_status('saved_local', 'Lisenssiavain on tallennettu. Aktivoi lisenssi, jotta Pro-toiminnot avautuvat.');
        }
    }

    public static function get_api_url() {
        $url = defined('HUMANTONE_LICENSE_API_URL') ? HUMANTONE_LICENSE_API_URL : self::DEFAULT_API_URL;
        $url = esc_url_raw(trim((string) $url));
        if ($url === '') {
            $url = self::DEFAULT_API_URL;
        }
        return untrailingslashit($url);
    }

    public static function set_api_url($url) {
        // Lisenssipalvelimen osoite on kiinteä eikä näy käyttäjälle.
        // Kehityskäyttöön osoitteen voi yliajaa wp-config.php-tiedostossa vakiolla HUMANTONE_LICENSE_API_URL.
        delete_option(self::API_URL_OPTION_KEY);
    }

    public static function get_status() {
        $status = get_option(self::STATUS_OPTION_KEY, array());
        if (!is_array($status)) {
            $status = array();
        }
        $defaults = array(
            'status' => self::get_key() !== '' ? 'saved_local' : 'missing',
            'message' => self::get_key() !== '' ? 'Lisenssiavain on tallennettu paikallisesti.' : 'Lisenssiavainta ei ole asetettu.',
            'checked_at' => '',
            'last_active_at' => '',
            'plan' => '',
            'expires_at' => '',
            'sites_used' => '',
            'sites_allowed' => '',
            'license_signature' => '',
        );
        return array_merge($defaults, $status);
    }

    public static function set_status($status, $message, $extra = array()) {
        $previous = self::get_status();
        $status = sanitize_key($status);
        $checked_at = current_time('mysql');
        $payload = array(
            'status' => $status,
            'message' => sanitize_text_field($message),
            'checked_at' => $checked_at,
            'last_active_at' => isset($previous['last_active_at']) ? sanitize_text_field($previous['last_active_at']) : '',
            'plan' => isset($extra['plan']) ? sanitize_text_field($extra['plan']) : (isset($previous['plan']) ? sanitize_text_field($previous['plan']) : ''),
            'expires_at' => isset($extra['expires_at']) ? sanitize_text_field($extra['expires_at']) : (isset($previous['expires_at']) ? sanitize_text_field($previous['expires_at']) : ''),
            'sites_used' => isset($extra['sites_used']) ? intval($extra['sites_used']) : (isset($previous['sites_used']) ? intval($previous['sites_used']) : ''),
            'sites_allowed' => isset($extra['sites_allowed']) ? intval($extra['sites_allowed']) : (isset($previous['sites_allowed']) ? intval($previous['sites_allowed']) : ''),
            'license_signature' => isset($previous['license_signature']) ? sanitize_text_field($previous['license_signature']) : '',
        );
        if ($status === 'active') {
            $payload['last_active_at'] = $checked_at;
            $payload['license_signature'] = self::build_status_signature($payload);
        }
        if (in_array($status, array('missing', 'invalid', 'disabled', 'expired', 'deactivated', 'site_limit_reached'), true)) {
            $payload['last_active_at'] = '';
            $payload['license_signature'] = '';
        }
        update_option(self::STATUS_OPTION_KEY, $payload, false);
    }

    private static function build_status_signature($status) {
        $key = self::get_key();
        if ($key === '') {
            return '';
        }
        $payload = array(
            'license_key_hash' => hash('sha256', $key),
            'site_url' => home_url('/'),
            'plan' => isset($status['plan']) ? (string) $status['plan'] : '',
            'expires_at' => isset($status['expires_at']) ? (string) $status['expires_at'] : '',
            'sites_allowed' => isset($status['sites_allowed']) ? (string) $status['sites_allowed'] : '',
        );
        return hash_hmac('sha256', wp_json_encode($payload), wp_salt('auth'));
    }

    private static function has_valid_status_signature($status) {
        if (!is_array($status) || empty($status['license_signature'])) {
            return false;
        }
        $expected = self::build_status_signature($status);
        return $expected !== '' && hash_equals($expected, (string) $status['license_signature']);
    }

    private static function is_status_fresh($status) {
        if (empty($status['checked_at'])) {
            return false;
        }
        $checked = strtotime($status['checked_at']);
        return $checked && (time() - $checked) <= (self::MAX_STALE_DAYS * DAY_IN_SECONDS);
    }

    public static function is_active() {
        $status = self::get_status();
        return isset($status['status']) && $status['status'] === 'active' && self::has_valid_status_signature($status) && self::is_status_fresh($status);
    }

    public static function is_grace_period_active() {
        $status = self::get_status();
        if (empty($status['last_active_at']) || !self::has_valid_status_signature($status)) {
            return false;
        }
        $last_active = strtotime($status['last_active_at']);
        return $last_active && (time() - $last_active) <= (self::GRACE_DAYS * DAY_IN_SECONDS);
    }

    public static function is_dev_mode_enabled() {
        return defined('HUMANTONE_ALLOW_PRO_DEV_MODE') && HUMANTONE_ALLOW_PRO_DEV_MODE;
    }

    public static function is_pro_enabled() {
        if (self::is_dev_mode_enabled() || self::is_active()) {
            return true;
        }
        $status = self::get_status();
        return isset($status['status']) && $status['status'] === 'api_error' && self::is_grace_period_active();
    }

    public static function get_mode_label() {
        if (self::is_dev_mode_enabled()) {
            return 'Pro-kehitystila';
        }
        if (self::is_active()) {
            return 'Pro';
        }
        if (self::is_grace_period_active()) {
            return 'Pro-armonaika';
        }
        return 'Free';
    }

    public static function get_status_message() {
        $status = self::get_status();
        $code = isset($status['status']) ? sanitize_key($status['status']) : 'missing';
        $messages = array(
            'missing' => 'Lisenssiavainta ei ole asetettu.',
            'saved_local' => 'Lisenssiavain on tallennettu paikallisesti. Aktivoi lisenssi, jotta Pro-toiminnot avautuvat.',
            'active' => 'Lisenssi on aktiivinen.',
            'invalid' => 'Lisenssi ei ole aktiivinen tai avain on virheellinen.',
            'expired' => 'Lisenssi on vanhentunut. Pro-toiminnot on lukittu, mutta asetukset, historia ja aiemmat sisällöt säilyvät.',
            'disabled' => 'Lisenssi on poistettu käytöstä. Pro-toiminnot on lukittu, mutta asetukset ja aiemmat sisällöt säilyvät.',
            'deactivated' => 'Lisenssin aktivointi on poistettu tältä sivustolta.',
            'site_limit_reached' => 'Lisenssin sivustoraja on täynnä.',
            'not_activated' => 'Lisenssiä ei ole aktivoitu tälle sivustolle.',
            'api_error' => 'Lisenssipalvelimeen ei saatu yhteyttä. Jos lisenssi oli aiemmin aktiivinen, armonaika voi pitää Pro-toiminnot käytössä väliaikaisesti.',
        );
        if (isset($messages[$code])) {
            return $messages[$code];
        }
        return !empty($status['message']) ? sanitize_text_field($status['message']) : 'Lisenssin tila ei ole tiedossa.';
    }

    public static function get_status_code() {
        $status = self::get_status();
        return isset($status['status']) ? sanitize_key($status['status']) : 'missing';
    }

    public static function is_expired() {
        return self::get_status_code() === 'expired';
    }

    public static function get_pro_unavailable_message($feature = '') {
        $code = self::get_status_code();
        if ($code === 'expired') {
            $base = 'Lisenssi on vanhentunut. Pro-toiminnot, kuten tallennus, joukkokäsittely, historia ja WooCommerce-työkalut, ovat pois käytöstä. Asetukset, historia ja aiemmat sisällöt säilyvät.';
        } elseif ($code === 'disabled') {
            $base = 'Lisenssi on poistettu käytöstä. Pro-toiminnot ovat pois käytöstä, mutta asetukset ja aiemmat sisällöt säilyvät.';
        } elseif ($code === 'site_limit_reached') {
            $base = 'Lisenssin sivustoraja on täynnä. Poista aktivointi toiselta sivustolta tai päivitä lisenssi.';
        } elseif ($code === 'api_error' && self::is_grace_period_active()) {
            $base = 'Lisenssipalvelimeen ei saada yhteyttä, mutta aiempi aktiivinen lisenssi pitää Pro-toiminnot tilapäisesti käytössä armonaikana.';
        } else {
            $base = 'Tämä toiminto kuuluu WP Sanaseppä Pro -versioon.';
        }
        if ($feature !== '') {
            return sprintf('%s Toiminto: %s.', $base, $feature);
        }
        return $base;
    }

    public static function pro_error_response($feature = '') {
        return new WP_Error(
            'humantone_pro_required',
            self::get_pro_unavailable_message($feature),
            array('status' => 403, 'mode' => self::get_mode_label(), 'license_status' => self::get_status_code())
        );
    }

    public static function require_pro_feature($feature = '') {
        if (!self::is_pro_enabled()) {
            return self::pro_error_response($feature);
        }
        return true;
    }

    public static function remote_request($endpoint) {
        $key = self::get_key();
        $base_url = self::get_api_url();
        if ($key === '') {
            self::set_status('missing', 'Lisenssiavainta ei ole asetettu.');
            return array('success' => false, 'message' => 'Lisenssiavainta ei ole asetettu.');
        }
        $url = trailingslashit($base_url) . ltrim((string) $endpoint, '/');
        $response = wp_remote_post($url, array(
            'timeout' => 15,
            'headers' => array('Accept' => 'application/json'),
            'body' => array(
                'license_key' => $key,
                'site_url' => home_url('/'),
                'site_hash' => hash('sha256', (string) wp_parse_url(home_url('/'), PHP_URL_HOST)),
                'plugin_version' => defined('HUMANTONE_VERSION') ? HUMANTONE_VERSION : '',
            ),
        ));
        if (is_wp_error($response)) {
            $message = $response->get_error_message();
            self::set_status('api_error', $message);
            return array('success' => false, 'message' => $message);
        }
        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data)) {
            self::set_status('api_error', 'Lisenssipalvelin palautti virheellisen vastauksen.');
            return array('success' => false, 'message' => 'Lisenssipalvelin palautti virheellisen vastauksen.');
        }
        $status = isset($data['status']) ? sanitize_key($data['status']) : (!empty($data['valid']) ? 'active' : 'invalid');
        $message = isset($data['message']) ? sanitize_text_field($data['message']) : ($status === 'active' ? 'Lisenssi on aktiivinen.' : 'Lisenssi ei ole aktiivinen.');
        self::set_status($status, $message, $data);
        return array('success' => $code >= 200 && $code < 300 && in_array($status, array('active', 'deactivated'), true), 'status' => $status, 'message' => $message, 'data' => $data);
    }

    private static function redirect($status = '') {
        $args = array(
            'page' => 'wp-sanaseppa-settings',
            'tab'  => 'license',
        );
        if ($status !== '') {
            $args['humantone_license'] = sanitize_key($status);
        }
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    private static function require_admin() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sinulla ei ole oikeutta hallita lisenssiä.', 'humantone'));
        }
        check_admin_referer('humantone_license_action', 'humantone_license_nonce');
    }

    public function maybe_periodic_check() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }
        $key = self::get_key();
        if ($key === '') {
            return;
        }
        $status = self::get_status();
        $last_checked = !empty($status['checked_at']) ? strtotime($status['checked_at']) : 0;
        if ($last_checked && (time() - $last_checked) < DAY_IN_SECONDS) {
            return;
        }
        if (get_transient('humantone_license_check_lock')) {
            return;
        }
        set_transient('humantone_license_check_lock', 1, HOUR_IN_SECONDS);
        self::remote_request('check');
    }

    public function handle_save() {
        self::require_admin();
        self::set_key(isset($_POST['humantone_license_key']) ? wp_unslash($_POST['humantone_license_key']) : '');
        self::set_api_url('');
        self::redirect('saved');
    }

    public function handle_activate() {
        self::require_admin();
        if (isset($_POST['humantone_license_key'])) {
            self::set_key(wp_unslash($_POST['humantone_license_key']));
        }
        self::set_api_url('');
        $result = self::remote_request('activate');
        self::redirect(!empty($result['success']) ? 'activated' : 'failed');
    }

    public function handle_check() {
        self::require_admin();
        $result = self::remote_request('check');
        self::redirect(!empty($result['success']) ? 'checked' : 'failed');
    }

    public function handle_deactivate() {
        self::require_admin();
        $result = self::remote_request('deactivate');
        if (!empty($result['success'])) {
            self::set_status('deactivated', 'Lisenssin aktivointi poistettiin tältä sivustolta.');
        }
        self::redirect(!empty($result['success']) ? 'deactivated' : 'failed');
    }
}
