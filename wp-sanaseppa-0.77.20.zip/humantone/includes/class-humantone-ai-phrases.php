<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_AI_Phrases {
    public static function get_phrases() {
        return array(
            'nykypäivän digitaalisessa maailmassa',
            'nykypäivän nopeasti muuttuvassa maailmassa',
            'on tärkeää huomata',
            'tässä artikkelissa käsittelemme',
            'tässä oppaassa käsittelemme',
            'sukelletaan aiheeseen',
            'kattava opas',
            'olennainen osa',
            'ei ole vain',
            'vaan myös',
            'lisäksi on syytä huomioida',
            'kaiken kaikkiaan',
            'yhteenvetona voidaan todeta',
            'avaa uusia mahdollisuuksia',
            'vie seuraavalle tasolle',
            'räätälöity ratkaisu',
            'tehokas ja helppokäyttöinen',
            'saumaton käyttökokemus',
            'innovatiivinen ratkaisu',
            'kilpailukykyinen etu',
            'digitaalinen läsnäolo',
            'käyttäjäystävällinen ratkaisu',
            'monipuoliset mahdollisuudet',
            'tänä päivänä',
            'modernissa liiketoimintaympäristössä'
        );
    }

    public static function analyze($content) {
        $content = (string) $content;
        $found = array();

        foreach (self::get_phrases() as $phrase) {
            $count = self::count_phrase($content, $phrase);
            if ($count > 0) {
                $found[] = array(
                    'phrase' => $phrase,
                    'count' => $count,
                );
            }
        }

        usort($found, function ($a, $b) {
            if ($a['count'] === $b['count']) {
                return strcmp($a['phrase'], $b['phrase']);
            }
            return $b['count'] - $a['count'];
        });

        $total = 0;
        foreach ($found as $item) {
            $total += (int) $item['count'];
        }

        return array(
            'total' => $total,
            'items' => array_slice($found, 0, 20),
        );
    }

    public static function count_total($content) {
        $analysis = self::analyze($content);
        return (int) $analysis['total'];
    }

    private static function count_phrase($content, $phrase) {
        $pattern = '/(?<![\p{L}\p{N}])' . preg_quote($phrase, '/') . '(?![\p{L}\p{N}])/iu';
        if (preg_match_all($pattern, $content, $matches)) {
            return count($matches[0]);
        }
        return 0;
    }
}
