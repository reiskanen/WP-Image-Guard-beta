<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_Settings {
    const OPTION_GROUP = 'humantone_settings_group';
    const OPTION_NAME = 'humantone_settings';
    const API_TEST_OPTION_NAME = 'humantone_api_test_status';
    const VERSION_PATCH='0.77.20';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'), 20);
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_settings_assets'));
        add_action('admin_post_humantone_export_settings', array($this, 'export_settings'));
        add_action('admin_post_humantone_import_settings', array($this, 'import_settings'));
        add_action('admin_post_humantone_save_api_settings', array($this, 'save_api_settings'));
        add_action('admin_post_humantone_prune_api_log', array($this, 'prune_api_log'));
    }


    public function prune_api_log() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sinulla ei ole oikeutta siivota API-kutsulokia.', 'humantone'));
        }
        check_admin_referer('humantone_prune_api_log');
        if (class_exists('HumanTone_Costs')) {
            HumanTone_Costs::prune_recent(HumanTone_Costs::DEFAULT_KEEP_CALLS);
        }
        wp_safe_redirect(add_query_arg(array(
            'page' => 'wp-sanaseppa-settings',
            'tab' => 'costs',
            'humantone_api_log_pruned' => '1',
        ), admin_url('admin.php')));
        exit;
    }


    public function enqueue_settings_assets($hook_suffix) {
        if (!in_array($hook_suffix, array('wp-sanaseppa_page_wp-sanaseppa-settings', 'settings_page_humantone', 'wp-sanaseppa_page_humantone'), true)) {
            return;
        }

        wp_enqueue_style(
            'humantone-admin',
            HUMANTONE_PLUGIN_URL . 'assets/admin.css',
            array(),
            HUMANTONE_VERSION
        );
    }

    public static function defaults() {
        return array(
            'api_key' => '',
            'api_source' => 'auto',
            'model' => 'gpt-5.4-mini',
            'access_capability' => 'manage_options',
            'default_profile' => 'default',
            'ai_instructions' => array(
                'global' => '',
                'page' => '',
                'post' => '',
                'product' => '',
            ),
            'heading_preserve_terms' => self::default_heading_preserve_terms_text(),
            'limits' => array(
                'plain_max_chars' => 8000,
                'post_max_chars' => 60000,
                'product_max_chars' => 30000,
                'bulk_max_items' => 10,
                'warn_chars' => 20000,
                'monthly_budget_usd' => 10,
            ),
            'safety' => array(
                'block_structure_loss' => 1,
                'block_thumbnail_loss' => 1,
                'block_excerpt_loss' => 0,
                'block_taxonomy_loss' => 1,
                'block_seo_meta_loss' => 1,
                'block_acf_meta_loss' => 1,
                'block_page_builder_overwrite' => 1,
            ),
            'profiles' => array(
                'default' => array(
                    'id' => 'default',
                    'name' => 'Oletusprofiili',
                    'brand_voice' => 'Selkeä, lämmin ja asiantunteva suomen kieli. Vältä ylisanoja ja liian geneeristä markkinointikieltä.',
                    'audience' => 'Suomenkieliset verkkosivukävijät ja asiakkaat.',
                    'banned_phrases' => 'mullistava, huipputason, seuraavan sukupolven, ainutlaatuinen ratkaisu',
                    'example_text' => '',
                ),
            ),
        );
    }


    public static function default_heading_preserve_terms_text() {
        return implode("\n", array(
            'SEO',
            'SSL',
            'API',
            'URL',
            'SKU',
            'EAN',
            'GDPR',
            'EU',
            'B2B',
            'B2C',
            'WordPress',
            'WooCommerce',
            'ChatGPT',
            'OpenAI',
        ));
    }

    public static function normalize_heading_preserve_terms_text($text) {
        $lines = preg_split('/\R/u', (string) $text);
        $terms = array();
        foreach ($lines as $line) {
            $term = trim(wp_strip_all_tags((string) $line));
            if ($term === '') {
                continue;
            }
            $term = preg_replace('/\s+/u', '', $term);
            if (!preg_match('/^[\p{L}\p{N}._+-]{2,40}$/u', $term)) {
                continue;
            }
            $key = function_exists('mb_strtolower') ? mb_strtolower($term, 'UTF-8') : strtolower($term);
            $terms[$key] = $term;
        }
        if (empty($terms)) {
            return self::default_heading_preserve_terms_text();
        }
        return implode("\n", array_values($terms));
    }

    public static function get_heading_preserve_terms_map() {
        $settings = self::get_settings();
        $text = isset($settings['heading_preserve_terms']) ? $settings['heading_preserve_terms'] : self::default_heading_preserve_terms_text();
        $text = self::normalize_heading_preserve_terms_text($text);
        $map = array();
        foreach (preg_split('/\R/u', $text) as $term) {
            $term = trim((string) $term);
            if ($term === '') {
                continue;
            }
            $key = function_exists('mb_strtolower') ? mb_strtolower($term, 'UTF-8') : strtolower($term);
            $map[$key] = $term;
        }
        return $map;
    }

    public static function get_settings() {
        $saved = get_option(self::OPTION_NAME, array());
        $settings = wp_parse_args(is_array($saved) ? $saved : array(), self::defaults());
        $settings['heading_preserve_terms'] = self::normalize_heading_preserve_terms_text(isset($settings['heading_preserve_terms']) ? $settings['heading_preserve_terms'] : self::default_heading_preserve_terms_text());
        $settings['profiles'] = self::normalize_profiles($settings);
        $settings['limits'] = self::normalize_limits(isset($settings['limits']) ? $settings['limits'] : array());
        $settings['safety'] = self::normalize_safety(isset($settings['safety']) ? $settings['safety'] : array());

        if (empty($settings['default_profile']) || !isset($settings['profiles'][$settings['default_profile']])) {
            $profile_ids = array_keys($settings['profiles']);
            $settings['default_profile'] = reset($profile_ids) ?: 'default';
        }

        return $settings;
    }



    public static function get_api_test_status() {
        $status = get_option(self::API_TEST_OPTION_NAME, array());
        if (!is_array($status)) {
            $status = array();
        }

        $status = wp_parse_args($status, array(
            'status' => 'not_tested',
            'message' => __('API-avainta ei ole vielä testattu.', 'humantone'),
            'model' => '',
            'tested_at' => '',
            'source' => '',
            'error_type' => '',
        ));

        // 0.77.12: older status-card tests could store a stale OpenAI parameter error
        // (max_tokens/max_completion_tokens) even though the diagnostics test now works.
        // Do not keep showing that stale failure on the API and model tab.
        $message = isset($status['message']) ? (string) $status['message'] : '';
        if (preg_match('/Unsupported parameter.*max_|max_tokens|maximum context length/i', $message)) {
            $status['status'] = 'not_tested';
            $status['message'] = __('Yhteystesti pitää suorittaa uudelleen. Vanha testitulos poistettiin, koska se liittyi aiempaan testiparametriin eikä nykyiseen yhteystestiin.', 'humantone');
            $status['error_type'] = '';
        }

        return $status;
    }

    public static function update_api_test_status($status, $message, $model = '', $source = '', $error_type = '') {
        update_option(self::API_TEST_OPTION_NAME, array(
            'status' => sanitize_key($status),
            'message' => sanitize_text_field($message),
            'model' => sanitize_text_field($model),
            'tested_at' => current_time('mysql'),
            'source' => sanitize_text_field($source),
            'error_type' => sanitize_key($error_type),
        ), false);
    }


    public static function add_beta_log($action, $status = 'info', $message = '', $context = array()) {
        $logs = get_option('humantone_beta_log', array());
        if (!is_array($logs)) {
            $logs = array();
        }
        $entry = array(
            'time' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'action' => sanitize_text_field((string) $action),
            'status' => sanitize_key((string) $status),
            'message' => sanitize_text_field((string) $message),
            'context' => array(),
        );
        if (is_array($context)) {
            foreach ($context as $key => $value) {
                if (is_scalar($value)) {
                    $entry['context'][sanitize_key((string) $key)] = sanitize_text_field((string) $value);
                }
            }
        }
        array_unshift($logs, $entry);
        if (count($logs) > 200) {
            $logs = array_slice($logs, 0, 200);
        }
        update_option('humantone_beta_log', $logs, false);
    }

    public static function get_beta_log($limit = 30) {
        $logs = get_option('humantone_beta_log', array());
        if (!is_array($logs)) {
            return array();
        }
        return array_slice($logs, 0, max(1, absint($limit)));
    }

    public static function get_environment_diagnostics() {
        global $wpdb;
        $api_status = self::get_api_test_status();
        $last_job_id = (string) get_option('humantone_last_bulk_job_id', '');
        $jobs = get_option('humantone_bulk_jobs', array());
        $last_job = ($last_job_id && is_array($jobs) && isset($jobs[$last_job_id]) && is_array($jobs[$last_job_id])) ? $jobs[$last_job_id] : array();
        $cron_disabled = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
        $next_cron = $last_job_id ? wp_next_scheduled('humantone_process_bulk_job', array($last_job_id)) : false;
        return array(
            'plugin_version' => defined('HUMANTONE_VERSION') ? HUMANTONE_VERSION : self::VERSION_PATCH,
            'wordpress_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'mysql_version' => isset($wpdb->db_version) ? $wpdb->db_version() : '',
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'wp_debug' => defined('WP_DEBUG') && WP_DEBUG ? 'on' : 'off',
            'wp_cron' => $cron_disabled ? __('DISABLE_WP_CRON on päällä', 'humantone') : __('WP-Cron käytössä', 'humantone'),
            'next_bulk_cron' => $next_cron ? wp_date('Y-m-d H:i:s', $next_cron) : __('Ei ajastettua Sanaseppä-tausta-ajoa', 'humantone'),
            'api_status' => isset($api_status['status']) ? $api_status['status'] : 'not_tested',
            'api_message' => isset($api_status['message']) ? $api_status['message'] : '',
            'api_model' => isset($api_status['model']) ? $api_status['model'] : '',
            'last_job_status' => isset($last_job['status']) ? $last_job['status'] : __('Ei tausta-ajoa', 'humantone'),
            'last_job_progress' => isset($last_job['done'], $last_job['total']) ? absint($last_job['done']) . '/' . absint($last_job['total']) : '-',
            'last_job_updated' => isset($last_job['updated_at']) ? $last_job['updated_at'] : '',
        );
    }



    public static function get_api_status_type($status = null) {
        if ($status === null) {
            $status = self::get_api_test_status();
        }
        $message = isset($status['message']) ? (string) $status['message'] : '';
        $type = isset($status['error_type']) ? sanitize_key($status['error_type']) : '';
        if ($type !== '') {
            return $type;
        }
        if (class_exists('HumanTone_AI_Client')) {
            return HumanTone_AI_Client::classify_openai_error($message);
        }
        return '';
    }

    public static function is_api_status_blocking($status = null) {
        if ($status === null) {
            $status = self::get_api_test_status();
        }
        $state = isset($status['status']) ? sanitize_key($status['status']) : 'not_tested';
        if ($state !== 'fail') {
            return false;
        }
        return in_array(self::get_api_status_type($status), array('quota', 'auth', 'model'), true);
    }

    public static function get_api_status_notice_message($status = null) {
        if ($status === null) {
            $status = self::get_api_test_status();
        }
        $type = self::get_api_status_type($status);
        if ($type === 'quota') {
            return __('OpenAI API -saldo on loppunut tai laskutus ei ole aktiivinen. WP Sanaseppä ei voi käsitellä tekstejä ennen kuin OpenAI Platformin laskutus tai käyttöraja on kunnossa.', 'humantone');
        }
        if ($type === 'auth') {
            return __('OpenAI API -avain ei kelpaa tai sitä ei ole tallennettu oikein. Tarkista API ja malli -välilehti ja tallenna API-asetukset uudelleen.', 'humantone');
        }
        if ($type === 'model') {
            return __('Valittu OpenAI-malli ei ole käytettävissä tällä API-tilillä. Vaihda malli API ja malli -välilehdellä ja testaa yhteys uudelleen.', 'humantone');
        }
        return isset($status['message']) ? (string) $status['message'] : '';
    }


    public function render_api_connection_overview() {
        $settings = self::get_settings();
        $status = self::get_api_test_status();
        $status_key = isset($status['status']) ? sanitize_key($status['status']) : 'not_tested';
        $type = self::get_api_status_type($status);
        $source = isset($settings['api_source']) ? sanitize_key($settings['api_source']) : 'auto';
        $effective_source = $source;
        if ('auto' === $source) {
            $effective_source = (empty($settings['api_key']) && class_exists('HumanTone_AI_Client') && HumanTone_AI_Client::is_openai_provider_available()) ? 'provider' : 'own';
        }
        $source_label = class_exists('HumanTone_AI_Client') ? HumanTone_AI_Client::get_api_source_label($effective_source) : $this->get_api_source_label($effective_source);
        $model = isset($settings['model']) ? (string) $settings['model'] : '';
        $has_key = !empty($settings['api_key']);
        $is_ok = ('ok' === $status_key);
        $is_fail = ('fail' === $status_key);
        $is_blocking = self::is_api_status_blocking($status);
        $card_class = $is_ok ? 'is-ok' : ($is_fail ? 'is-fail' : 'is-not-tested');
        if ($is_blocking) {
            $card_class .= ' is-blocking';
        }
        if ($is_ok) {
            $headline = __('OpenAI-yhteys toimii', 'humantone');
            $lead = __('API-avain, laskutus ja valittu malli on testattu onnistuneesti.', 'humantone');
        } elseif ($is_fail) {
            $headline = __('OpenAI-yhteys ei toimi', 'humantone');
            $lead = self::get_api_status_notice_message($status);
        } else {
            $headline = __('OpenAI-yhteyttä ei ole vielä testattu', 'humantone');
            $lead = __('Tallenna API-asetukset ja paina Testaa yhteys nyt. Testi tarkistaa samalla API-avaimen, laskutuksen ja mallin.', 'humantone');
        }
        ?>
        <div class="humantone-api-overview <?php echo esc_attr($card_class); ?>" id="humantone-api-overview" data-status="<?php echo esc_attr($status_key); ?>" data-error-type="<?php echo esc_attr($type); ?>">
            <div class="humantone-api-overview-main">
                <div class="humantone-api-overview-icon" aria-hidden="true"><?php echo $is_ok ? '✓' : ($is_fail ? '!' : '?'); ?></div>
                <div>
                    <h3><?php echo esc_html($headline); ?></h3>
                    <p class="humantone-api-overview-lead"><?php echo esc_html($lead); ?></p>
                    <dl class="humantone-api-overview-facts">
                        <div><dt><?php echo esc_html__('Käytössä oleva malli', 'humantone'); ?></dt><dd><?php echo esc_html($model !== '' ? $model : __('Ei valittu', 'humantone')); ?></dd></div>
                        <div><dt><?php echo esc_html__('API-lähde', 'humantone'); ?></dt><dd><?php echo esc_html($source_label); ?></dd></div>
                        <div><dt><?php echo esc_html__('Oma API-avain', 'humantone'); ?></dt><dd><?php echo esc_html($has_key ? __('Tallennettu', 'humantone') : __('Ei tallennettu', 'humantone')); ?></dd></div>
                        <div><dt><?php echo esc_html__('Viimeisin testi', 'humantone'); ?></dt><dd><?php echo esc_html(!empty($status['tested_at']) ? $status['tested_at'] : __('Ei vielä testattu', 'humantone')); ?></dd></div>
                    </dl>
                </div>
            </div>
            <div class="humantone-api-overview-actions">
                <button type="button" class="button button-primary" id="humantone-api-overview-test"><?php echo esc_html__('Testaa yhteys nyt', 'humantone'); ?></button>
                <button type="button" class="button button-secondary" id="humantone-api-overview-save"><?php echo esc_html__('Tallenna API-asetukset', 'humantone'); ?></button>
                <a class="button button-secondary" href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('OpenAI Billing', 'humantone'); ?></a>
            </div>
            <?php if ($is_blocking) : ?>
                <div class="humantone-api-overview-warning">
                    <?php echo esc_html__('Käsittely on estetty, kunnes tämä virhe on korjattu ja yhteystesti onnistuu.', 'humantone'); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function get_profiles() {
        $settings = self::get_settings();
        return $settings['profiles'];
    }

    public static function get_profile_options() {
        $profiles = self::get_profiles();
        $options = array();
        foreach ($profiles as $id => $profile) {
            if (!empty($profile['name'])) {
                $options[] = array(
                    'id' => $id,
                    'name' => $profile['name'],
                );
            }
        }
        return $options;
    }

    public static function get_default_profile_id() {
        $settings = self::get_settings();
        return $settings['default_profile'];
    }

    public static function get_limits() {
        $settings = self::get_settings();
        return $settings['limits'];
    }

    public static function get_limit($key) {
        $limits = self::get_limits();
        return isset($limits[$key]) ? (int) $limits[$key] : 0;
    }

    public static function get_safety() {
        $settings = self::get_settings();
        return isset($settings['safety']) && is_array($settings['safety']) ? $settings['safety'] : self::defaults()['safety'];
    }

    public static function get_safety_flag($key) {
        $safety = self::get_safety();
        return !empty($safety[$key]);
    }

    public static function get_access_capability_options() {
        return array(
            'manage_options' => __('Vain ylläpitäjät', 'humantone'),
            'edit_others_posts' => __('Päätoimittajat ja ylläpitäjät', 'humantone'),
            'publish_posts' => __('Kirjoittajat, päätoimittajat ja ylläpitäjät', 'humantone'),
            'edit_posts' => __('Kaikki kirjoitusoikeudelliset käyttäjät', 'humantone'),
        );
    }

    public static function get_access_capability() {
        $settings = self::get_settings();
        $capability = isset($settings['access_capability']) ? sanitize_key($settings['access_capability']) : 'manage_options';
        $allowed = array_keys(self::get_access_capability_options());
        return in_array($capability, $allowed, true) ? $capability : 'manage_options';
    }

    public static function current_user_can_use_ai() {
        return current_user_can(self::get_access_capability());
    }

    public static function get_model_options() {
        return array(
            'gpt-5.4-mini' => __('Oletus: GPT-5.4 mini - hyvä tasapaino laatuun, nopeuteen ja hintaan', 'humantone'),
            'gpt-5.4-nano' => __('Halpa: GPT-5.4 nano - edullisin vaihtoehto kevyisiin tekstikorjauksiin', 'humantone'),
            'gpt-5.4' => __('Parempi laatu: GPT-5.4 - laadukkaampaan sisällön viimeistelyyn', 'humantone'),
            'gpt-5.5' => __('Premium: GPT-5.5 - paras laatu vaativaan käyttöön', 'humantone'),
            'gpt-4.1' => __('Vanhempi hyvä laatu: GPT-4.1 - pidetään mukana yhteensopivuuden vuoksi', 'humantone'),
        );
    }

    private static function normalize_safety($safety) {
        $defaults = self::defaults();
        $default_safety = $defaults['safety'];
        $safety = is_array($safety) ? $safety : array();

        return array(
            'block_structure_loss' => array_key_exists('block_structure_loss', $safety) ? (!empty($safety['block_structure_loss']) ? 1 : 0) : (int) $default_safety['block_structure_loss'],
            'block_thumbnail_loss' => array_key_exists('block_thumbnail_loss', $safety) ? (!empty($safety['block_thumbnail_loss']) ? 1 : 0) : (int) $default_safety['block_thumbnail_loss'],
            'block_excerpt_loss' => array_key_exists('block_excerpt_loss', $safety) ? (!empty($safety['block_excerpt_loss']) ? 1 : 0) : (int) $default_safety['block_excerpt_loss'],
            'block_taxonomy_loss' => array_key_exists('block_taxonomy_loss', $safety) ? (!empty($safety['block_taxonomy_loss']) ? 1 : 0) : (int) $default_safety['block_taxonomy_loss'],
            'block_seo_meta_loss' => array_key_exists('block_seo_meta_loss', $safety) ? (!empty($safety['block_seo_meta_loss']) ? 1 : 0) : (int) $default_safety['block_seo_meta_loss'],
            'block_acf_meta_loss' => array_key_exists('block_acf_meta_loss', $safety) ? (!empty($safety['block_acf_meta_loss']) ? 1 : 0) : (int) $default_safety['block_acf_meta_loss'],
            'block_page_builder_overwrite' => array_key_exists('block_page_builder_overwrite', $safety) ? (!empty($safety['block_page_builder_overwrite']) ? 1 : 0) : (int) $default_safety['block_page_builder_overwrite'],
        );
    }

    private static function normalize_limits($limits) {
        $defaults = self::defaults();
        $default_limits = $defaults['limits'];
        $limits = is_array($limits) ? $limits : array();

        $normalized = array();
        $normalized['plain_max_chars'] = max(1000, min(30000, absint(isset($limits['plain_max_chars']) ? $limits['plain_max_chars'] : $default_limits['plain_max_chars'])));
        $normalized['post_max_chars'] = max(5000, min(150000, absint(isset($limits['post_max_chars']) ? $limits['post_max_chars'] : $default_limits['post_max_chars'])));
        $normalized['product_max_chars'] = max(2000, min(80000, absint(isset($limits['product_max_chars']) ? $limits['product_max_chars'] : $default_limits['product_max_chars'])));
        $normalized['bulk_max_items'] = max(1, min(25, absint(isset($limits['bulk_max_items']) ? $limits['bulk_max_items'] : $default_limits['bulk_max_items'])));
        $normalized['warn_chars'] = max(1000, min(150000, absint(isset($limits['warn_chars']) ? $limits['warn_chars'] : $default_limits['warn_chars'])));
        $normalized['monthly_budget_usd'] = max(0, min(10000, (float) (isset($limits['monthly_budget_usd']) ? str_replace(',', '.', (string) $limits['monthly_budget_usd']) : $default_limits['monthly_budget_usd'])));

        return $normalized;
    }

    public static function get_profile($profile_id = '') {
        $settings = self::get_settings();
        $profile_id = sanitize_key((string) $profile_id);

        if ($profile_id && isset($settings['profiles'][$profile_id])) {
            return $settings['profiles'][$profile_id];
        }

        if (isset($settings['profiles'][$settings['default_profile']])) {
            return $settings['profiles'][$settings['default_profile']];
        }

        $defaults = self::defaults();
        return $defaults['profiles']['default'];
    }

    private static function normalize_profiles($settings) {
        $defaults = self::defaults();
        $profiles = isset($settings['profiles']) && is_array($settings['profiles']) ? $settings['profiles'] : array();

        if (empty($profiles) && (!empty($settings['brand_voice']) || !empty($settings['banned_phrases']))) {
            $profiles['default'] = array(
                'id' => 'default',
                'name' => 'Oletusprofiili',
                'brand_voice' => isset($settings['brand_voice']) ? $settings['brand_voice'] : $defaults['profiles']['default']['brand_voice'],
                'audience' => 'Suomenkieliset verkkosivukävijät ja asiakkaat.',
                'banned_phrases' => isset($settings['banned_phrases']) ? $settings['banned_phrases'] : $defaults['profiles']['default']['banned_phrases'],
                'example_text' => '',
            );
        }

        if (empty($profiles)) {
            $profiles = $defaults['profiles'];
        }

        $normalized = array();
        foreach ($profiles as $key => $profile) {
            if (!is_array($profile)) {
                continue;
            }

            $name = isset($profile['name']) ? trim((string) $profile['name']) : '';
            $voice = isset($profile['brand_voice']) ? trim((string) $profile['brand_voice']) : '';

            if ($name === '' && $voice === '') {
                continue;
            }

            $id = isset($profile['id']) ? sanitize_key($profile['id']) : sanitize_key($key);
            if ($id === '') {
                $id = sanitize_key(sanitize_title($name));
            }
            if ($id === '') {
                $id = 'profile_' . (count($normalized) + 1);
            }

            $base_id = $id;
            $counter = 2;
            while (isset($normalized[$id])) {
                $id = $base_id . '_' . $counter;
                $counter++;
            }

            $normalized[$id] = array(
                'id' => $id,
                'name' => $name !== '' ? $name : sprintf(__('Profiili %d', 'humantone'), count($normalized) + 1),
                'brand_voice' => $voice !== '' ? $voice : $defaults['profiles']['default']['brand_voice'],
                'audience' => isset($profile['audience']) ? trim((string) $profile['audience']) : '',
                'banned_phrases' => isset($profile['banned_phrases']) ? trim((string) $profile['banned_phrases']) : '',
                'example_text' => isset($profile['example_text']) ? trim((string) $profile['example_text']) : '',
            );
        }

        if (empty($normalized)) {
            $normalized = $defaults['profiles'];
        }

        return $normalized;
    }

    public function add_settings_page() {
        add_submenu_page(
            'wp-sanaseppa',
            __('WP Sanaseppä - asetukset', 'humantone'),
            __('Asetukset', 'humantone'),
            'manage_options',
            'wp-sanaseppa-settings',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting(
            self::OPTION_GROUP,
            self::OPTION_NAME,
            array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize_settings'),
                'default' => self::defaults(),
            )
        );

        add_settings_section(
            'humantone_main_section',
            __('Perusasetukset', 'humantone'),
            function () {
                echo '<p>' . esc_html__('Määritä API-avain, malli ja brändiprofiilit. API-avain säilytetään vain WordPressin asetuksissa eikä sitä lähetetä selaimelle.', 'humantone') . '</p>';
            },
            'humantone'
        );

        add_settings_field('api_key', __('OpenAI API -avain', 'humantone'), array($this, 'render_api_key_field'), 'humantone', 'humantone_main_section');
        add_settings_field('model', __('Malli', 'humantone'), array($this, 'render_model_field'), 'humantone', 'humantone_main_section');
        add_settings_field('default_profile', __('Oletusprofiili', 'humantone'), array($this, 'render_default_profile_field'), 'humantone', 'humantone_main_section');
        add_settings_field('profiles', __('Brändiprofiilit', 'humantone'), array($this, 'render_profiles_field'), 'humantone', 'humantone_main_section');
    }

    public function sanitize_settings($input) {
        $defaults = self::defaults();
        $output = array();
        $output['api_key'] = isset($input['api_key']) ? sanitize_text_field($input['api_key']) : '';
        $api_source = isset($input['api_source']) ? sanitize_key($input['api_source']) : $defaults['api_source'];
        $output['api_source'] = in_array($api_source, array('auto', 'provider', 'own'), true) ? $api_source : $defaults['api_source'];

        $access_capability = isset($input['access_capability']) ? sanitize_key($input['access_capability']) : $defaults['access_capability'];
        $allowed_capabilities = array_keys(self::get_access_capability_options());
        $output['access_capability'] = in_array($access_capability, $allowed_capabilities, true) ? $access_capability : $defaults['access_capability'];

        $selected_model = isset($input['model']) ? sanitize_text_field($input['model']) : $defaults['model'];
        $custom_model = isset($input['custom_model']) ? sanitize_text_field($input['custom_model']) : '';
        $model = $custom_model !== '' ? $custom_model : $selected_model;
        if (!preg_match('/^[a-zA-Z0-9_.:-]+$/', $model)) {
            $model = $defaults['model'];
        }
        $output['model'] = $model;

        $output['heading_preserve_terms'] = self::normalize_heading_preserve_terms_text(isset($input['heading_preserve_terms']) ? $input['heading_preserve_terms'] : self::default_heading_preserve_terms_text());

        $output['limits'] = self::normalize_limits(isset($input['limits']) ? $input['limits'] : array());
        $output['safety'] = self::normalize_safety(isset($input['safety']) ? $input['safety'] : array());

        $raw_profiles = isset($input['profiles']) && is_array($input['profiles']) ? $input['profiles'] : array();
        $profiles = array();

        foreach ($raw_profiles as $profile) {
            if (!is_array($profile)) {
                continue;
            }

            $name = isset($profile['name']) ? sanitize_text_field($profile['name']) : '';
            $voice = isset($profile['brand_voice']) ? sanitize_textarea_field($profile['brand_voice']) : '';
            $audience = isset($profile['audience']) ? sanitize_textarea_field($profile['audience']) : '';
            $banned = isset($profile['banned_phrases']) ? sanitize_textarea_field($profile['banned_phrases']) : '';
            $example = isset($profile['example_text']) ? sanitize_textarea_field($profile['example_text']) : '';

            if ($name === '' && $voice === '' && $audience === '' && $banned === '' && $example === '') {
                continue;
            }

            $id = isset($profile['id']) ? sanitize_key($profile['id']) : '';
            if ($id === '') {
                $id = sanitize_key(sanitize_title($name));
            }
            if ($id === '') {
                $id = 'profile_' . (count($profiles) + 1);
            }

            $base_id = $id;
            $counter = 2;
            while (isset($profiles[$id])) {
                $id = $base_id . '_' . $counter;
                $counter++;
            }

            $profiles[$id] = array(
                'id' => $id,
                'name' => $name !== '' ? $name : sprintf(__('Profiili %d', 'humantone'), count($profiles) + 1),
                'brand_voice' => $voice !== '' ? $voice : $defaults['profiles']['default']['brand_voice'],
                'audience' => $audience,
                'banned_phrases' => $banned,
                'example_text' => $example,
            );
        }

        if (empty($profiles)) {
            $profiles = $defaults['profiles'];
        }

        $default_profile = isset($input['default_profile']) ? sanitize_key($input['default_profile']) : '';
        if (!$default_profile || !isset($profiles[$default_profile])) {
            $keys = array_keys($profiles);
            $default_profile = reset($keys);
        }

        $output['default_profile'] = $default_profile;
        $output['profiles'] = $profiles;

        return $output;
    }

    public static function get_export_data() {
        $settings = self::get_settings();

        if (isset($settings['api_key'])) {
            unset($settings['api_key']);
        }

        return array(
            'schema' => 'wp-sanaseppa-settings',
            'version' => 1,
            'plugin_version' => defined('HUMANTONE_VERSION') ? HUMANTONE_VERSION : '',
            'exported_at' => gmdate('c'),
            'settings' => $settings,
        );
    }

    public function export_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sinulla ei ole oikeutta viedä asetuksia.', 'humantone'));
        }

        check_admin_referer('humantone_export_settings');

        $json = wp_json_encode(self::get_export_data(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if (!$json) {
            wp_die(esc_html__('Asetusten vienti epäonnistui.', 'humantone'));
        }

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="wp-sanaseppa-asetukset-' . gmdate('Y-m-d') . '.json"');
        echo $json;
        exit;
    }

    public function import_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sinulla ei ole oikeutta tuoda asetuksia.', 'humantone'));
        }

        check_admin_referer('humantone_import_settings');

        $redirect_url = admin_url('admin.php?page=wp-sanaseppa-settings');
        $raw_json = isset($_POST['humantone_import_json']) ? wp_unslash($_POST['humantone_import_json']) : '';
        $raw_json = trim((string) $raw_json);

        if ($raw_json === '') {
            wp_safe_redirect(add_query_arg('humantone_import', 'empty', $redirect_url));
            exit;
        }

        $decoded = json_decode($raw_json, true);
        if (!is_array($decoded)) {
            wp_safe_redirect(add_query_arg('humantone_import', 'invalid', $redirect_url));
            exit;
        }

        $incoming = isset($decoded['settings']) && is_array($decoded['settings']) ? $decoded['settings'] : $decoded;
        $current = self::get_settings();

        if (empty($incoming['api_key'])) {
            $incoming['api_key'] = isset($current['api_key']) ? $current['api_key'] : '';
        }

        $sanitized = $this->sanitize_settings($incoming);
        update_option(self::OPTION_NAME, $sanitized);

        wp_safe_redirect(add_query_arg('humantone_import', 'success', $redirect_url));
        exit;
    }

    private function render_import_notice() {
        if (empty($_GET['humantone_import'])) {
            return;
        }

        $status = sanitize_key(wp_unslash($_GET['humantone_import']));
        if ($status === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Asetukset tuotiin onnistuneesti. API-avain säilyi ennallaan, jos sitä ei ollut tuontitiedostossa.', 'humantone') . '</p></div>';
        } elseif ($status === 'empty') {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Tuonti epäonnistui: JSON-kenttä oli tyhjä.', 'humantone') . '</p></div>';
        } elseif ($status === 'invalid') {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Tuonti epäonnistui: JSON ei ollut kelvollinen.', 'humantone') . '</p></div>';
        }
    }


    public function render_api_source_field() {
        $settings = self::get_settings();
        $source = isset($settings['api_source']) ? $settings['api_source'] : 'auto';
        $provider_available = class_exists('HumanTone_AI_Client') && HumanTone_AI_Client::is_openai_provider_available();
        $options = array(
            'auto' => __('Automaattinen: käytä konnektoria, jos se löytyy', 'humantone'),
            'provider' => __('AI Provider for OpenAI -konnektori', 'humantone'),
            'own' => __('WP Sanasepän oma API-avain', 'humantone'),
        );

        echo '<select id="humantone-api-source-field" name="' . esc_attr(self::OPTION_NAME) . '[api_source]" class="regular-text" data-provider-available="' . esc_attr($provider_available ? '1' : '0') . '">';
        foreach ($options as $value => $label) {
            $disabled = ($value === 'provider' && !$provider_available) ? ' disabled' : '';
            $option_label = ($value === 'provider' && !$provider_available) ? $label . ' (' . __('ei havaittu', 'humantone') . ')' : $label;
            printf('<option value="%1$s" %2$s%3$s>%4$s</option>', esc_attr($value), selected($source, $value, false), $disabled, esc_html($option_label));
        }
        echo '</select>';
        if ($provider_available) {
            echo '<p class="description">' . esc_html__('AI Provider for OpenAI ja PHP AI Client SDK havaittiin. WP Sanaseppä käyttää konnektorin API-avainta automaattisesti, jos omaa API-avainta ei ole tallennettu tai API-lähde on Automaattinen.', 'humantone') . '</p>';
        } else {
            echo '<p class="description">' . esc_html__('AI Provider for OpenAI -konnektoria ei havaittu käyttövalmiina. Automaattisessa tilassa käytetään WP Sanasepän omaa API-avainkenttää, jos sellainen on tallennettu.', 'humantone') . '</p>';
        }
    }


    public function render_heading_preserve_terms_field() {
        $settings = self::get_settings();
        $value = isset($settings['heading_preserve_terms']) ? $settings['heading_preserve_terms'] : self::default_heading_preserve_terms_text();
        printf(
            '<textarea id="humantone-heading-preserve-terms" name="%1$s[heading_preserve_terms]" rows="10" class="large-text code">%2$s</textarea>',
            esc_attr(self::OPTION_NAME),
            esc_textarea($value)
        );
        echo '<p class="description">' . esc_html__('Esimerkki: seo-vinkit → SEO-vinkit, wordpress-lisäosat → WordPress-lisäosat. Jos lista tyhjennetään, oletussanasto palautuu tallennuksessa.', 'humantone') . '</p>';
        echo '<p><button type="button" class="button" id="humantone-reset-heading-terms">' . esc_html__('Palauta oletussanasto', 'humantone') . '</button></p>';
        echo '<script type="application/json" id="humantone-default-heading-terms">' . wp_json_encode(self::default_heading_preserve_terms_text()) . '</script>';
    }

    public function render_api_key_field() {
        $settings = self::get_settings();
        printf(
            '<input id="humantone-api-key-field" type="password" name="%1$s[api_key]" value="%2$s" class="regular-text" autocomplete="new-password" autocapitalize="off" autocorrect="off" spellcheck="false" data-bwignore="true" data-1p-ignore="true" data-lpignore="true" data-form-type="other" />',
            esc_attr(self::OPTION_NAME),
            esc_attr($settings['api_key'])
        );
        echo '<p class="description">' . esc_html__('Tarvitaan vain, jos et käytä AI Provider for OpenAI -konnektoria tai haluat käyttää WP Sanasepällä omaa erillistä API-avainta. Jos konnektori on käytössä ja tämä kenttä jätetään tyhjäksi, WP Sanaseppä käyttää konnektorin avainta automaattisesti. Avainta ei näytetä editorissa.', 'humantone') . '</p>';
    }

    public function render_model_field() {
        $settings = self::get_settings();
        $current_model = isset($settings['model']) ? $settings['model'] : self::defaults()['model'];
        $model_options = self::get_model_options();

        echo '<select id="humantone-model-field" name="' . esc_attr(self::OPTION_NAME) . '[model]" class="regular-text">';
        foreach ($model_options as $model_id => $label) {
            printf(
                '<option value="%1$s" %2$s>%3$s</option>',
                esc_attr($model_id),
                selected($current_model, $model_id, false),
                esc_html($label . ' (' . $model_id . ')')
            );
        }
        if (!isset($model_options[$current_model]) && $current_model !== '') {
            printf(
                '<option value="%1$s" selected>%2$s</option>',
                esc_attr($current_model),
                esc_html(sprintf(__('Nykyinen oma malli: %s', 'humantone'), $current_model))
            );
        }
        echo '</select>';

        echo '<p class="description">' . esc_html__('Valitse valmis malli pudotusvalikosta. Oletus on gpt-5.4-mini. Jos malli ei vielä näy omalla API-tililläsi, voit valita gpt-4.1:n tai kirjoittaa mallinimen käsin.', 'humantone') . '</p>';

        printf(
            '<label for="humantone-custom-model" class="humantone-inline-label">%1$s</label>',
            esc_html__('Oma mallinimi', 'humantone')
        );
        printf(
            '<input id="humantone-custom-model" type="text" name="%1$s[custom_model]" value="" class="regular-text" placeholder="%2$s" />',
            esc_attr(self::OPTION_NAME),
            esc_attr__('Esim. uusi-mallinimi, jos se on käytössä API-tililläsi', 'humantone')
        );
        echo '<p class="description">' . esc_html__('Täytä tämä vain, jos haluat käyttää mallia, jota ei ole listassa. Oma mallinimi ohittaa pudotusvalikon tallennuksessa.', 'humantone') . '</p>';
    }



    public function render_api_test_card() {
        $settings = self::get_settings();
        $status = self::get_api_test_status();
        $status_key = isset($status['status']) ? sanitize_key($status['status']) : 'not_tested';
        $status_labels = array(
            'ok' => __('Toimii', 'humantone'),
            'fail' => __('Ei toimi', 'humantone'),
            'not_tested' => __('Ei vielä testattu', 'humantone'),
            'not_run' => __('Ei vielä testattu', 'humantone'),
        );
        if (empty($settings['api_key']) && 'fail' === $status_key && !empty($status['message']) && false !== strpos($status['message'], 'oma API-avain puuttuu')) {
            $status_key = 'not_tested';
            $status['message'] = __('API-avainta ei ole vielä tallennettu. Kirjoita avain, tallenna asetukset ja testaa sen jälkeen.', 'humantone');
        }
        $label = isset($status_labels[$status_key]) ? $status_labels[$status_key] : $status_key;
        ?>
        <div class="humantone-card humantone-card-inner humantone-api-test-card" id="humantone-api-test-card" data-saved-api-key="<?php echo esc_attr(empty($settings['api_key']) ? '0' : '1'); ?>" data-provider-available="<?php echo esc_attr((class_exists('HumanTone_AI_Client') && HumanTone_AI_Client::is_openai_provider_available()) ? '1' : '0'); ?>" data-current-status="<?php echo esc_attr($status_key); ?>" data-current-source="<?php echo esc_attr(isset($status['source']) ? $status['source'] : ''); ?>">
            <h3><?php echo esc_html__('API-avaimen testi', 'humantone'); ?></h3>
            <p><?php echo esc_html__('Testaa käytössä oleva API-lähde. Jos AI Provider for OpenAI -konnektori on käytettävissä ja omaa API-avainta ei ole tallennettu, WP Sanaseppä testaa konnektorin automaattisesti ja näyttää, toimiiko yhteys.', 'humantone'); ?></p>
            <div id="humantone-api-test-status" class="humantone-api-test-status humantone-api-test-status-<?php echo esc_attr($status_key); ?>">
                <strong><?php echo esc_html__('Tila:', 'humantone'); ?></strong>
                <span class="humantone-api-test-label"><?php echo esc_html($label); ?></span><br />
                <span class="humantone-api-test-message"><?php echo esc_html(isset($status['message']) ? $status['message'] : ''); ?></span>
                <?php if (!empty($status['tested_at'])) : ?>
                    <br /><span class="description humantone-api-test-time"><?php echo esc_html(sprintf(__('Viimeksi testattu: %s', 'humantone'), $status['tested_at'])); ?></span>
                <?php endif; ?>
                <?php if (!empty($status['model'])) : ?>
                    <br /><span class="description humantone-api-test-model"><?php echo esc_html(sprintf(__('Testattu malli: %s', 'humantone'), $status['model'])); ?></span>
                <?php endif; ?>
                <?php if (!empty($status['source'])) : ?>
                    <br /><span class="description humantone-api-test-source"><?php echo esc_html(sprintf(__('API-lähde: %s', 'humantone'), $status['source'])); ?></span>
                <?php endif; ?>
            </div>
            <p>
                <button type="button" class="button button-secondary" id="humantone-save-api-settings"><?php echo esc_html__('Tallenna API-asetukset', 'humantone'); ?></button>
                <button type="button" class="button button-primary" id="humantone-test-api-key"><?php echo esc_html__('Testaa API-avain nyt', 'humantone'); ?></button>
                <button type="button" class="button button-secondary" data-humantone-jump-tab="api-guide"><?php echo esc_html__('Avaa API-avaimen ohje', 'humantone'); ?></button>
            </p>
            <div id="humantone-api-test-preflight" class="notice notice-warning inline" style="display:none;"><p></p></div>
            <p class="description">
                <?php echo esc_html__('Jos kirjoitit tai vaihdoit API-avaimen, API-lähteen tai mallin, paina ensin Tallenna API-asetukset. Testi käyttää tallennettuja asetuksia.', 'humantone'); ?>
                <?php if (empty($settings['api_key'])) : ?>
                    <br /><?php echo esc_html__('Tallennettua API-avainta ei vielä ole. Kirjoita avain kenttään, paina ensin Tallenna API-asetukset ja suorita testi vasta sen jälkeen.', 'humantone'); ?>
                <?php endif; ?>
            </p>
        </div>
        <?php
    }

    public function render_default_profile_field() {
        $settings = self::get_settings();
        $profiles = $settings['profiles'];
        printf('<select name="%1$s[default_profile]">', esc_attr(self::OPTION_NAME));
        foreach ($profiles as $id => $profile) {
            printf(
                '<option value="%1$s" %2$s>%3$s</option>',
                esc_attr($id),
                selected($settings['default_profile'], $id, false),
                esc_html($profile['name'])
            );
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Tätä profiilia käytetään oletuksena työkaluissa ja Gutenberg-sivupalkissa.', 'humantone') . '</p>';
    }

    public function render_profiles_field() {
        $profiles = self::get_profiles();
        $slots = array_values($profiles);
        while (count($slots) < 5) {
            $slots[] = array(
                'id' => '',
                'name' => '',
                'brand_voice' => '',
                'audience' => '',
                'banned_phrases' => '',
                'example_text' => '',
            );
        }

        echo '<p class="description">' . esc_html__('Voit luoda enintään viisi profiilia. Tyhjät profiilit ohitetaan tallennuksessa.', 'humantone') . '</p>';
        echo '<div class="humantone-profile-settings">';

        foreach ($slots as $index => $profile) {
            $number = $index + 1;
            echo '<div class="humantone-profile-card">';
            echo '<h3>' . esc_html(sprintf(__('Profiili %d', 'humantone'), $number)) . '</h3>';

            printf(
                '<input type="hidden" name="%1$s[profiles][%2$d][id]" value="%3$s" />',
                esc_attr(self::OPTION_NAME),
                (int) $index,
                esc_attr($profile['id'])
            );

            printf('<label>%s</label>', esc_html__('Nimi', 'humantone'));
            printf(
                '<input type="text" name="%1$s[profiles][%2$d][name]" value="%3$s" class="regular-text humantone-profile-name-field" data-humantone-profile-index="%2$d" placeholder="%4$s" />',
                esc_attr(self::OPTION_NAME),
                (int) $index,
                esc_attr($profile['name']),
                esc_attr__('Esim. Asiantuntija, Rento verkkokauppa, B2B', 'humantone')
            );

            printf('<label>%s</label>', esc_html__('Kohdeyleisö', 'humantone'));
            printf(
                '<textarea name="%1$s[profiles][%2$d][audience]" rows="2" class="large-text humantone-profile-audience-field" data-humantone-profile-index="%2$d" placeholder="%4$s">%3$s</textarea>',
                esc_attr(self::OPTION_NAME),
                (int) $index,
                esc_textarea($profile['audience']),
                esc_attr__('Kenelle teksti kirjoitetaan?', 'humantone')
            );

            printf('<label>%s</label>', esc_html__('Brändin äänensävy', 'humantone'));
            printf(
                '<textarea name="%1$s[profiles][%2$d][brand_voice]" rows="4" class="large-text humantone-profile-voice-field" data-humantone-profile-index="%2$d" placeholder="%4$s">%3$s</textarea>',
                esc_attr(self::OPTION_NAME),
                (int) $index,
                esc_textarea($profile['brand_voice']),
                esc_attr__('Kuvaile tyyli, rytmi, puhuttelu ja sävy.', 'humantone')
            );

            printf('<label>%s</label>', esc_html__('Vältettävät fraasit', 'humantone'));
            printf(
                '<textarea name="%1$s[profiles][%2$d][banned_phrases]" rows="3" class="large-text humantone-profile-banned-field" data-humantone-profile-index="%2$d" placeholder="%4$s">%3$s</textarea>',
                esc_attr(self::OPTION_NAME),
                (int) $index,
                esc_textarea($profile['banned_phrases']),
                esc_attr__('Erottele pilkulla tai riveittäin.', 'humantone')
            );

            printf('<label>%s</label>', esc_html__('Tyyliesimerkki', 'humantone'));
            printf(
                '<textarea name="%1$s[profiles][%2$d][example_text]" rows="4" class="large-text humantone-profile-example-field" data-humantone-profile-index="%2$d" placeholder="%4$s">%3$s</textarea>',
                esc_attr(self::OPTION_NAME),
                (int) $index,
                esc_textarea($profile['example_text']),
                esc_attr__('Lyhyt esimerkkiteksti, jonka tyyliä haluat jäljitellä. Älä lisää arkaluontoista dataa.', 'humantone')
            );

            echo '</div>';
        }

        echo '</div>';
    }

    private function render_access_capability_field() {
        $settings = self::get_settings();
        $current = isset($settings['access_capability']) ? $settings['access_capability'] : 'manage_options';
        $options = self::get_access_capability_options();

        echo '<select name="' . esc_attr(self::OPTION_NAME) . '[access_capability]">';
        foreach ($options as $capability => $label) {
            printf('<option value="%s" %s>%s</option>', esc_attr($capability), selected($current, $capability, false), esc_html($label));
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Oletus on vain ylläpitäjät. Tämä rajoittaa, ketkä voivat käyttää sivuston OpenAI-kulua WP Sanasepän kautta.', 'humantone') . '</p>';
    }

    public function render_limit_number_field($key, $label, $description, $min, $max) {
        $settings = self::get_settings();
        $value = isset($settings['limits'][$key]) ? (int) $settings['limits'][$key] : 0;
        printf(
            '<input type="number" name="%1$s[limits][%2$s]" value="%3$d" min="%4$d" max="%5$d" step="1" class="small-text" />',
            esc_attr(self::OPTION_NAME),
            esc_attr($key),
            (int) $value,
            (int) $min,
            (int) $max
        );
        echo '<p class="description"><strong>' . esc_html($label) . ':</strong> ' . esc_html($description) . '</p>';
    }


    public function render_beta_diagnostics_dashboard() {
        $diag = self::get_environment_diagnostics();
        echo '<div class="humantone-onboarding-grid humantone-beta-diagnostics-grid">';
        echo '<div class="humantone-card humantone-card-inner"><h3>' . esc_html__('Ympäristö', 'humantone') . '</h3>';
        echo '<table class="widefat striped"><tbody>';
        $rows = array(
            __('Sanaseppä-versio', 'humantone') => $diag['plugin_version'],
            __('WordPress', 'humantone') => $diag['wordpress_version'],
            __('PHP', 'humantone') => $diag['php_version'],
            __('Muistiraja', 'humantone') => $diag['memory_limit'],
            __('max_execution_time', 'humantone') => $diag['max_execution_time'],
            __('WP_DEBUG', 'humantone') => $diag['wp_debug'],
        );
        foreach ($rows as $label => $value) {
            echo '<tr><th>' . esc_html($label) . '</th><td><code>' . esc_html((string) $value) . '</code></td></tr>';
        }
        echo '</tbody></table></div>';
        echo '<div class="humantone-card humantone-card-inner"><h3>' . esc_html__('OpenAI ja tausta-ajot', 'humantone') . '</h3>';
        echo '<table class="widefat striped"><tbody>';
        $rows = array(
            __('API-tila', 'humantone') => $diag['api_status'],
            __('API-viesti', 'humantone') => $diag['api_message'],
            __('Malli', 'humantone') => $diag['api_model'],
            __('WP-Cron', 'humantone') => $diag['wp_cron'],
            __('Seuraava Sanaseppä-cron', 'humantone') => $diag['next_bulk_cron'],
            __('Viimeisin ajo', 'humantone') => $diag['last_job_status'] . ' ' . $diag['last_job_progress'],
            __('Viimeisin eteneminen', 'humantone') => $diag['last_job_updated'],
        );
        foreach ($rows as $label => $value) {
            echo '<tr><th>' . esc_html($label) . '</th><td>' . esc_html((string) $value) . '</td></tr>';
        }
        echo '</tbody></table></div></div>';

        $logs = self::get_beta_log(40);
        echo '<div class="humantone-card humantone-card-inner humantone-beta-log"><h3>' . esc_html__('Beta-loki', 'humantone') . '</h3>';
        echo '<p class="description">' . esc_html__('Lokissa näkyvät viimeisimmät Sanasepän beta-tapahtumat. Se auttaa ongelmien selvittämisessä testikäyttäjien kanssa.', 'humantone') . '</p>';
        if (empty($logs)) {
            echo '<p>' . esc_html__('Lokissa ei ole vielä tapahtumia.', 'humantone') . '</p>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Aika', 'humantone') . '</th><th>' . esc_html__('Käyttäjä', 'humantone') . '</th><th>' . esc_html__('Toiminto', 'humantone') . '</th><th>' . esc_html__('Tila', 'humantone') . '</th><th>' . esc_html__('Viesti', 'humantone') . '</th></tr></thead><tbody>';
            foreach ($logs as $entry) {
                $user = !empty($entry['user_id']) ? get_user_by('id', absint($entry['user_id'])) : null;
                $user_label = $user ? $user->user_login : '-';
                echo '<tr><td>' . esc_html(isset($entry['time']) ? $entry['time'] : '') . '</td><td>' . esc_html($user_label) . '</td><td>' . esc_html(isset($entry['action']) ? $entry['action'] : '') . '</td><td><code>' . esc_html(isset($entry['status']) ? $entry['status'] : '') . '</code></td><td>' . esc_html(isset($entry['message']) ? $entry['message'] : '') . '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
    }

    public function render_monthly_budget_field() {
        $settings = self::get_settings();
        $value = isset($settings['limits']['monthly_budget_usd']) ? (float) $settings['limits']['monthly_budget_usd'] : 10;
        printf(
            '<input type="number" name="%1$s[limits][monthly_budget_usd]" value="%2$s" min="0" max="10000" step="0.01" class="small-text" />',
            esc_attr(self::OPTION_NAME),
            esc_attr($value)
        );
        echo '<p class="description">' . esc_html__('USD/kk. Aseta 0, jos et halua budjettivaroitusta. Sanaseppä näyttää varoituksen, kun kuukauden arvioitu OpenAI-kulu ylittää 80 % budjetista.', 'humantone') . '</p>';
    }

    public function render_cost_dashboard() {
        if (!class_exists('HumanTone_Costs')) {
            echo '<p>' . esc_html__('Kustannusseuranta ei ole käytettävissä.', 'humantone') . '</p>';
            return;
        }
        $summary = HumanTone_Costs::get_summary();
        $settings = self::get_settings();
        $budget = isset($settings['limits']['monthly_budget_usd']) ? (float) $settings['limits']['monthly_budget_usd'] : 0;
        $month_cost = isset($summary['month']['cost_usd']) ? (float) $summary['month']['cost_usd'] : 0;
        if ($budget > 0 && $month_cost >= ($budget * 0.8)) {
            echo '<div class="notice notice-warning inline"><p><strong>' . esc_html__('Budjettivaroitus:', 'humantone') . '</strong> ' . esc_html(sprintf(__('Tämän kuun arvioitu kulu on %1$s / %2$s.', 'humantone'), HumanTone_Costs::format_usd($month_cost), HumanTone_Costs::format_usd($budget))) . '</p></div>';
        }
        echo '<div class="humantone-cost-grid">';
        $this->render_cost_box(__('Tänään', 'humantone'), $summary['today']);
        $this->render_cost_box(__('Tämä kuukausi', 'humantone'), $summary['month']);
        echo '</div>';
        echo '<h3>' . esc_html__('Viimeisimmät API-kutsut', 'humantone') . '</h3>';
        if (isset($_GET['humantone_api_log_pruned'])) {
            echo '<div class="notice notice-success inline"><p>' . esc_html__('API-kutsuloki siivottiin. Uusimmat 50 riviä säilytettiin.', 'humantone') . '</p></div>';
        }
        if (empty($summary['recent'])) {
            echo '<p>' . esc_html__('Kustannusdataa ei ole vielä kertynyt. Tee yksi käsittely WP Sanasepällä, niin OpenAI:n usage-tokenit näkyvät tässä.', 'humantone') . '</p>';
            return;
        }
        $allowed_limits = array(20, 50, 100);
        $visible_limit = isset($_GET['humantone_api_log_limit']) ? absint($_GET['humantone_api_log_limit']) : HumanTone_Costs::DEFAULT_VISIBLE_CALLS;
        if (!in_array($visible_limit, $allowed_limits, true)) {
            $visible_limit = HumanTone_Costs::DEFAULT_VISIBLE_CALLS;
        }
        $recent_total = HumanTone_Costs::count_recent();
        $recent_rows = HumanTone_Costs::get_recent($visible_limit);
        echo '<p class="description">' . esc_html(sprintf(__('Näytetään %1$d viimeisintä API-kutsua. Lokissa on yhteensä %2$d riviä. Lisäosa säilyttää enintään %3$d uusinta API-kutsua.', 'humantone'), count($recent_rows), $recent_total, HumanTone_Costs::MAX_RECENT_CALLS)) . '</p>';
        echo '<div class="humantone-history-controls humantone-api-log-controls">';
        echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '">';
        echo '<input type="hidden" name="page" value="wp-sanaseppa-settings" />';
        echo '<input type="hidden" name="tab" value="costs" />';
        echo '<label for="humantone-api-log-limit">' . esc_html__('Näytä', 'humantone') . '</label> ';
        echo '<select id="humantone-api-log-limit" name="humantone_api_log_limit">';
        foreach ($allowed_limits as $limit) {
            echo '<option value="' . esc_attr($limit) . '" ' . selected($visible_limit, $limit, false) . '>' . esc_html(sprintf(__('%d viimeisintä', 'humantone'), $limit)) . '</option>';
        }
        echo '</select> ';
        echo '<button type="submit" class="button">' . esc_html__('Päivitä näkymä', 'humantone') . '</button>';
        echo '</form>';
        if (current_user_can('manage_options')) {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'' . esc_js(__('Siivotaanko API-kutsuloki? Uusimmat 50 riviä säilytetään ja vanhemmat poistetaan.', 'humantone')) . '\');">';
            wp_nonce_field('humantone_prune_api_log');
            echo '<input type="hidden" name="action" value="humantone_prune_api_log" />';
            echo '<button type="submit" class="button button-secondary">' . esc_html__('Siivoa vanhat API-kutsut', 'humantone') . '</button>';
            echo '</form>';
        }
        echo '</div>';
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Aika', 'humantone') . '</th><th>' . esc_html__('Malli', 'humantone') . '</th><th>' . esc_html__('Input', 'humantone') . '</th><th>' . esc_html__('Output', 'humantone') . '</th><th>' . esc_html__('Hinta-arvio', 'humantone') . '</th></tr></thead><tbody>';
        foreach ($recent_rows as $row) {
            echo '<tr>';
            echo '<td>' . esc_html(isset($row['time']) ? $row['time'] : '') . '</td>';
            echo '<td>' . esc_html(isset($row['model']) ? $row['model'] : '') . '</td>';
            echo '<td>' . esc_html(number_format_i18n(isset($row['input_tokens']) ? (int) $row['input_tokens'] : 0)) . '</td>';
            echo '<td>' . esc_html(number_format_i18n(isset($row['output_tokens']) ? (int) $row['output_tokens'] : 0)) . '</td>';
            echo '<td>' . esc_html(HumanTone_Costs::format_usd(isset($row['cost_usd']) ? (float) $row['cost_usd'] : 0)) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '<p class="description">' . esc_html__('Hinnat ovat arvioita mallikohtaisen token-hinnaston perusteella. Siivous poistaa vain yksittäisiä kutsurivejä, ei päivän tai kuukauden kustannusyhteenvetoja.', 'humantone') . '</p>';
    }

    private function render_cost_box($title, $data) {
        $data = wp_parse_args(is_array($data) ? $data : array(), array('requests' => 0, 'input_tokens' => 0, 'output_tokens' => 0, 'total_tokens' => 0, 'cost_usd' => 0));
        echo '<div class="humantone-card humantone-card-inner humantone-cost-box">';
        echo '<h3>' . esc_html($title) . '</h3>';
        echo '<p><strong>' . esc_html(HumanTone_Costs::format_usd((float) $data['cost_usd'])) . '</strong></p>';
        echo '<ul>';
        echo '<li>' . esc_html(sprintf(__('Pyyntöjä: %s', 'humantone'), number_format_i18n((int) $data['requests']))) . '</li>';
        echo '<li>' . esc_html(sprintf(__('Input-tokenit: %s', 'humantone'), number_format_i18n((int) $data['input_tokens']))) . '</li>';
        echo '<li>' . esc_html(sprintf(__('Output-tokenit: %s', 'humantone'), number_format_i18n((int) $data['output_tokens']))) . '</li>';
        echo '<li>' . esc_html(sprintf(__('Tokenit yhteensä: %s', 'humantone'), number_format_i18n((int) $data['total_tokens']))) . '</li>';
        echo '</ul>';
        echo '</div>';
    }

    private function has_custom_profile() {
        $settings = self::get_settings();
        $defaults = self::defaults();
        $default = $defaults['profiles']['default'];
        foreach ($settings['profiles'] as $profile) {
            if ((isset($profile['name']) && $profile['name'] !== $default['name']) ||
                (isset($profile['brand_voice']) && $profile['brand_voice'] !== $default['brand_voice']) ||
                (isset($profile['audience']) && $profile['audience'] !== $default['audience']) ||
                (isset($profile['example_text']) && trim($profile['example_text']) !== '')) {
                return true;
            }
        }
        return false;
    }

    private function render_onboarding_status_badge($is_done, $done_text, $todo_text) {
        $class = $is_done ? 'humantone-status-done' : 'humantone-status-todo';
        $text = $is_done ? $done_text : $todo_text;
        echo '<span class="humantone-onboarding-status ' . esc_attr($class) . '">' . esc_html($text) . '</span>';
    }


    private function render_safety_checkbox($key, $label, $description = '') {
        $safety = self::get_safety();
        printf(
            '<label><input type="checkbox" name="%1$s[safety][%2$s]" value="1" %3$s /> %4$s</label>',
            esc_attr(self::OPTION_NAME),
            esc_attr($key),
            checked(!empty($safety[$key]), true, false),
            esc_html($label)
        );
        if ($description !== '') {
            echo '<p class="description">' . esc_html($description) . '</p>';
        }
    }


    private function render_license_notice() {
        if (empty($_GET['humantone_license'])) {
            return;
        }
        $status = sanitize_key(wp_unslash($_GET['humantone_license']));
        $message = HumanTone_License::get_status_message();
        $class = in_array($status, array('activated', 'checked', 'saved', 'deactivated'), true) ? 'notice-success' : 'notice-error';
        echo '<div class="notice ' . esc_attr($class) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }

    private function render_license_panel() {
        $license_status = HumanTone_License::get_status();
        $is_pro = HumanTone_License::is_pro_enabled();
        $mode_label = HumanTone_License::get_mode_label();
        $license_code = HumanTone_License::get_status_code();
        ?>
        <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="license" hidden>
            <h2><?php echo esc_html__('Lisenssi ja Free/Pro-tila', 'humantone'); ?></h2>
            <p><?php echo esc_html__('Free-versio sopii yksittäisten tekstien viimeistelyyn. Pro avaa kokonaiset artikkelit ja sivut, joukkokäsittelyn, WooCommerce-tuotteet, historian, palautuksen ja muut ammattikäytön työkalut.', 'humantone'); ?></p>

            <div class="humantone-license-status-card <?php echo $is_pro ? 'humantone-license-pro' : 'humantone-license-free'; ?>">
                <h3><?php echo esc_html(sprintf(__('Nykyinen tila: %s', 'humantone'), $mode_label)); ?></h3>
                <p><?php echo esc_html(HumanTone_License::get_status_message()); ?></p>
                <?php if ('expired' === $license_code) : ?>
                    <div class="humantone-license-expired-notice">
                        <strong><?php echo esc_html__('Lisenssi on vanhentunut.', 'humantone'); ?></strong>
                        <p><?php echo esc_html__('Pro-toiminnot, kuten tallennus, joukkokäsittely, Historia ja palautus sekä WooCommerce-työkalut, ovat pois käytöstä. Aiemmat asetukset, historia ja sisällöt säilyvät. Uusi lisenssi tai aktivoi uusi avain, jotta Pro-toiminnot avautuvat uudelleen.', 'humantone'); ?></p>
                    </div>
                <?php endif; ?>
                <?php if (!empty($license_status['checked_at'])) : ?>
                    <p class="description"><?php echo esc_html(sprintf(__('Tarkistettu viimeksi: %s', 'humantone'), $license_status['checked_at'])); ?></p>
                <?php endif; ?>
                <?php if (!empty($license_status['plan'])) : ?>
                    <p class="description"><?php echo esc_html(sprintf(__('Paketti: %s', 'humantone'), $license_status['plan'])); ?></p>
                <?php endif; ?>
                <?php if ($license_status['sites_allowed'] !== '') : ?>
                    <p class="description"><?php echo esc_html(sprintf(__('Aktivoinnit: %s / %s', 'humantone'), $license_status['sites_used'], $license_status['sites_allowed'])); ?></p>
                <?php endif; ?>
            </div>

            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row"><label for="humantone-license-key"><?php echo esc_html__('Lisenssiavain', 'humantone'); ?></label></th>
                        <td>
                            <input id="humantone-license-key" type="password" name="humantone_license_key" form="humantone-license-action-form" value="<?php echo esc_attr(HumanTone_License::get_key()); ?>" class="regular-text" autocomplete="new-password" data-bwignore="true" data-1p-ignore="true" data-lpignore="true" />
                            <p class="description"><?php echo esc_html__('Liitä tähän WP Sanaseppä Pro -lisenssiavain. Avainta ei lähetetä selaimen editoriin.', 'humantone'); ?></p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <p class="submit humantone-license-actions">
                <button type="submit" form="humantone-license-action-form" class="button button-secondary" name="action" value="humantone_license_save"><?php echo esc_html__('Tallenna lisenssiavain', 'humantone'); ?></button>
                <button type="submit" form="humantone-license-action-form" class="button button-primary" name="action" value="humantone_license_activate"><?php echo esc_html__('Aktivoi lisenssi', 'humantone'); ?></button>
                <button type="submit" form="humantone-license-action-form" class="button" name="action" value="humantone_license_check"><?php echo esc_html__('Tarkista lisenssi', 'humantone'); ?></button>
                <button type="submit" form="humantone-license-action-form" class="button button-link-delete" name="action" value="humantone_license_deactivate" onclick="return confirm('<?php echo esc_js(__('Poistetaanko lisenssin aktivointi tältä sivustolta?', 'humantone')); ?>');"><?php echo esc_html__('Poista aktivointi tältä sivustolta', 'humantone'); ?></button>
            </p>

            <div class="humantone-feature-grid">
                <div class="humantone-card humantone-card-inner">
                    <h3><?php echo esc_html__('Free sisältää', 'humantone'); ?></h3>
                    <ul class="humantone-help-list">
                        <li><?php echo esc_html__('Yksittäisen tekstin muokkaus', 'humantone'); ?></li>
                        <li><strong><?php echo esc_html__('Otsikoiden kirjainkoon korjaus', 'humantone'); ?></strong> — <?php echo esc_html__('muuttaa tekoälymäiset Title Case -otsikot luontevaksi suomeksi.', 'humantone'); ?></li>
                        <li><?php echo esc_html__('AI-fraasien tunnistus', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Yksi brändiprofiili', 'humantone'); ?></li>
                    </ul>
                </div>
                <div class="humantone-card humantone-card-inner humantone-pro-card">
                    <h3><?php echo esc_html__('Pro avaa', 'humantone'); ?></h3>
                    <ul class="humantone-help-list">
                        <li><?php echo esc_html__('Kokonaiset artikkelit ja sivut', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Joukkokäsittelyn ja useat brändiprofiilit', 'humantone'); ?></li>
                        <li><?php echo esc_html__('WooCommerce-tuotetekstit', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Historia, palautus ja turvallinen tallennus', 'humantone'); ?></li>
                        <li><?php echo esc_html__('SEO-, ACF- ja sivunrakentajasuojaukset', 'humantone'); ?></li>
                    </ul>
                </div>
            </div>
        </section>
        <?php
    }


    private function get_api_source_label($source) {
        $source = sanitize_key((string) $source);
        $labels = array(
            'auto' => __('Automaattinen', 'humantone'),
            'provider' => __('AI Provider for OpenAI -konnektori', 'humantone'),
            'own' => __('WP Sanasepän oma API-avain', 'humantone'),
        );

        return isset($labels[$source]) ? $labels[$source] : $labels['auto'];
    }


    public function save_api_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sinulla ei ole oikeutta muuttaa näitä asetuksia.', 'humantone'));
        }

        check_admin_referer('humantone_save_api_settings');

        $current = self::get_settings();
        $input = isset($_POST[self::OPTION_NAME]) && is_array($_POST[self::OPTION_NAME]) ? wp_unslash($_POST[self::OPTION_NAME]) : array();

        if (isset($input['api_key'])) {
            $current['api_key'] = sanitize_text_field($input['api_key']);
        }

        if (isset($input['api_source'])) {
            $api_source = sanitize_key($input['api_source']);
            $current['api_source'] = in_array($api_source, array('auto', 'provider', 'own'), true) ? $api_source : 'auto';
        }

        $selected_model = isset($input['model']) ? sanitize_text_field($input['model']) : $current['model'];
        $custom_model = isset($input['custom_model']) ? sanitize_text_field($input['custom_model']) : '';
        $model = $custom_model !== '' ? $custom_model : $selected_model;
        if (!preg_match('/^[a-zA-Z0-9_.:-]+$/', $model)) {
            $model = self::defaults()['model'];
        }
        $current['model'] = $model;

        update_option(self::OPTION_NAME, $current);
        update_option(self::API_TEST_OPTION_NAME, array(
            'status' => 'not_tested',
            'message' => __('API-asetukset tallennettu. Voit suorittaa yhteystestin nyt.', 'humantone'),
            'tested_at' => current_time('mysql'),
            'model' => $current['model'],
            'source' => $this->get_api_source_label($current['api_source']),
        ));

        wp_safe_redirect(add_query_arg(array(
            'page' => 'wp-sanaseppa-settings',
            'tab' => 'api',
            'humantone_api_saved' => '1',
        ), admin_url('admin.php')));
        exit;
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap humantone-settings-wrap">
            <h1><?php echo esc_html__('WP Sanaseppä', 'humantone'); ?></h1>
            <div class="humantone-mode-switch humantone-card-inner">
                <strong><?php echo esc_html__('Olet asetuksissa.', 'humantone'); ?></strong>
                <span><?php echo esc_html__('Täällä määritetään API-avain, brändiprofiilit, lisenssi ja turvallisuusasetukset.', 'humantone'); ?></span>
                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa')); ?>"><?php echo esc_html__('Siirry tekstityökaluun', 'humantone'); ?></a>
            </div>
            <?php $this->render_import_notice(); ?>
            <?php $this->render_license_notice(); ?>
            <?php $api_status = self::get_api_test_status(); if (self::is_api_status_blocking($api_status)) : ?>
                <div class="notice notice-error humantone-api-global-notice"><p><strong><?php echo esc_html__('OpenAI-yhteys vaatii huomiota.', 'humantone'); ?></strong> <?php echo esc_html(self::get_api_status_notice_message($api_status)); ?> <a href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Avaa OpenAI Billing', 'humantone'); ?></a> &nbsp; <button type="button" class="button button-small" data-humantone-jump-tab="api"><?php echo esc_html__('Avaa API ja malli', 'humantone'); ?></button></p></div>
            <?php endif; ?>

            <?php if (isset($_GET['humantone_api_saved'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html__('API-asetukset tallennettu. Voit suorittaa yhteystestin nyt.', 'humantone'); ?></p></div>
            <?php endif; ?>
            <nav class="nav-tab-wrapper humantone-admin-tabs" aria-label="<?php echo esc_attr__('WP Sanasepän asetukset', 'humantone'); ?>">
                <button type="button" class="nav-tab nav-tab-active" data-humantone-settings-tab="onboarding"><?php echo esc_html__('Ohjattu käyttöönotto', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="api"><?php echo esc_html__('API ja malli', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="api-guide"><?php echo esc_html__('API-avaimen ohje', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="diagnostics"><?php echo esc_html__('Testit', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="profiles"><?php echo esc_html__('Brändiprofiilit', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="heading-terms"><?php echo esc_html__('Otsikkosanasto', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="safety"><?php echo esc_html__('Turvallinen tallennus', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="limits"><?php echo esc_html__('Käyttörajat', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="costs"><?php echo esc_html__('Kustannusseuranta', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="export-import"><?php echo esc_html__('Vienti ja tuonti', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="help"><?php echo esc_html__('Käyttöohje', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-settings-tab="license"><?php echo esc_html__('Lisenssi', 'humantone'); ?></button>
            </nav>

            <form action="options.php" method="post" class="humantone-settings-form">
                <?php settings_fields(self::OPTION_GROUP); ?>

                <section class="humantone-settings-panel humantone-settings-panel-active humantone-card" data-humantone-settings-panel="onboarding">
                    <h2><?php echo esc_html__('Ohjattu käyttöönotto', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Tämä velho auttaa tekemään vähimmäisasetukset: API-avain, malli ja ensimmäinen brändiprofiili. Lopuksi tallenna asetukset sivun alalaidasta.', 'humantone'); ?></p>

                    <?php $settings = self::get_settings(); ?>
                    <div class="humantone-wizard-progress" aria-label="<?php echo esc_attr__('Käyttöönoton tila', 'humantone'); ?>">
                        <div class="humantone-wizard-step">
                            <strong><?php echo esc_html__('1. API-avain', 'humantone'); ?></strong>
                            <?php $this->render_onboarding_status_badge(!empty($settings['api_key']), __('Lisätty', 'humantone'), __('Puuttuu', 'humantone')); ?>
                        </div>
                        <div class="humantone-wizard-step">
                            <strong><?php echo esc_html__('2. Malli', 'humantone'); ?></strong>
                            <?php $this->render_onboarding_status_badge(!empty($settings['model']), __('Valittu', 'humantone'), __('Puuttuu', 'humantone')); ?>
                        </div>
                        <div class="humantone-wizard-step">
                            <strong><?php echo esc_html__('3. Brändiprofiili', 'humantone'); ?></strong>
                            <?php $this->render_onboarding_status_badge($this->has_custom_profile(), __('Määritetty', 'humantone'), __('Tee ohjatusti', 'humantone')); ?>
                        </div>
                    </div>

                    <div class="humantone-onboarding-grid humantone-wizard-grid">
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Vaihe 1: API ja malli', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Lisää API-avain ja valitse malli omalla välilehdellään. Jos et ole koskaan luonut OpenAI API -avainta, avaa ensin selkeä ohje.', 'humantone'); ?></p>
                            <p>
                                <button type="button" class="button button-secondary" data-humantone-jump-tab="api-guide"><?php echo esc_html__('Avaa API-avaimen ohje', 'humantone'); ?></button>
                                <button type="button" class="button button-secondary" data-humantone-jump-tab="api"><?php echo esc_html__('Avaa API-asetukset', 'humantone'); ?></button>
                            </p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Vaihe 2: Luo ensimmäinen brändiprofiili', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Täytä nämä kentät ja paina painiketta. Velho siirtää tiedot ensimmäiseen brändiprofiiliin, jonka voit vielä tarkistaa Brändiprofiilit-välilehdellä.', 'humantone'); ?></p>

                            <label class="humantone-label" for="humantone-wizard-brand-name"><?php echo esc_html__('Brändin tai sivuston nimi', 'humantone'); ?></label>
                            <input type="text" id="humantone-wizard-brand-name" class="regular-text" placeholder="<?php echo esc_attr__('Esim. Kukkakauppa Aino', 'humantone'); ?>" />

                            <label class="humantone-label" for="humantone-wizard-audience"><?php echo esc_html__('Kohdeyleisö', 'humantone'); ?></label>
                            <textarea id="humantone-wizard-audience" rows="2" class="large-text" placeholder="<?php echo esc_attr__('Kenelle tekstit kirjoitetaan? Esim. suomalaiset pienyrittäjät, verkkokaupan asiakkaat, paikalliset kuluttajat.', 'humantone'); ?>"></textarea>

                            <div class="humantone-wizard-two-cols">
                                <div>
                                    <label class="humantone-label" for="humantone-wizard-tone"><?php echo esc_html__('Perussävy', 'humantone'); ?></label>
                                    <select id="humantone-wizard-tone">
                                        <option value="selkea"><?php echo esc_html__('Selkeä ja asiantunteva', 'humantone'); ?></option>
                                        <option value="rento"><?php echo esc_html__('Rento ja lämmin', 'humantone'); ?></option>
                                        <option value="myyva"><?php echo esc_html__('Myyvä mutta hillitty', 'humantone'); ?></option>
                                        <option value="asiantuntija"><?php echo esc_html__('Asiantuntijamainen ja luotettava', 'humantone'); ?></option>
                                    </select>
                                </div>
                                <div>
                                    <label class="humantone-label" for="humantone-wizard-addressing"><?php echo esc_html__('Puhuttelu', 'humantone'); ?></label>
                                    <select id="humantone-wizard-addressing">
                                        <option value="sinuttele"><?php echo esc_html__('Sinuttele lukijaa', 'humantone'); ?></option>
                                        <option value="neutraali"><?php echo esc_html__('Neutraali tyyli', 'humantone'); ?></option>
                                        <option value="teitittele"><?php echo esc_html__('Teitittele tarvittaessa', 'humantone'); ?></option>
                                    </select>
                                </div>
                            </div>

                            <label class="humantone-label" for="humantone-wizard-banned"><?php echo esc_html__('Vältettävät sanat ja fraasit', 'humantone'); ?></label>
                            <textarea id="humantone-wizard-banned" rows="2" class="large-text" placeholder="<?php echo esc_attr__('Esim. mullistava, huipputason, seuraavan sukupolven, kattava opas', 'humantone'); ?>"></textarea>

                            <label class="humantone-label" for="humantone-wizard-example"><?php echo esc_html__('Lyhyt tyyliesimerkki', 'humantone'); ?> <span class="humantone-required"><?php echo esc_html__('pakollinen', 'humantone'); ?></span></label>
                            <textarea id="humantone-wizard-example" rows="3" class="large-text" required aria-required="true" placeholder="<?php echo esc_attr__('Liitä tähän lyhyt teksti, joka kuulostaa oikealta brändiltä. Ei arkaluontoista dataa.', 'humantone'); ?>"></textarea>
                            <p class="description"><?php echo esc_html__('Tyyliesimerkki on pakollinen ohjatussa brändiprofiilin luonnissa, jotta WP Sanaseppä saa konkreettisen mallin halutusta suomenkielisestä tyylistä.', 'humantone'); ?></p>

                            <p class="humantone-actions">
                                <button type="button" class="button button-primary" id="humantone-create-first-profile"><?php echo esc_html__('Täytä ensimmäinen brändiprofiili', 'humantone'); ?></button>
                                <button type="button" class="button button-secondary" data-humantone-jump-tab="profiles"><?php echo esc_html__('Avaa brändiprofiilit', 'humantone'); ?></button>
                            </p>
                            <div id="humantone-wizard-message" class="humantone-wizard-message" aria-live="polite"></div>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Vaihe 3: Testaa asetukset', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Kun olet tallentanut asetukset, suorita perustesti ja kokeile työkalua ensin lyhyellä tekstillä.', 'humantone'); ?></p>
                            <p><button type="button" class="button button-secondary" data-humantone-jump-tab="diagnostics"><?php echo esc_html__('Avaa testit', 'humantone'); ?></button></p>
                        </div>
                    </div>
                </section>

                <?php $this->render_license_panel(); ?>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="api" hidden>
                    <h2><?php echo esc_html__('API ja malli', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Näitä asetuksia tarvitaan, jotta WP Sanaseppä voi lähettää tekstin muokattavaksi palvelimelta käsin. API-avain ei lähde selaimeen.', 'humantone'); ?></p>
                    <?php $this->render_api_connection_overview(); ?>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo esc_html__('API-avaimen lähde', 'humantone'); ?></th>
                                <td><?php $this->render_api_source_field(); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('OpenAI API -avain', 'humantone'); ?></th>
                                <td><?php $this->render_api_key_field(); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Malli', 'humantone'); ?></th>
                                <td><?php $this->render_model_field(); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="api-guide" hidden>
                    <h2><?php echo esc_html__('OpenAI API Key Guide', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Tämä ohje on tarkoitettu myös käyttäjälle, joka ei ole aiemmin luonut API-avainta. WP Sanaseppä tarvitsee OpenAI API -avaimen, jotta se voi muokata tekstejä OpenAI:n mallilla.', 'humantone'); ?></p>

                    <div class="humantone-api-guide-alert">
                        <strong><?php echo esc_html__('Tärkeää:', 'humantone'); ?></strong>
                        <?php echo esc_html__('ChatGPT Plus-, Pro- tai Team-tilaus ei automaattisesti tarkoita, että OpenAI API -käyttö on laskutettu. API-käyttö maksetaan OpenAI Platformin kautta erikseen.', 'humantone'); ?>
                    </div>

                    <div class="humantone-guide-grid humantone-api-guide-grid">
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('1. Avaa OpenAI Platform', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Kirjaudu selaimessa OpenAI Platformiin. Käytä sitä tiliä, jolla haluat maksaa API-käytöstä.', 'humantone'); ?></p>
                            <p><a class="button button-secondary" href="https://platform.openai.com/" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Avaa OpenAI Platform', 'humantone'); ?></a></p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('2. Lisää maksutapa tai saldo', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('API-käyttö vaatii yleensä maksutavan tai prepaid-saldoa. Jos pyyntö epäonnistuu myöhemmin laskutusvirheeseen, tarkista tämä kohta ensin.', 'humantone'); ?></p>
                            <p><a class="button button-secondary" href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Avaa laskutusasetukset', 'humantone'); ?></a></p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('3. Luo API-avain', 'humantone'); ?></h3>
                            <ol class="humantone-help-list">
                                <li><?php echo esc_html__('Avaa API keys -sivu.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Paina Create new secret key tai Luo uusi salainen avain.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Anna avaimelle nimi, esimerkiksi WP Sanaseppä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Kopioi avain heti talteen. Avainta ei yleensä voi nähdä uudelleen myöhemmin.', 'humantone'); ?></li>
                            </ol>
                            <p><a class="button button-primary" href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Avaa API keys -sivu', 'humantone'); ?></a></p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('4. Liitä avain WP Sanaseppään', 'humantone'); ?></h3>
                            <ol class="humantone-help-list">
                                <li><?php echo esc_html__('Palaa tähän WordPress-sivuun.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Avaa API ja malli -välilehti.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Liitä avain OpenAI API -avain -kenttään.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Valitse malli. Aloita oletuksella, ellei sinulla ole erityistä syytä vaihtaa mallia.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Paina Tallenna asetukset.', 'humantone'); ?></li>
                            </ol>
                            <p><button type="button" class="button button-secondary" data-humantone-jump-tab="api"><?php echo esc_html__('Siirry API-asetuksiin', 'humantone'); ?></button></p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('5. Testaa yhteys', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Kun avain on tallennettu, suorita järjestelmätesti. OpenAI-yhteystesti kertoo, toimiiko API-avain ja löytyykö valittu malli tililtäsi.', 'humantone'); ?></p>
                            <p><button type="button" class="button button-secondary" data-humantone-jump-tab="diagnostics"><?php echo esc_html__('Avaa käyttöönotto ja testit', 'humantone'); ?></button></p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Jos tulee virhe', 'humantone'); ?></h3>
                            <ul class="humantone-help-list">
                                <li><?php echo esc_html__('Tarkista, ettei API-avaimen alusta tai lopusta kopioitunut ylimääräisiä välilyöntejä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Tarkista OpenAI Platformin laskutusasetukset.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Tarkista, että valittu malli on käytettävissä omalla API-tililläsi.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Kokeile ensin oletusmallia gpt-5.4-mini. Jos se ei ole käytettävissä tililläsi, kokeile gpt-4.1:tä.', 'humantone'); ?></li>
                            </ul>
                        </div>
                    </div>

                    <p class="description"><?php echo esc_html__('Tämä välilehti ei sisällä tallennettavia asetuksia. Linkit avautuvat uuteen välilehteen.', 'humantone'); ?></p>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="profiles" hidden>
                    <h2><?php echo esc_html__('Brändiprofiilit', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Brändiprofiileilla määrität eri asiakkaiden, sivustojen tai sisältötyyppien äänensävyt. Työkaluissa voi valita käytettävän profiilin.', 'humantone'); ?></p>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Oletusprofiili', 'humantone'); ?></th>
                                <td><?php $this->render_default_profile_field(); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Profiilit', 'humantone'); ?></th>
                                <td><?php $this->render_profiles_field(); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </section>


                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="heading-terms" hidden>
                    <h2><?php echo esc_html__('Otsikkosanasto', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Nämä lyhenteet ja nimet säilytetään otsikoiden suomalaisessa kirjoitusasussa. Yksi termi per rivi. Toimii myös yhdysmerkin alussa, esimerkiksi SEO-vinkit ja WordPress-lisäosat.', 'humantone'); ?></p>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Säilytä muodossa', 'humantone'); ?></th>
                                <td><?php $this->render_heading_preserve_terms_field(); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="limits" hidden>
                    <h2><?php echo esc_html__('Käyttörajat ja kustannusten hallinta', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Näillä asetuksilla voit rajoittaa liian suuria käsittelyjä ja pitää API-kulut ennakoitavampina. Rajat ovat merkki- ja kappalemääräisiä, eivät tarkkoja token- tai euromääräisiä kustannuksia.', 'humantone'); ?></p>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Käyttöoikeus AI-työkaluihin', 'humantone'); ?></th>
                                <td><?php $this->render_access_capability_field(); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Yksittäinen teksti', 'humantone'); ?></th>
                                <td><?php $this->render_limit_number_field('plain_max_chars', __('Merkkiä', 'humantone'), __('Suurin sallittu tekstimäärä yksittäisen tekstin työkalussa.', 'humantone'), 1000, 30000); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Artikkeli tai sivu', 'humantone'); ?></th>
                                <td><?php $this->render_limit_number_field('post_max_chars', __('Merkkiä', 'humantone'), __('Suurin sallittu sisältömäärä artikkeli- ja sivutyökalussa.', 'humantone'), 5000, 150000); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('WooCommerce-tuotekuvaus', 'humantone'); ?></th>
                                <td><?php $this->render_limit_number_field('product_max_chars', __('Merkkiä', 'humantone'), __('Suurin sallittu pitkän tai lyhyen tuotekuvauksen pituus.', 'humantone'), 2000, 80000); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Joukkokäsittely', 'humantone'); ?></th>
                                <td><?php $this->render_limit_number_field('bulk_max_items', __('Sisältöä', 'humantone'), __('Kuinka monta artikkelia tai sivua voidaan käsitellä yhdellä kertaa.', 'humantone'), 1, 25); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Pitkän sisällön varoitus', 'humantone'); ?></th>
                                <td><?php $this->render_limit_number_field('warn_chars', __('Merkkiä', 'humantone'), __('Käyttöliittymä voi varoittaa pitkistä sisällöistä tämän rajan jälkeen.', 'humantone'), 1000, 150000); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Kuukausibudjetti', 'humantone'); ?></th>
                                <td><?php $this->render_monthly_budget_field(); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="safety" hidden>
                    <h2><?php echo esc_html__('Turvallinen tallennus', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Näillä asetuksilla WP Sanaseppä voi estää tallennuksen, jos muokattu sisältö näyttää kadottavan tärkeitä elementtejä. Tämä koskee artikkeli-, sivu- ja joukkokäsittelytyökaluja.', 'humantone'); ?></p>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Rakenne-elementit', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_structure_loss', __('Estä tallennus, jos linkkejä, kuvia, lyhytkoodeja tai WordPress-lohkoja katoaa', 'humantone'), __('Suositus: päällä. Tämä suojaa yleisimmiltä ongelmilta, joissa tekoäly poistaa vahingossa linkkejä, kuvia tai lohkorakenteita.', 'humantone')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Artikkelikuva', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_thumbnail_loss', __('Estä tallennus, jos artikkelikuva ei siirry uuteen luonnokseen', 'humantone'), __('Tarkistus tehdään luonnoksen luomisen jälkeen. Jos kuvaa ei saada kopioitua, tallennus palauttaa virheen.', 'humantone')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Ote', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_excerpt_loss', __('Estä tallennus, jos alkuperäinen ote katoaa', 'humantone'), __('Tämä on oletuksena pois päältä, koska kaikilla sivustoilla otetta ei käytetä.', 'humantone')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Kategoriat ja avainsanat', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_taxonomy_loss', __('Estä tallennus, jos kategoriat tai avainsanat eivät siirry uuteen luonnokseen', 'humantone'), __('Suositus: päällä. Tämä suojaa etenkin blogiartikkeleiden organisointia.', 'humantone')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('SEO-metatiedot', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_seo_meta_loss', __('Estä tallennus, jos Yoast SEO-, Rank Math- tai AIOSEO-metatiedot eivät siirry uuteen luonnokseen', 'humantone'), __('Suositus: päällä. Tämä suojaa SEO-otsikoita, metakuvauksia, avainsanoja, canonical-osoitteita ja sosiaalisen median metatietoja.', 'humantone')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('ACF-kentät', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_acf_meta_loss', __('Estä tallennus, jos ACF-kenttien arvot eivät siirry uuteen luonnokseen', 'humantone'), __('Suositus: päällä, jos sivusto käyttää Advanced Custom Fields -lisäosaa. Tämä suojaa sivupohjien ja erikoissisältöjen kenttäarvoja luonnoskopioissa.', 'humantone')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row"><?php echo esc_html__('Sivunrakentajat', 'humantone'); ?></th>
                                <td><?php $this->render_safety_checkbox('block_page_builder_overwrite', __('Estä alkuperäisen korvaaminen, jos sisältö käyttää Elementoria, Diviä tai WPBakeryä', 'humantone'), __('Suositus: päällä. Sivunrakentajat tallentavat rakenteita omiin kenttiinsä, joten alkuperäisen korvaaminen on riskialttiimpaa. Uuden luonnoksen luonti on edelleen sallittu.', 'humantone')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="diagnostics" hidden>
                    <h2><?php echo esc_html__('Käyttöönotto ja järjestelmätesti', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Tarkista nopeasti, että WP Sanaseppä on käyttövalmis. Perustesti ei tee OpenAI-pyyntöä. API-yhteystesti tehdään vain erillisestä napista.', 'humantone'); ?></p>
                    <div class="humantone-onboarding-grid">
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Aloita tästä', 'humantone'); ?></h3>
                            <ol class="humantone-help-list">
                                <li><?php echo esc_html__('Lisää OpenAI API -avain API ja malli -välilehdellä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Valitse malli tai kirjoita oma mallinimi.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Täytä vähintään yksi brändiprofiili.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Tarkista käyttörajat ennen suuria käsittelyjä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Suorita testit ja kokeile ensin lyhyellä tekstillä.', 'humantone'); ?></li>
                            </ol>
                        </div>
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Testit', 'humantone'); ?></h3>
                            <p>
                                <button type="button" class="button button-secondary" id="humantone-run-diagnostics"><?php echo esc_html__('Suorita perustesti', 'humantone'); ?></button>
                                <button type="button" class="button button-primary" id="humantone-run-api-test"><?php echo esc_html__('Suorita myös OpenAI-yhteystesti', 'humantone'); ?></button>
                            </p>
                            <p class="description"><?php echo esc_html__('OpenAI-yhteystesti tarkistaa API-avaimen ja mallin saatavuuden. Se ei muokkaa sisältöä.', 'humantone'); ?></p>
                        </div>
                    </div>
                    <div id="humantone-diagnostics-results" class="humantone-diagnostics-results" aria-live="polite"></div>
                    <?php $this->render_beta_diagnostics_dashboard(); ?>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="costs" hidden>
                    <h2><?php echo esc_html__('Kustannusseuranta', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Seuranta perustuu OpenAI:n palauttamiin token-määriin. Jos käytät AI Provider -konnektoria, token-dataa ei aina saada lisäosan käyttöön, jolloin kulutus voi näkyä vajaana.', 'humantone'); ?></p>
                    <?php $this->render_cost_dashboard(); ?>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="export-import" hidden>
                    <h2><?php echo esc_html__('Asetusten vienti ja tuonti', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Vie brändiprofiilit, mallivalinta ja käyttörajat toiselle sivustolle. API-avainta ei sisällytetä vientiin tietoturvasyistä.', 'humantone'); ?></p>

                    <div class="humantone-onboarding-grid">
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Vie asetukset', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Lataa JSON-tiedosto, jonka voit tuoda toiselle WordPress-sivustolle.', 'humantone'); ?></p>
                            <p>
                                <a class="button button-secondary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=humantone_export_settings'), 'humantone_export_settings')); ?>">
                                    <?php echo esc_html__('Lataa asetukset JSON-tiedostona', 'humantone'); ?>
                                </a>
                            </p>
                            <p class="description"><?php echo esc_html__('Vienti sisältää brändiprofiilit, oletusprofiilin, mallin ja käyttörajat. API-avain jätetään pois.', 'humantone'); ?></p>
                        </div>

                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Tuo asetukset', 'humantone'); ?></h3>
                            <p><?php echo esc_html__('Liitä aiemmin viedyn JSON-tiedoston sisältö tähän. Tuonti korvaa brändiprofiilit, oletusprofiilin, mallin ja käyttörajat.', 'humantone'); ?></p>
                            <textarea form="humantone-import-settings-form" name="humantone_import_json" rows="10" class="large-text code" placeholder="<?php echo esc_attr__('Liitä WP Sanasepän vienti-JSON tähän', 'humantone'); ?>"></textarea>
                            <p>
                                <button form="humantone-import-settings-form" type="submit" class="button button-primary" onclick="return window.confirm('<?php echo esc_js(__('Tuonti korvaa nykyiset brändiprofiilit, mallivalinnan ja käyttörajat. API-avain säilyy ennallaan. Jatketaanko?', 'humantone')); ?>');">
                                    <?php echo esc_html__('Tuo asetukset', 'humantone'); ?>
                                </button>
                            </p>
                        </div>
                    </div>
                </section>

                <section class="humantone-settings-panel humantone-card" data-humantone-settings-panel="help" hidden>
                    <h2><?php echo esc_html__('Käyttöohje ja parhaat käytännöt', 'humantone'); ?></h2>
                    <p><?php echo esc_html__('Tämä välilehti kokoaa tärkeimmät ohjeet asetusten tekemiseen. Alla olevilla linkeillä pääset suoraan oikeisiin asetuksiin ja työkaluihin.', 'humantone'); ?></p>
                    <p class="humantone-guide-actions">
                        <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api')); ?>"><?php echo esc_html__('API ja malli', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=profiles')); ?>"><?php echo esc_html__('Brändiprofiilit', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=diagnostics')); ?>"><?php echo esc_html__('Testit', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=safety')); ?>"><?php echo esc_html__('Turvallinen tallennus', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=guide')); ?>"><?php echo esc_html__('Työkalujen käyttöopas', 'humantone'); ?></a>
                    </p>

                    <div class="humantone-guide-grid">
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Peruskäyttöönotto', 'humantone'); ?></h3>
                            <ol class="humantone-help-list">
                                <li><?php echo esc_html__('Lisää OpenAI API -avain API ja malli -välilehdellä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Valitse malli pudotusvalikosta tai kirjoita oma mallinimi.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Luo vähintään yksi brändiprofiili ohjatusti tai käsin.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Suorita perustesti ja tarvittaessa OpenAI-yhteystesti.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Kokeile ensin lyhyellä tekstillä ennen kokonaisia artikkeleita.', 'humantone'); ?></li>
                            </ol>
                            <p class="humantone-guide-actions">
                                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api')); ?>"><?php echo esc_html__('Avaa API-asetukset', 'humantone'); ?></a>
                                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=diagnostics')); ?>"><?php echo esc_html__('Avaa testit', 'humantone'); ?></a>
                            </p>
                        </div>
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Hyvä brändiprofiili', 'humantone'); ?></h3>
                            <ul class="humantone-help-list">
                                <li><?php echo esc_html__('Kuvaa kohdeyleisö konkreettisesti: kenelle teksti puhuu?', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Kerro, onko tyyli rento, asiantunteva, myyvä vai neutraali.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Lisää vältettävät sanat ja fraasit, etenkin tekoälymäiset ilmaisut.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Anna lyhyt tyyliesimerkki, joka kuulostaa aidosti oikealta brändiltä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Älä liitä arkaluontoista dataa tyyliesimerkkiin.', 'humantone'); ?></li>
                            </ul>
                            <p class="humantone-guide-actions"><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=profiles')); ?>"><?php echo esc_html__('Avaa brändiprofiilit', 'humantone'); ?></a></p>
                        </div>
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Turvallinen tallennus', 'humantone'); ?></h3>
                            <ul class="humantone-help-list">
                                <li><?php echo esc_html__('Pidä suojaukset päällä, jos muokkaat kokonaisia artikkeleita, sivuja tai tuotteita.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Käytä uutena luonnoksena tallentamista aina, kun sivulla on monimutkaista rakennetta.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Sivunrakentajilla tehdyt sivut kannattaa tarkistaa erityisen huolellisesti.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Palautuspiste tallennetaan ennen alkuperäisen sisällön korvaamista.', 'humantone'); ?></li>
                            </ul>
                            <p class="humantone-guide-actions"><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=safety')); ?>"><?php echo esc_html__('Avaa turvallisen tallennuksen asetukset', 'humantone'); ?></a></p>
                        </div>
                        <div class="humantone-card humantone-card-inner">
                            <h3><?php echo esc_html__('Yleisimmät ongelmat', 'humantone'); ?></h3>
                            <ul class="humantone-help-list">
                                <li><?php echo esc_html__('Jos muokkaus ei toimi, tarkista ensin API-avain ja malli järjestelmätestillä.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Jos palvelin estää ulkoiset yhteydet, OpenAI-yhteystesti epäonnistuu.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Jos tallennus estetään, tarkista suojattujen elementtien varoitukset.', 'humantone'); ?></li>
                                <li><?php echo esc_html__('Jos WooCommerce-välilehti ei näytä tuotteita, varmista että WooCommerce on käytössä.', 'humantone'); ?></li>
                            </ul>
                            <p class="humantone-guide-actions">
                                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=diagnostics')); ?>"><?php echo esc_html__('Avaa käyttöönotto ja testit', 'humantone'); ?></a>
                                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api-guide')); ?>"><?php echo esc_html__('Avaa API-avaimen ohje', 'humantone'); ?></a>
                            </p>
                        </div>
                    </div>

                    <p><a class="button button-secondary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=guide')); ?>"><?php echo esc_html__('Avaa WP Sanasepän työkalukohtainen käyttöopas', 'humantone'); ?></a></p>
                    <p class="description"><?php echo esc_html__('Tämä välilehti ei sisällä tallennettavia asetuksia.', 'humantone'); ?></p>
                </section>

                <?php submit_button(__('Tallenna asetukset', 'humantone')); ?>
            </form>
            <form id="humantone-license-action-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:none;">
                <input type="hidden" name="humantone_license_nonce" value="<?php echo esc_attr(wp_create_nonce('humantone_license_action')); ?>" />
            </form>
            <form id="humantone-import-settings-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('humantone_import_settings'); ?>
                <input type="hidden" name="action" value="humantone_import_settings" />
            </form>
            <form id="humantone-api-settings-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:none;">
                <?php wp_nonce_field('humantone_save_api_settings'); ?>
                <input type="hidden" name="action" value="humantone_save_api_settings" />
                <input type="hidden" name="<?php echo esc_attr(self::OPTION_NAME); ?>[api_source]" id="humantone-api-save-source" value="" />
                <input type="hidden" name="<?php echo esc_attr(self::OPTION_NAME); ?>[api_key]" id="humantone-api-save-key" value="" />
                <input type="hidden" name="<?php echo esc_attr(self::OPTION_NAME); ?>[model]" id="humantone-api-save-model" value="" />
                <input type="hidden" name="<?php echo esc_attr(self::OPTION_NAME); ?>[custom_model]" id="humantone-api-save-custom-model" value="" />
            </form>
            <script>
            window.humantoneSettingsDiagnostics = {
                endpoint: <?php echo wp_json_encode(rest_url('humantone/v1/diagnostics')); ?>,
                nonce: <?php echo wp_json_encode(wp_create_nonce('wp_rest')); ?>
            };
            (function () {
                function activateSettingsTab(tab) {
                    document.querySelectorAll('[data-humantone-settings-tab]').forEach(function (button) {
                        var isActive = button.getAttribute('data-humantone-settings-tab') === tab;
                        button.classList.toggle('nav-tab-active', isActive);
                        button.setAttribute('aria-selected', isActive ? 'true' : 'false');
                    });
                    document.querySelectorAll('[data-humantone-settings-panel]').forEach(function (panel) {
                        var isActive = panel.getAttribute('data-humantone-settings-panel') === tab;
                        panel.hidden = !isActive;
                    });
                    try { window.localStorage.setItem('humantone_active_settings_tab', tab); } catch (e) {}
                }
                document.querySelectorAll('[data-humantone-settings-tab]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        activateSettingsTab(button.getAttribute('data-humantone-settings-tab'));
                    });
                });
                var stored = '';
                try { stored = window.localStorage.getItem('humantone_active_settings_tab') || ''; } catch (e) {}
                var urlTab = '';
                try { urlTab = new URLSearchParams(window.location.search).get('tab') || ''; } catch (e) {}
                activateSettingsTab(urlTab || stored || 'onboarding');

                document.querySelectorAll('[data-humantone-jump-tab]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        activateSettingsTab(button.getAttribute('data-humantone-jump-tab'));
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    });
                });

                function wizardValue(id) {
                    var el = document.getElementById(id);
                    return el ? String(el.value || '').trim() : '';
                }

                function wizardSet(selector, value) {
                    var el = document.querySelector(selector);
                    if (el) {
                        el.value = value;
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }

                function buildWizardVoice(tone, addressing) {
                    var toneText = {
                        selkea: 'Selkeä, lämmin ja asiantunteva suomen kieli. Vältä ylisanoja, tyhjää markkinointipuhetta ja liian tekoälymäistä rytmiä.',
                        rento: 'Rento, lämmin ja helposti lähestyttävä suomen kieli. Kirjoita kuin asiantunteva ihminen, älä kuin mainosesite.',
                        myyva: 'Myyvä mutta hillitty suomen kieli. Nosta hyödyt esiin konkreettisesti ilman liioittelua tai painostavaa sävyä.',
                        asiantuntija: 'Asiantuntijamainen, täsmällinen ja luotettava suomen kieli. Perustele selkeästi, vältä ylisanoja ja säilytä ammattimainen tyyli.'
                    }[tone] || '';
                    var addressingText = {
                        sinuttele: 'Puhuttele lukijaa luontevasti sinä-muodossa silloin, kun se sopii lauseeseen.',
                        neutraali: 'Pidä puhuttelu neutraalina ja vältä tarpeetonta sinuttelua tai teitittelyä.',
                        teitittele: 'Käytä tarvittaessa kohteliasta teitittelyä, mutta älä tee tekstistä kankeaa.'
                    }[addressing] || '';
                    return (toneText + ' ' + addressingText).trim();
                }

                var createProfileButton = document.getElementById('humantone-create-first-profile');
                if (createProfileButton) {
                    createProfileButton.addEventListener('click', function () {
                        var brandName = wizardValue('humantone-wizard-brand-name') || 'Ensimmäinen brändiprofiili';
                        var audience = wizardValue('humantone-wizard-audience') || 'Suomenkieliset asiakkaat ja verkkosivukävijät.';
                        var tone = wizardValue('humantone-wizard-tone') || 'selkea';
                        var addressing = wizardValue('humantone-wizard-addressing') || 'sinuttele';
                        var banned = wizardValue('humantone-wizard-banned') || 'mullistava, huipputason, seuraavan sukupolven, kattava opas, sukella aiheeseen';
                        var example = wizardValue('humantone-wizard-example');
                        var message = document.getElementById('humantone-wizard-message');
                        var exampleField = document.getElementById('humantone-wizard-example');
                        if (!example) {
                            if (message) {
                                message.className = 'humantone-wizard-message notice notice-error inline';
                                message.innerHTML = '<p><?php echo esc_js(__('Lisää ensin lyhyt tyyliesimerkki. Se on pakollinen tieto ensimmäisen brändiprofiilin ohjatussa luonnissa.', 'humantone')); ?></p>';
                            }
                            if (exampleField) {
                                exampleField.classList.add('humantone-field-error');
                                exampleField.focus();
                            }
                            return;
                        }
                        if (exampleField) {
                            exampleField.classList.remove('humantone-field-error');
                        }
                        var voice = buildWizardVoice(tone, addressing);

                        wizardSet('.humantone-profile-name-field[data-humantone-profile-index="0"]', brandName);
                        wizardSet('.humantone-profile-audience-field[data-humantone-profile-index="0"]', audience);
                        wizardSet('.humantone-profile-voice-field[data-humantone-profile-index="0"]', voice);
                        wizardSet('.humantone-profile-banned-field[data-humantone-profile-index="0"]', banned);
                        wizardSet('.humantone-profile-example-field[data-humantone-profile-index="0"]', example);

                        if (message) {
                            message.className = 'humantone-wizard-message notice notice-success inline';
                            message.innerHTML = '<p><?php echo esc_js(__('Ensimmäinen brändiprofiili täytettiin. Tarkista tiedot Brändiprofiilit-välilehdellä ja paina lopuksi Tallenna asetukset.', 'humantone')); ?></p>';
                        }
                        activateSettingsTab('profiles');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    });
                }

                function escapeHtml(value) {
                    return String(value || '').replace(/[&<>"']/g, function (char) {
                        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char];
                    });
                }

                function renderApiTestCard(data) {
                    // The diagnostics status element only exists on the Testit panel in some layouts.
                    // The API overview card must still update when the test is started from the
                    // API ja malli tab, so update the overview before touching the diagnostics card.
                    if (!data || !data.api_test) { return; }
                    updateApiOverview(data);
                    var card = document.getElementById('humantone-api-test-status');
                    if (!card) { return; }
                    var status = data.api_test.status || 'not_tested';
                    var labelMap = {
                        ok: '<?php echo esc_js(__('Toimii', 'humantone')); ?>',
                        fail: '<?php echo esc_js(__('Ei toimi', 'humantone')); ?>',
                        not_tested: '<?php echo esc_js(__('Ei vielä testattu', 'humantone')); ?>',
                        not_run: '<?php echo esc_js(__('Ei vielä testattu', 'humantone')); ?>'
                    };
                    card.className = 'humantone-api-test-status humantone-api-test-status-' + escapeHtml(status);
                    var html = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> ';
                    html += '<span class="humantone-api-test-label">' + escapeHtml(labelMap[status] || status) + '</span><br />';
                    html += '<span class="humantone-api-test-message">' + escapeHtml(data.api_test.message || '') + '</span>';
                    if (data.generated_at) {
                        html += '<br /><span class="description humantone-api-test-time"><?php echo esc_js(__('Viimeksi testattu:', 'humantone')); ?> ' + escapeHtml(data.generated_at) + '</span>';
                    }
                    if (data.api_test.model) {
                        html += '<br /><span class="description humantone-api-test-model"><?php echo esc_js(__('Testattu malli:', 'humantone')); ?> ' + escapeHtml(data.api_test.model) + '</span>';
                    }
                    if (data.api_test.source) {
                        html += '<br /><span class="description humantone-api-test-source"><?php echo esc_js(__('API-lähde:', 'humantone')); ?> ' + escapeHtml(data.api_test.source) + '</span>';
                    }
                    card.innerHTML = html;
                }

                function updateApiOverview(data) {
                    var overview = document.getElementById('humantone-api-overview');
                    if (!overview || !data || !data.api_test) { return; }
                    var status = data.api_test.status || 'not_tested';
                    var errorType = data.api_test.error_type || '';
                    var isOk = status === 'ok';
                    var isFail = status === 'fail';
                    overview.className = 'humantone-api-overview ' + (isOk ? 'is-ok' : (isFail ? 'is-fail' : 'is-not-tested')) + ((isFail && (errorType === 'quota' || errorType === 'auth' || errorType === 'model')) ? ' is-blocking' : '');
                    overview.setAttribute('data-status', status);
                    overview.setAttribute('data-error-type', errorType);
                    var icon = overview.querySelector('.humantone-api-overview-icon');
                    if (icon) { icon.textContent = isOk ? '✓' : (isFail ? '!' : '?'); }
                    var title = overview.querySelector('h3');
                    if (title) { title.textContent = isOk ? '<?php echo esc_js(__('OpenAI-yhteys toimii', 'humantone')); ?>' : (isFail ? '<?php echo esc_js(__('OpenAI-yhteys ei toimi', 'humantone')); ?>' : '<?php echo esc_js(__('OpenAI-yhteyttä ei ole vielä testattu', 'humantone')); ?>'); }
                    var lead = overview.querySelector('.humantone-api-overview-lead');
                    if (lead) { lead.textContent = data.api_test.message || ''; }
                    var dds = overview.querySelectorAll('.humantone-api-overview-facts dd');
                    if (dds[0] && data.api_test.model) { dds[0].textContent = data.api_test.model; }
                    if (dds[1] && data.api_test.source) { dds[1].textContent = data.api_test.source; }
                    if (dds[3] && data.generated_at) { dds[3].textContent = data.generated_at; }
                    var warning = overview.querySelector('.humantone-api-overview-warning');
                    if (!warning && isFail && (errorType === 'quota' || errorType === 'auth' || errorType === 'model')) {
                        warning = document.createElement('div');
                        warning.className = 'humantone-api-overview-warning';
                        warning.textContent = '<?php echo esc_js(__('Käsittely on estetty, kunnes tämä virhe on korjattu ja yhteystesti onnistuu.', 'humantone')); ?>';
                        overview.appendChild(warning);
                    } else if (warning && !(isFail && (errorType === 'quota' || errorType === 'auth' || errorType === 'model'))) {
                        warning.parentNode.removeChild(warning);
                    }
                }

                function renderDiagnostics(data) {
                    renderApiTestCard(data);
                    var box = document.getElementById('humantone-diagnostics-results');
                    if (!box) { return; }
                    var html = '<h3><?php echo esc_js(__('Testitulokset', 'humantone')); ?></h3>';
                    html += '<table class="widefat striped humantone-diagnostics-table"><thead><tr><th><?php echo esc_js(__('Tarkistus', 'humantone')); ?></th><th><?php echo esc_js(__('Tila', 'humantone')); ?></th><th><?php echo esc_js(__('Selite', 'humantone')); ?></th></tr></thead><tbody>';
                    (data.items || []).forEach(function (item) {
                        html += '<tr class="humantone-diagnostics-status-' + escapeHtml(item.status) + '"><td><strong>' + escapeHtml(item.label) + '</strong></td><td>' + escapeHtml(item.status) + '</td><td>' + escapeHtml(item.message) + '</td></tr>';
                    });
                    if (data.api_test && data.api_test.run) {
                        html += '<tr class="humantone-diagnostics-status-' + escapeHtml(data.api_test.status) + '"><td><strong><?php echo esc_js(__('OpenAI-yhteystesti', 'humantone')); ?></strong></td><td>' + escapeHtml(data.api_test.status) + '</td><td>' + escapeHtml(data.api_test.message) + '</td></tr>';
                    }
                    html += '</tbody></table>';
                    if (data.generated_at) {
                        html += '<p class="description"><?php echo esc_js(__('Suoritettu:', 'humantone')); ?> ' + escapeHtml(data.generated_at) + '</p>';
                    }
                    box.innerHTML = html;
                }

                function runDiagnostics(runApiTest) {
                    var box = document.getElementById('humantone-diagnostics-results');
                    if (box) {
                        box.innerHTML = '<p><?php echo esc_js(__('Suoritetaan testiä...', 'humantone')); ?></p>';
                    }
                    var config = window.humantoneSettingsDiagnostics || {};
                    return fetch(config.endpoint, {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': config.nonce || ''
                        },
                        body: JSON.stringify({ run_api_test: !!runApiTest })
                    }).then(function (response) {
                        return response.json().then(function (data) {
                            if (!response.ok) {
                                throw new Error(data && data.message ? data.message : '<?php echo esc_js(__('Testi epäonnistui.', 'humantone')); ?>');
                            }
                            return data;
                        });
                    }).then(renderDiagnostics).catch(function (error) {
                        if (box) {
                            box.innerHTML = '<div class="notice notice-error inline"><p>' + escapeHtml(error.message) + '</p></div>';
                        }
                        var card = document.getElementById('humantone-api-test-status');
                        if (card) {
                            card.className = 'humantone-api-test-status humantone-api-test-status-fail';
                            card.innerHTML = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> <span class="humantone-api-test-label"><?php echo esc_js(__('Ei toimi', 'humantone')); ?></span><br /><span class="humantone-api-test-message">' + escapeHtml(error.message) + '</span>';
                        }
                        updateApiOverview({ api_test: { status: 'fail', message: error.message || '<?php echo esc_js(__('Testi epäonnistui.', 'humantone')); ?>' } });
                    });
                }

                var diagnosticsButton = document.getElementById('humantone-run-diagnostics');
                if (diagnosticsButton) {
                    diagnosticsButton.addEventListener('click', function () { runDiagnostics(false); });
                }
                var apiTestButton = document.getElementById('humantone-run-api-test');
                if (apiTestButton) {
                    apiTestButton.addEventListener('click', function () { runDiagnostics(true); });
                }

                var apiOverviewTestButton = document.getElementById('humantone-api-overview-test');
                if (apiOverviewTestButton) {
                    apiOverviewTestButton.addEventListener('click', function () {
                        if (apiTestPreflightFailed()) { return; }
                        apiOverviewTestButton.disabled = true;
                        var oldText = apiOverviewTestButton.textContent;
                        apiOverviewTestButton.textContent = '<?php echo esc_js(__('Testataan...', 'humantone')); ?>';
                        updateApiOverview({ api_test: { status: 'not_tested', message: '<?php echo esc_js(__('Testataan yhteyttä samalla OpenAI-yhteystestillä kuin Testit-välilehdellä...', 'humantone')); ?>' } });
                        var card = document.getElementById('humantone-api-test-status');
                        if (card) {
                            card.className = 'humantone-api-test-status humantone-api-test-status-running';
                            card.innerHTML = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> <?php echo esc_js(__('Testataan...', 'humantone')); ?>';
                        }
                        runDiagnostics(true).finally(function () {
                            apiOverviewTestButton.disabled = false;
                            apiOverviewTestButton.textContent = oldText;
                        });
                    });
                }
                var apiOverviewSaveButton = document.getElementById('humantone-api-overview-save');
                if (apiOverviewSaveButton) {
                    apiOverviewSaveButton.addEventListener('click', function () { submitApiSettings(); });
                }
                
function showApiTestPreflight(message) {
                    // The API test card itself now shows preflight messages.
                    // Keep this helper for older inline hooks, but do not show a duplicate warning box.
                    var box = document.getElementById('humantone-api-test-preflight');
                    if (box) { box.style.display = 'none'; }
                }

                function setApiTestCardStatus(statusClass, label, message) {
                    var card = document.getElementById('humantone-api-test-status');
                    if (card) {
                        card.className = 'humantone-api-test-status humantone-api-test-status-' + statusClass;
                        card.innerHTML = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> <span class="humantone-api-test-label">' + escapeHtml(label) + '</span><br /><span class="humantone-api-test-message">' + escapeHtml(message) + '</span>';
                    }
                    updateApiOverview({ api_test: { status: statusClass === 'ok' ? 'ok' : (statusClass === 'fail' ? 'fail' : 'not_tested'), message: message } });
                }

                function updateApiTestButtonState() {
                    var testButton = document.getElementById('humantone-test-api-key');
                    if (!testButton) { return; }
                    testButton.disabled = false;
                    testButton.classList.remove('disabled');
                    testButton.removeAttribute('aria-disabled');
                    testButton.title = '<?php echo esc_js(__('Testi käyttää tallennettuja API-asetuksia. Jos muutit avainta, tallenna API-asetukset ensin.', 'humantone')); ?>';
                }


                function submitApiSettings() {
                    var form = document.getElementById('humantone-api-settings-form');
                    var sourceField = document.getElementById('humantone-api-source-field');
                    var keyField = document.getElementById('humantone-api-key-field');
                    var modelField = document.getElementById('humantone-model-field');
                    var customModelField = document.getElementById('humantone-custom-model');
                    if (!form || !sourceField || !keyField || !modelField || !customModelField) {
                        var settingsForm = document.querySelector('.humantone-settings-form');
                        if (settingsForm) { settingsForm.submit(); }
                        return;
                    }
                    document.getElementById('humantone-api-save-source').value = sourceField.value || 'auto';
                    document.getElementById('humantone-api-save-key').value = keyField.value || '';
                    document.getElementById('humantone-api-save-model').value = modelField.value || 'gpt-5.4-mini';
                    document.getElementById('humantone-api-save-custom-model').value = customModelField.value || '';
                    form.submit();
                }

                function getSelectedApiSource() {
                    var source = document.getElementById('humantone-api-source-field');
                    return source ? source.value : 'auto';
                }

                function apiTestPreflightFailed() {
                    var cardWrap = document.getElementById('humantone-api-test-card');
                    var keyField = document.getElementById('humantone-api-key-field');
                    var sourceField = document.getElementById('humantone-api-source-field');
                    var overview = document.getElementById('humantone-api-overview');
                    var savedKey = <?php echo !empty(self::get_settings()['api_key']) ? 'true' : 'false'; ?>;
                    var providerAvailable = <?php echo (class_exists('HumanTone_AI_Client') && HumanTone_AI_Client::is_openai_provider_available()) ? 'true' : 'false'; ?>;
                    var typedKey = keyField && keyField.value && keyField.value.trim().length > 0;
                    var source = getSelectedApiSource();

                    if (!providerAvailable && source === 'provider') {
                        setApiTestCardStatus('not_tested', '<?php echo esc_js(__('Odottaa asetusta', 'humantone')); ?>', '<?php echo esc_js(__('AI Provider for OpenAI -konnektoria ei ole käytettävissä tällä sivustolla. Vaihda API-lähteeksi Automaattinen tai WP Sanasepän oma API-avain, tallenna asetukset ja testaa sen jälkeen.', 'humantone')); ?>');
                        if (sourceField) { sourceField.focus(); }
                        return true;
                    }

                    if (!savedKey && typedKey && (source === 'own' || source === 'auto' || !providerAvailable)) {
                        setApiTestCardStatus('not_tested', '<?php echo esc_js(__('Odottaa tallennusta', 'humantone')); ?>', '<?php echo esc_js(__('API-avain on kirjoitettu kenttään, mutta sitä ei ole vielä tallennettu. Paina Tallenna API-asetukset ja suorita testi sen jälkeen.', 'humantone')); ?>');
                        updateApiTestButtonState();
                        var submit = document.querySelector('.humantone-settings-form input[type="submit"], .humantone-settings-form button[type="submit"], .wrap input[type="submit"]');
                        if (submit) { submit.focus(); }
                        return true;
                    }

                    if (!savedKey && !providerAvailable) {
                        setApiTestCardStatus('not_tested', '<?php echo esc_js(__('Ei vielä testattu', 'humantone')); ?>', '<?php echo esc_js(__('Lisää OpenAI API -avain, tallenna API-asetukset ja suorita testi sen jälkeen.', 'humantone')); ?>');
                        updateApiTestButtonState();
                        if (keyField) { keyField.focus(); }
                        return true;
                    }

                    showApiTestPreflight('');
                    updateApiTestButtonState();
                    return false;
                }

                function markApiTestNeedsSave() {
                    var cardWrap = document.getElementById('humantone-api-test-card');
                    var keyField = document.getElementById('humantone-api-key-field');
                    var card = document.getElementById('humantone-api-test-status');
                    if (!keyField) { return; }
                    var savedKey = <?php echo !empty(self::get_settings()['api_key']) ? 'true' : 'false'; ?>;
                    var typedKey = keyField.value && keyField.value.trim().length > 0;
                    if (!savedKey && typedKey) {
                        if (card) {
                            card.className = 'humantone-api-test-status humantone-api-test-status-not_tested';
                            card.innerHTML = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> <span class="humantone-api-test-label"><?php echo esc_js(__('Odottaa tallennusta', 'humantone')); ?></span><br /><span class="humantone-api-test-message"><?php echo esc_js(__('API-avain on kirjoitettu kenttään, mutta sitä ei ole vielä tallennettu. Paina Tallenna API-asetukset ja suorita testi sen jälkeen.', 'humantone')); ?></span>';
                        }
                        updateApiOverview({ api_test: { status: 'not_tested', message: '<?php echo esc_js(__('API-avain on kirjoitettu kenttään, mutta sitä ei ole vielä tallennettu. Paina Tallenna API-asetukset ja suorita testi sen jälkeen.', 'humantone')); ?>' } });
                        showApiTestPreflight('');
                        updateApiTestButtonState();
                    }
                }

                var saveApiSettingsButton = document.getElementById('humantone-save-api-settings');
                if (saveApiSettingsButton) {
                    saveApiSettingsButton.addEventListener('click', function () {
                        submitApiSettings();
                    });
                }

                var keyFieldForTest = document.getElementById('humantone-api-key-field');
                if (keyFieldForTest) {
                    keyFieldForTest.addEventListener('input', markApiTestNeedsSave);
                    keyFieldForTest.addEventListener('change', markApiTestNeedsSave);
                    markApiTestNeedsSave();
                    updateApiTestButtonState();
                } else {
                    updateApiTestButtonState();
                }

                var apiKeyTestButton = document.getElementById('humantone-test-api-key');
                if (apiKeyTestButton) {
                    apiKeyTestButton.addEventListener('click', function () {
                        if (apiKeyTestButton.disabled) { return; }
                        if (apiTestPreflightFailed()) { return; }
                        var card = document.getElementById('humantone-api-test-status');
                        if (card) {
                            card.className = 'humantone-api-test-status humantone-api-test-status-running';
                            card.innerHTML = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> <?php echo esc_js(__('Testataan...', 'humantone')); ?>';
                        }
                        runDiagnostics(true);
                    });
                }

                function maybeAutoTestConnector() {
                    var cardWrap = document.getElementById('humantone-api-test-card');
                    var sourceField = document.getElementById('humantone-api-source-field');
                    var keyField = document.getElementById('humantone-api-key-field');
                    var card = document.getElementById('humantone-api-test-status');
                    if (!cardWrap || !card) { return; }

                    var providerAvailable = cardWrap.getAttribute('data-provider-available') === '1';
                    var savedKey = cardWrap.getAttribute('data-saved-api-key') === '1';
                    var currentStatus = cardWrap.getAttribute('data-current-status') || '';
                    var selectedSource = sourceField ? sourceField.value : 'auto';
                    var typedKey = keyField && keyField.value && keyField.value.trim().length > 0;
                    var shouldUseConnector = providerAvailable && !savedKey && !typedKey && (selectedSource === 'auto' || selectedSource === 'provider' || selectedSource === 'own');

                    if (!shouldUseConnector || currentStatus === 'ok') { return; }

                    card.className = 'humantone-api-test-status humantone-api-test-status-running';
                    card.innerHTML = '<strong><?php echo esc_js(__('Tila:', 'humantone')); ?></strong> <?php echo esc_js(__('Konnektori havaittu. Testataan yhteyttä automaattisesti...', 'humantone')); ?>';
                    window.setTimeout(function () { runDiagnostics(true); }, 600);
                }

                maybeAutoTestConnector();
            }());
            </script>
        </div>
        <?php
    }
}
