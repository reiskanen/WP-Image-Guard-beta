<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_Tools {
    private $page_hook = '';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_tools_page'), 9);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function add_tools_page() {
        $this->page_hook = add_menu_page(
            __('WP Sanaseppä - tekstityökalu', 'humantone'),
            __('WP Sanaseppä', 'humantone'),
            'edit_posts',
            'wp-sanaseppa',
            array($this, 'render_tools_page'),
            'dashicons-edit-page',
            58
        );

        add_submenu_page(
            'wp-sanaseppa',
            __('WP Sanaseppä - tekstityökalu', 'humantone'),
            __('Tekstityökalu', 'humantone'),
            'edit_posts',
            'wp-sanaseppa',
            array($this, 'render_tools_page')
        );
    }

    public function enqueue_assets($hook_suffix) {
        if ($hook_suffix !== $this->page_hook) {
            return;
        }

        wp_enqueue_style(
            'humantone-admin',
            HUMANTONE_PLUGIN_URL . 'assets/admin.css',
            array(),
            HUMANTONE_VERSION
        );

        wp_enqueue_script(
            'humantone-admin',
            HUMANTONE_PLUGIN_URL . 'assets/admin.js',
            array(),
            HUMANTONE_VERSION,
            true
        );

        wp_localize_script('humantone-admin', 'HumanToneTool', array(
            'restUrl' => esc_url_raw(rest_url('humantone/v1/rewrite')),
            'postsUrl' => esc_url_raw(rest_url('humantone/v1/posts')),
            'postUrlBase' => esc_url_raw(rest_url('humantone/v1/post/')),
            'bulkUrl' => esc_url_raw(rest_url('humantone/v1/bulk/rewrite')),
            'bulkJobUrl' => esc_url_raw(rest_url('humantone/v1/bulk/jobs')),
            'bulkLastJobUrl' => esc_url_raw(rest_url('humantone/v1/bulk/jobs/last')),
            'productsUrl' => esc_url_raw(rest_url('humantone/v1/products')),
            'productUrlBase' => esc_url_raw(rest_url('humantone/v1/product/')),
            'productSaveUrlSuffix' => '/save',
            'postSaveUrlSuffix' => '/save',
            'historyUrl' => esc_url_raw(rest_url('humantone/v1/history')),
            'historyRestoreSuffix' => '/restore',
            'historyPruneSuffix' => '/prune',
            'nonce' => wp_create_nonce('wp_rest'),
            'profiles' => HumanTone_Settings::get_profile_options(),
            'defaultProfile' => HumanTone_Settings::get_default_profile_id(),
            'limits' => HumanTone_Settings::get_limits(),
            'safety' => HumanTone_Settings::get_safety(),
            'apiStatus' => array(
                'blocking' => HumanTone_Settings::is_api_status_blocking(),
                'message' => HumanTone_Settings::get_api_status_notice_message(),
                'settingsUrl' => esc_url_raw(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api')),
            ),
            'license' => array(
                'mode' => HumanTone_License::get_mode_label(),
                'isPro' => HumanTone_License::is_pro_enabled(),
                'status' => HumanTone_License::get_status_code(),
                'message' => HumanTone_License::get_status_message(),
                'proUnavailableMessage' => HumanTone_License::get_pro_unavailable_message(),
                'licenseUrl' => esc_url_raw(admin_url('admin.php?page=wp-sanaseppa-settings&tab=license')),
            ),
            'messages' => array(
                'emptyText' => __('Lisää ensin muokattava teksti.', 'humantone'),
                'working' => __('Muokataan tekstiä...', 'humantone'),
                'loadingPosts' => __('Haetaan julkaisuja...', 'humantone'),
                'loadingPost' => __('Haetaan sisältöä...', 'humantone'),
                'workingPost' => __('Muokataan koko sisältöä. Pitkä artikkeli voi vaatia useita API-kutsuja...', 'humantone'),
                'savingPost' => __('Tallennetaan muokattua versiota...', 'humantone'),
                'failed' => __('Tekstin muokkaus epäonnistui.', 'humantone'),
                'copied' => __('Ehdotus kopioitu leikepöydälle.', 'humantone'),
                'selectPost' => __('Valitse ensin artikkeli tai sivu.', 'humantone'),
                'confirmUpdate' => __('Tämä korvaa alkuperäisen julkaisun sisällön. Varmista, että vertailu on tarkistettu. Jatketaanko?', 'humantone'),
                'noPosts' => __('Julkaisuja ei löytynyt.', 'humantone'),
                'bulkWorking' => __('Joukkokäsitellään sisältöjä. Tämä voi tehdä useita API-kutsuja...', 'humantone'),
                'bulkSelect' => __('Valitse vähintään yksi sisältö joukkokäsittelyyn.', 'humantone'),
                'bulkLimit' => sprintf(__('Valitse enintään %d sisältöä kerralla.', 'humantone'), HumanTone_Settings::get_limit('bulk_max_items')),
                'loadingProducts' => __('Haetaan tuotteita...', 'humantone'),
                'selectProduct' => __('Valitse ensin tuote.', 'humantone'),
                'workingProduct' => __('Muokataan tuotekuvausta...', 'humantone'),
                'savingProduct' => __('Tallennetaan tuotekuvausta...', 'humantone'),
                'confirmProductUpdate' => __('Tämä päivittää alkuperäisen tuotteen kuvauksen. Tarkista tuotetiedot ennen jatkamista. Jatketaanko?', 'humantone'),
                'loadingHistory' => __('Haetaan historiaa...', 'humantone'),
                'confirmRestore' => __('Tämä palauttaa alkuperäisen version valittuun sisältöön. Jatketaanko?', 'humantone'),
                'confirmPruneHistory' => __('Tämä poistaa vanhimmat historiarivit pysyvästi ja säilyttää vain viimeisimmät valitun määrän. Jatketaanko?', 'humantone'),
            ),
        ));
    }


    private function render_beta_check_item($label, $status, $message, $action_url = '', $action_label = '') {
        $status = sanitize_key($status);
        if (!in_array($status, array('ok', 'warning', 'fail', 'info'), true)) {
            $status = 'info';
        }
        $labels = array(
            'ok' => __('Kunnossa', 'humantone'),
            'warning' => __('Tarkista', 'humantone'),
            'fail' => __('Vaatii korjausta', 'humantone'),
            'info' => __('Tieto', 'humantone'),
        );
        ?>
        <li class="humantone-beta-check-item humantone-beta-check-<?php echo esc_attr($status); ?>">
            <div class="humantone-beta-check-main">
                <span class="humantone-beta-check-icon" aria-hidden="true"></span>
                <div>
                    <strong><?php echo esc_html($label); ?></strong>
                    <p><?php echo esc_html($message); ?></p>
                </div>
            </div>
            <div class="humantone-beta-check-side">
                <span class="humantone-beta-status-pill"><?php echo esc_html($labels[$status]); ?></span>
                <?php if ($action_url && $action_label) : ?>
                    <a class="button button-small" href="<?php echo esc_url($action_url); ?>"><?php echo esc_html($action_label); ?></a>
                <?php endif; ?>
            </div>
        </li>
        <?php
    }

    private function render_beta_checklist_panel() {
        $settings = HumanTone_Settings::get_settings();
        $api_status = HumanTone_Settings::get_api_test_status();
        $api_status_key = isset($api_status['status']) ? sanitize_key($api_status['status']) : 'not_tested';
        $api_message = isset($api_status['message']) ? (string) $api_status['message'] : '';
        $has_own_api_key = !empty($settings['api_key']);
        $provider_available = class_exists('HumanTone_AI_Client') && HumanTone_AI_Client::is_openai_provider_available();
        $effective_api_ready = $has_own_api_key || $provider_available;
        $license_status = class_exists('HumanTone_License') ? HumanTone_License::get_status() : array('status' => 'missing', 'message' => __('Lisenssitietoa ei voitu lukea.', 'humantone'));
        $is_pro = class_exists('HumanTone_License') && HumanTone_License::is_pro_enabled();
        $profiles = HumanTone_Settings::get_profiles();
        $limits = HumanTone_Settings::get_limits();
        $safety = HumanTone_Settings::get_safety();
        $rest_base = rest_url('humantone/v1/');
        $locale = get_locale();
        $language_label = (strpos($locale, 'fi') === 0) ? __('suomi', 'humantone') : __('muu kuin suomi', 'humantone');
        $diagnostics = HumanTone_Settings::get_environment_diagnostics();
        $logs = HumanTone_Settings::get_beta_log(1);
        $last_log = !empty($logs[0]) && is_array($logs[0]) ? $logs[0] : array();
        ?>
        <div class="humantone-section humantone-card" data-humantone-tool-panel="beta" hidden>
            <h2><?php echo esc_html__('Beta-tarkistuslista', 'humantone'); ?></h2>
            <p><?php echo esc_html__('Tarkista tästä ennen betatestausta, ovatko tärkeimmät käyttöönoton kohdat kunnossa. Lista ei muuta asetuksia, vaan ohjaa oikeisiin paikkoihin.', 'humantone'); ?></p>

            <div class="humantone-beta-summary-grid">
                <div class="humantone-card humantone-card-inner">
                    <h3><?php echo esc_html__('Käyttövalmius', 'humantone'); ?></h3>
                    <p class="humantone-beta-big-status <?php echo ($effective_api_ready && 'ok' === $api_status_key && $is_pro) ? 'is-ok' : 'is-warning'; ?>">
                        <?php echo ($effective_api_ready && 'ok' === $api_status_key && $is_pro) ? esc_html__('Valmis betatestaukseen', 'humantone') : esc_html__('Vaatii vielä tarkistuksia', 'humantone'); ?>
                    </p>
                    <p class="description"><?php echo esc_html__('Suositus: testaa ensin yhdellä artikkelilla, sitten pienellä joukkokäsittelyerällä.', 'humantone'); ?></p>
                </div>
                <div class="humantone-card humantone-card-inner">
                    <h3><?php echo esc_html__('Ympäristö', 'humantone'); ?></h3>
                    <ul class="humantone-beta-mini-list">
                        <li><?php echo esc_html(sprintf(__('WordPress %s', 'humantone'), isset($diagnostics['wordpress_version']) ? $diagnostics['wordpress_version'] : '-')); ?></li>
                        <li><?php echo esc_html(sprintf(__('PHP %s', 'humantone'), PHP_VERSION)); ?></li>
                        <li><?php echo esc_html(sprintf(__('Sivuston kieli: %s (%s)', 'humantone'), $language_label, $locale)); ?></li>
                    </ul>
                </div>
                <div class="humantone-card humantone-card-inner">
                    <h3><?php echo esc_html__('Viimeisin tekninen huomio', 'humantone'); ?></h3>
                    <?php if (!empty($last_log)) : ?>
                        <p><strong><?php echo esc_html(isset($last_log['status']) ? $last_log['status'] : 'info'); ?>:</strong> <?php echo esc_html(isset($last_log['message']) ? $last_log['message'] : ''); ?></p>
                        <p class="description"><?php echo esc_html(isset($last_log['time']) ? $last_log['time'] : ''); ?></p>
                    <?php else : ?>
                        <p><?php echo esc_html__('Ei beta-lokin merkintöjä.', 'humantone'); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <ul class="humantone-beta-checklist">
                <?php
                $this->render_beta_check_item(
                    __('API-avain tai palveluntarjoajan yhteys', 'humantone'),
                    $effective_api_ready ? 'ok' : 'fail',
                    $effective_api_ready ? __('API-yhteyden lähde on käytettävissä.', 'humantone') : __('Lisää oma API-avain tai varmista, että palveluntarjoajan API-yhteys on käytettävissä.', 'humantone'),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=api'),
                    __('Avaa API-asetukset', 'humantone')
                );
                $this->render_beta_check_item(
                    __('OpenAI-yhteystesti', 'humantone'),
                    ('ok' === $api_status_key) ? 'ok' : (('fail' === $api_status_key) ? 'fail' : 'warning'),
                    ('ok' === $api_status_key) ? __('Yhteystesti on onnistunut.', 'humantone') : ($api_message ?: __('Yhteyttä ei ole vielä testattu.', 'humantone')),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=api'),
                    __('Testaa yhteys', 'humantone')
                );
                $this->render_beta_check_item(
                    __('Lisenssi ja Pro-toiminnot', 'humantone'),
                    $is_pro ? 'ok' : 'warning',
                    $is_pro ? __('Pro-toiminnot ovat käytettävissä.', 'humantone') : (isset($license_status['message']) ? $license_status['message'] : __('Lisenssi ei ole aktiivinen.', 'humantone')),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=license'),
                    __('Avaa lisenssi', 'humantone')
                );
                $this->render_beta_check_item(
                    __('Käyttäjäoikeudet', 'humantone'),
                    HumanTone_Settings::current_user_can_use_ai() ? 'ok' : 'fail',
                    HumanTone_Settings::current_user_can_use_ai() ? __('Nykyisellä käyttäjällä on oikeus käyttää AI-työkaluja.', 'humantone') : __('Nykyisellä käyttäjällä ei ole asetuksissa vaadittua käyttöoikeutta.', 'humantone'),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=general'),
                    __('Avaa yleisasetukset', 'humantone')
                );
                $this->render_beta_check_item(
                    __('Brändiprofiilit', 'humantone'),
                    count($profiles) > 0 ? 'ok' : 'warning',
                    count($profiles) > 0 ? sprintf(_n('%d brändiprofiili käytettävissä.', '%d brändiprofiilia käytettävissä.', count($profiles), 'humantone'), count($profiles)) : __('Lisää vähintään yksi brändiprofiili, jotta testitulokset ovat tasaisia.', 'humantone'),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=profiles'),
                    __('Avaa profiilit', 'humantone')
                );
                $safe_flags = array('block_structure_loss', 'block_thumbnail_loss', 'block_taxonomy_loss', 'block_seo_meta_loss', 'block_acf_meta_loss', 'block_page_builder_overwrite');
                $safe_on = 0;
                foreach ($safe_flags as $flag) {
                    if (!empty($safety[$flag])) {
                        $safe_on++;
                    }
                }
                $this->render_beta_check_item(
                    __('Turva-asetukset', 'humantone'),
                    $safe_on >= 4 ? 'ok' : 'warning',
                    sprintf(__('Tärkeitä suoja-asetuksia käytössä: %1$d / %2$d.', 'humantone'), $safe_on, count($safe_flags)),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=safety'),
                    __('Avaa turva-asetukset', 'humantone')
                );
                $bulk_max = isset($limits['bulk_max_items']) ? absint($limits['bulk_max_items']) : 0;
                $this->render_beta_check_item(
                    __('Joukkokäsittelyn raja', 'humantone'),
                    ($bulk_max > 0 && $bulk_max <= 20) ? 'ok' : 'warning',
                    $bulk_max > 0 ? sprintf(__('Kerralla käsiteltävien sisältöjen raja on %d.', 'humantone'), $bulk_max) : __('Joukkokäsittelyn rajaa ei voitu lukea.', 'humantone'),
                    admin_url('admin.php?page=wp-sanaseppa-settings&tab=limits'),
                    __('Avaa käyttörajat', 'humantone')
                );
                $this->render_beta_check_item(
                    __('REST API -reitit', 'humantone'),
                    $rest_base ? 'ok' : 'fail',
                    $rest_base ? sprintf(__('REST-reittien perusosoite muodostuu: %s', 'humantone'), $rest_base) : __('REST API -osoitetta ei voitu muodostaa.', 'humantone')
                );
                $this->render_beta_check_item(
                    __('WooCommerce-tuki', 'humantone'),
                    class_exists('WooCommerce') ? 'ok' : 'info',
                    class_exists('WooCommerce') ? __('WooCommerce on aktiivinen, joten tuotetyökalua voi testata.', 'humantone') : __('WooCommerce ei ole aktiivinen. Tuotetyökalua ei tarvitse testata tällä sivustolla.', 'humantone')
                );
                ?>
            </ul>

            <div class="humantone-card humantone-card-inner humantone-guide-wide">
                <h3><?php echo esc_html__('Suositeltu betatestin kulku', 'humantone'); ?></h3>
                <ol class="humantone-help-list">
                    <li><?php echo esc_html__('Tallenna API- ja lisenssiasetukset ja aja yhteystesti.', 'humantone'); ?></li>
                    <li><?php echo esc_html__('Muokkaa yksi lyhyt testiteksti yksittäisen tekstin työkalulla.', 'humantone'); ?></li>
                    <li><?php echo esc_html__('Muokkaa yksi artikkeli tai sivu ja tallenna se uutena luonnoksena.', 'humantone'); ?></li>
                    <li><?php echo esc_html__('Kokeile joukkokäsittelyä ensin 2–3 sisällöllä.', 'humantone'); ?></li>
                    <li><?php echo esc_html__('Tarkista historia ja palautus ennen laajempaa testausta.', 'humantone'); ?></li>
                </ol>
            </div>
        </div>
        <?php
    }

    public function render_tools_page() {
        if (!current_user_can('edit_posts')) {
            return;
        }
        $is_pro = HumanTone_License::is_pro_enabled();
        $license_code = HumanTone_License::get_status_code();
        $pro_unavailable_message = HumanTone_License::get_pro_unavailable_message();
        ?>
        <div class="wrap humantone-tool-wrap">
            <h1><?php echo esc_html__('WP Sanaseppä', 'humantone'); ?></h1>
            <div class="humantone-mode-switch humantone-card-inner">
                <strong><?php echo esc_html__('Olet tekstityökalussa.', 'humantone'); ?></strong>
                <span><?php echo esc_html__('Täällä muokataan yksittäisiä tekstejä, artikkeleita, sivuja ja tuotteita.', 'humantone'); ?></span>
                <?php if (current_user_can('manage_options')) : ?>
                    <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings')); ?>"><?php echo esc_html__('Avaa asetukset', 'humantone'); ?></a>
                <?php endif; ?>
            </div>
            <div id="humantone-message" class="humantone-message" aria-live="polite"></div>
            <?php $api_status = HumanTone_Settings::get_api_test_status(); if (HumanTone_Settings::is_api_status_blocking($api_status)) : ?>
                <div class="notice notice-error humantone-api-global-notice humantone-card-inner">
                    <p><strong><?php echo esc_html__('OpenAI-yhteys vaatii huomiota.', 'humantone'); ?></strong> <?php echo esc_html(HumanTone_Settings::get_api_status_notice_message($api_status)); ?> <?php if (current_user_can('manage_options')) : ?><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api')); ?>"><?php echo esc_html__('Avaa API ja malli', 'humantone'); ?></a><?php endif; ?> <a class="button button-small" href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('OpenAI Billing', 'humantone'); ?></a></p>
                </div>
            <?php endif; ?>
            <?php if (!$is_pro) : ?>
                <div class="humantone-pro-notice humantone-card-inner <?php echo 'expired' === $license_code ? 'humantone-license-expired-notice' : ''; ?>">
                    <strong><?php echo esc_html('expired' === $license_code ? __('Lisenssi on vanhentunut.', 'humantone') : __('Free-tila käytössä.', 'humantone')); ?></strong>
                    <?php echo esc_html('expired' === $license_code ? $pro_unavailable_message : __('Free-versiossa voit muokata yksittäisiä tekstejä, korjata tekoälymäiset otsikot luontevaksi suomeksi ja kokeilla artikkeli-/sivutyökalua demoesikatseluna. Kokonaisen sisällön käyttö, tallennus, joukkokäsittely, WooCommerce ja historia vaativat Pro-lisenssin.', 'humantone')); ?>
                    <a class="button button-primary button-small" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=license')); ?>"><?php echo esc_html('expired' === $license_code ? __('Uusi tai tarkista lisenssi', 'humantone') : __('Lisenssi', 'humantone')); ?></a>
                </div>
            <?php endif; ?>

            <nav class="nav-tab-wrapper humantone-admin-tabs" aria-label="<?php echo esc_attr__('WP Sanaseppä -työkalut', 'humantone'); ?>">
                <button type="button" class="nav-tab nav-tab-active" data-humantone-tool-tab="single"><?php echo esc_html__('Yksittäinen teksti', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-tool-tab="post"><?php echo esc_html__('Artikkeli tai sivu', 'humantone'); ?><?php if (!$is_pro) : ?> <span class="humantone-pro-pill"><?php echo esc_html__('Demo Free', 'humantone'); ?></span><?php endif; ?></button>
                <button type="button" class="nav-tab" data-humantone-tool-tab="bulk"><?php echo esc_html__('Joukkokäsittely', 'humantone'); ?><?php if (!$is_pro) : ?> <span class="humantone-pro-pill">Pro</span><?php endif; ?></button>
                <button type="button" class="nav-tab" data-humantone-tool-tab="product"><?php echo esc_html__('WooCommerce-tuotteet', 'humantone'); ?><?php if (!$is_pro) : ?> <span class="humantone-pro-pill">Pro</span><?php endif; ?></button>
                <button type="button" class="nav-tab" data-humantone-tool-tab="history"><?php echo esc_html__('Historia ja palautus', 'humantone'); ?><?php if (!$is_pro) : ?> <span class="humantone-pro-pill">Pro</span><?php endif; ?></button>
                <button type="button" class="nav-tab" data-humantone-tool-tab="beta"><?php echo esc_html__('Beta-tarkistus', 'humantone'); ?></button>
                <button type="button" class="nav-tab" data-humantone-tool-tab="guide"><?php echo esc_html__('Käyttöopas', 'humantone'); ?></button>
            </nav>

            <?php $this->render_beta_checklist_panel(); ?>

            <div class="humantone-section humantone-card" data-humantone-tool-panel="guide" hidden>
                <h2><?php echo esc_html__('Käyttöopas', 'humantone'); ?></h2>
                <p><?php echo esc_html__('Tämä pikaopas auttaa valitsemaan oikean työkalun ja turvallisen tallennustavan. Jokaisessa osiossa on suora linkki oikeaan kohtaan.', 'humantone'); ?></p>

                <div class="humantone-card humantone-card-inner humantone-guide-wide">
                    <h3><?php echo esc_html__('Pikalinkit', 'humantone'); ?></h3>
                    <p><?php echo esc_html__('Siirry suoraan yleisimpiin työkaluihin ja asetuksiin:', 'humantone'); ?></p>
                    <p class="humantone-guide-actions">
                        <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=single')); ?>"><?php echo esc_html__('Yksittäinen teksti', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=post')); ?>"><?php echo esc_html__('Artikkeli tai sivu', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=bulk')); ?>"><?php echo esc_html__('Joukkokäsittely', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=product')); ?>"><?php echo esc_html__('WooCommerce-tuotteet', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=history')); ?>"><?php echo esc_html__('Historia', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=api')); ?>"><?php echo esc_html__('API ja malli', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=profiles')); ?>"><?php echo esc_html__('Brändiprofiilit', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=license')); ?>"><?php echo esc_html__('Lisenssi', 'humantone'); ?></a>
                    </p>
                </div>

                <div class="humantone-guide-grid">
                    <div class="humantone-card humantone-card-inner">
                        <h3><?php echo esc_html__('1. Yksittäinen teksti', 'humantone'); ?></h3>
                        <p><?php echo esc_html__('Käytä tätä, kun haluat nopeasti siistiä tekstipätkän, otsikon, metakuvauksen tai kappaleen ilman, että kosket WordPress-julkaisuun.', 'humantone'); ?></p>
                        <ul class="humantone-help-list">
                            <li><?php echo esc_html__('Liitä teksti kenttään.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Valitse brändiprofiili ja muokkaustapa.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Kopioi ehdotus käsin oikeaan paikkaan.', 'humantone'); ?></li>
                        </ul>
                        <p class="humantone-guide-actions"><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=single')); ?>"><?php echo esc_html__('Avaa yksittäisen tekstin työkalu', 'humantone'); ?></a></p>
                    </div>
                    <div class="humantone-card humantone-card-inner">
                        <h3><?php echo esc_html__('2. Artikkeli tai sivu', 'humantone'); ?></h3>
                        <p><?php echo esc_html__('Käytä tätä, kun haluat muokata kokonaisen artikkelin tai sivun. Tarkista aina muutosnäkymä ja suojattujen elementtien lista ennen tallennusta.', 'humantone'); ?></p>
                        <ul class="humantone-help-list">
                            <li><?php echo esc_html__('Turvallisin valinta on Tallenna uutena luonnoksena.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Korvaa alkuperäinen vain, jos vertailu ja varoitukset on tarkistettu.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Sivunrakentajasisällöissä suosi aina luonnoskopiota.', 'humantone'); ?></li>
                        </ul>
                        <p class="humantone-guide-actions"><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=post')); ?>"><?php echo esc_html__('Avaa artikkeli- ja sivutyökalu', 'humantone'); ?></a></p>
                    </div>
                    <div class="humantone-card humantone-card-inner">
                        <h3><?php echo esc_html__('3. Joukkokäsittely', 'humantone'); ?></h3>
                        <p><?php echo esc_html__('Käytä tätä vanhojen sisältöjen siistimiseen. Joukkokäsittely luo aina uudet luonnokset eikä ylikirjoita alkuperäisiä.', 'humantone'); ?></p>
                        <ul class="humantone-help-list">
                            <li><?php echo esc_html__('Käsittele ensin pieni erä ja tarkista tulokset.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Rajoita käsittelymäärää käyttörajoista, jos API-kulut huolettavat.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Julkaise luonnokset vasta manuaalisen tarkistuksen jälkeen.', 'humantone'); ?></li>
                        </ul>
                        <p class="humantone-guide-actions"><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=bulk')); ?>"><?php echo esc_html__('Avaa joukkokäsittely', 'humantone'); ?></a></p>
                    </div>
                    <div class="humantone-card humantone-card-inner">
                        <h3><?php echo esc_html__('4. WooCommerce-tuotteet', 'humantone'); ?></h3>
                        <p><?php echo esc_html__('Käytä tätä tuotekuvausten parantamiseen. Tuotefaktat, SKU:t, mitat ja hinnat pitää aina tarkistaa ennen tallennusta.', 'humantone'); ?></p>
                        <ul class="humantone-help-list">
                            <li><?php echo esc_html__('Muokkaa pitkä tai lyhyt tuotekuvaus erikseen.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Tallenna ensin luonnostuotteena, jos tuotteessa on paljon teknisiä tietoja.', 'humantone'); ?></li>
                            <li><?php echo esc_html__('Älä anna tekoälyn lisätä uusia tuotefaktoja.', 'humantone'); ?></li>
                        </ul>
                        <p class="humantone-guide-actions"><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=product')); ?>"><?php echo esc_html__('Avaa WooCommerce-tuotetyökalu', 'humantone'); ?></a></p>
                    </div>
                </div>

                <div class="humantone-card humantone-card-inner humantone-guide-wide">
                    <h3><?php echo esc_html__('Suositeltu tarkistus ennen julkaisua', 'humantone'); ?></h3>
                    <ol class="humantone-help-list">
                        <li><?php echo esc_html__('Lue muokattu teksti kokonaan läpi.', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Tarkista otsikot, linkit, kuvat, lyhytkoodit ja WordPress-lohkot.', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Varmista, ettei uusia faktoja, lupauksia, hintoja tai teknisiä arvoja ole lisätty.', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Tarkista SEO-otsikko, metakuvaus ja artikkelikuva, jos käytät niitä.', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Käytä historiaa ja palautusta, jos alkuperäinen sisältö pitää palauttaa.', 'humantone'); ?></li>
                    </ol>
                    <p class="humantone-guide-actions">
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa&tool_tab=history')); ?>"><?php echo esc_html__('Avaa historia ja palautus', 'humantone'); ?></a>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=safety')); ?>"><?php echo esc_html__('Avaa turvallisen tallennuksen asetukset', 'humantone'); ?></a>
                    </p>
                </div>
            </div>

            <div class="humantone-section humantone-card" data-humantone-tool-panel="history" hidden>
                <h2><?php echo esc_html__('Historia ja palautus', 'humantone'); ?></h2>
                <p><?php echo esc_html__('Näet viimeisimmät WP Sanasepän käsittelyt. Lista näyttää oletuksena vain rajatun määrän rivejä, jotta näkymä pysyy kevyenä. Lisäosa säilyttää enintään 100 historiariviä.', 'humantone'); ?></p>
                <div class="humantone-history-controls">
                    <label for="humantone-history-limit"><?php echo esc_html__('Näytä', 'humantone'); ?></label>
                    <select id="humantone-history-limit">
                        <option value="25" selected><?php echo esc_html__('25 viimeisintä', 'humantone'); ?></option>
                        <option value="50"><?php echo esc_html__('50 viimeisintä', 'humantone'); ?></option>
                        <option value="100"><?php echo esc_html__('100 viimeisintä', 'humantone'); ?></option>
                    </select>
                    <button type="button" id="humantone-load-history" class="button"><?php echo esc_html__('Päivitä historia', 'humantone'); ?></button>
                    <?php if (current_user_can('manage_options')) : ?>
                        <button type="button" id="humantone-prune-history" class="button button-secondary"><?php echo esc_html__('Siivoa vanhat rivit', 'humantone'); ?></button>
                    <?php endif; ?>
                </div>
                <p class="description"><?php echo esc_html__('Siivous säilyttää viimeisimmät 50 historiariviä ja poistaa sitä vanhemmat rivit. Palautus toimii vain säilytetyille riveille.', 'humantone'); ?></p>
                <div id="humantone-history-list" class="humantone-history-list">
                    <p><?php echo esc_html__('Historia latautuu automaattisesti.', 'humantone'); ?></p>
                </div>
            </div>


            <div class="humantone-section humantone-card" data-humantone-tool-panel="product" hidden>
                <h2><?php echo esc_html__('WooCommerce-tuotteet', 'humantone'); ?></h2>
                <p><?php echo esc_html__('Hae tuote, muokkaa pitkä tai lyhyt tuotekuvaus ja tarkista tuotetietojen säilyminen ennen tallennusta.', 'humantone'); ?></p>
                <?php if (!post_type_exists('product')) : ?>
                    <div class="notice notice-warning inline"><p><?php echo esc_html__('WooCommerce ei näytä olevan käytössä. Tuotetyökalu aktivoituu, kun WooCommerce ja product-sisältötyyppi ovat käytössä.', 'humantone'); ?></p></div>
                <?php endif; ?>

                <div class="humantone-row">
                    <div>
                        <label for="humantone-product-search" class="humantone-label"><?php echo esc_html__('Haku', 'humantone'); ?></label>
                        <input type="search" id="humantone-product-search" class="regular-text" placeholder="<?php echo esc_attr__('Hae tuotteen nimellä...', 'humantone'); ?>" />
                    </div>
                    <div class="humantone-row-actions">
                        <button type="button" id="humantone-load-products" class="button"><?php echo esc_html__('Hae tuotteet', 'humantone'); ?></button>
                    </div>
                </div>

                <label for="humantone-product-select" class="humantone-label"><?php echo esc_html__('Valitse tuote', 'humantone'); ?></label>
                <select id="humantone-product-select">
                    <option value=""><?php echo esc_html__('Hae tuotteet ensin...', 'humantone'); ?></option>
                </select>

                <div class="humantone-row humantone-row-wide">
                    <div>
                        <label for="humantone-product-field" class="humantone-label"><?php echo esc_html__('Muokattava kenttä', 'humantone'); ?></label>
                        <select id="humantone-product-field">
                            <option value="long"><?php echo esc_html__('Pitkä tuotekuvaus', 'humantone'); ?></option>
                            <option value="short"><?php echo esc_html__('Lyhyt tuotekuvaus', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-product-mode" class="humantone-label"><?php echo esc_html__('Muokkaustapa', 'humantone'); ?></label>
                        <select id="humantone-product-mode">
                            <option value="natural"><?php echo esc_html__('Luonnollisempi', 'humantone'); ?></option>
                            <option value="clearer"><?php echo esc_html__('Selkeämpi', 'humantone'); ?></option>
                            <option value="proofread"><?php echo esc_html__('Kielenhuolto', 'humantone'); ?></option>
                            <option value="shorter"><?php echo esc_html__('Lyhyempi', 'humantone'); ?></option>
                            <option value="simplify"><?php echo esc_html__('Yksinkertaisempi', 'humantone'); ?></option>
                            <option value="expert"><?php echo esc_html__('Asiantuntevampi', 'humantone'); ?></option>
                            <option value="sales"><?php echo esc_html__('Myyvempi', 'humantone'); ?></option>
                            <option value="more_casual"><?php echo esc_html__('Rennompi', 'humantone'); ?></option>
                            <option value="more_formal"><?php echo esc_html__('Muodollisempi', 'humantone'); ?></option>
                            <option value="warmer"><?php echo esc_html__('Lämpimämpi', 'humantone'); ?></option>
                            <option value="stronger_intro"><?php echo esc_html__('Parempi aloitus', 'humantone'); ?></option>
                            <option value="better_cta"><?php echo esc_html__('Parempi toimintakehotus', 'humantone'); ?></option>
                            <option value="paragraph_flow"><?php echo esc_html__('Parempi rytmi ja siirtymät', 'humantone'); ?></option>
                            <option value="bullets"><?php echo esc_html__('Muuta luetteloksi', 'humantone'); ?></option>
                            <option value="remove_ai_tone"><?php echo esc_html__('Poista AI-sävy', 'humantone'); ?></option>
                            <option value="fix_heading_case"><?php echo esc_html__('Korjaa otsikoiden kirjainkoko', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-product-profile" class="humantone-label"><?php echo esc_html__('Brändiprofiili', 'humantone'); ?></label>
                        <select id="humantone-product-profile"></select>
                    </div>
                    <div>
                        <label class="humantone-label"><input type="checkbox" id="humantone-product-clean-ai-phrases" checked /> <?php echo esc_html__('Siivoa AI-fraasit', 'humantone'); ?></label>
                        <p class="description"><?php echo esc_html__('Tuotetiedot kuten SKU, mitat, hinnat ja mallikoodit pyritään säilyttämään muuttumattomina.', 'humantone'); ?></p>
                    </div>
                </div>

                <div class="humantone-actions">
                    <button type="button" id="humantone-load-product-content" class="button"><?php echo esc_html__('Näytä tuotekuvaus', 'humantone'); ?></button>
                    <button type="button" id="humantone-rewrite-product" class="button button-primary"><?php echo esc_html__('Muokkaa tuotekuvaus esikatseluun', 'humantone'); ?></button>
                    <button type="button" id="humantone-save-product-draft" class="button" disabled><?php echo esc_html__('Tallenna uutena luonnostuotteena', 'humantone'); ?></button>
                    <button type="button" id="humantone-update-product" class="button" disabled><?php echo esc_html__('Päivitä alkuperäinen tuote', 'humantone'); ?></button>
                    <a id="humantone-product-edit-link" class="button" href="#" target="_blank" rel="noopener" style="display:none;"><?php echo esc_html__('Avaa tuote editorissa', 'humantone'); ?></a>
                </div>

                <div id="humantone-product-facts" class="humantone-product-facts"></div>
                <div id="humantone-product-warnings" class="humantone-warnings"></div>
                <div id="humantone-product-diff" class="humantone-diff-panel" hidden></div>

                <div class="humantone-tool-grid humantone-post-preview-grid">
                    <div>
                        <label for="humantone-product-original" class="humantone-label"><?php echo esc_html__('Alkuperäinen tuotekuvaus', 'humantone'); ?></label>
                        <textarea id="humantone-product-original" rows="12" readonly></textarea>
                    </div>
                    <div>
                        <label for="humantone-product-output" class="humantone-label"><?php echo esc_html__('Muokattu tuotekuvaus', 'humantone'); ?></label>
                        <textarea id="humantone-product-output" rows="12"></textarea>
                    </div>
                </div>
            </div>

            <div class="humantone-section humantone-card" data-humantone-tool-panel="bulk" hidden>
                <h2><?php echo esc_html__('Joukkokäsittely', 'humantone'); ?></h2>
                <p><?php echo esc_html__('Valitse useita artikkeleita tai sivuja. Joukkokäsittely luo aina uudet luonnokset eikä koskaan korvaa alkuperäisiä.', 'humantone'); ?></p>

                <div class="humantone-row">
                    <div>
                        <label for="humantone-bulk-post-type" class="humantone-label"><?php echo esc_html__('Sisältötyyppi', 'humantone'); ?></label>
                        <select id="humantone-bulk-post-type">
                            <option value="post"><?php echo esc_html__('Artikkelit', 'humantone'); ?></option>
                            <option value="page"><?php echo esc_html__('Sivut', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-bulk-search" class="humantone-label"><?php echo esc_html__('Haku', 'humantone'); ?></label>
                        <input type="search" id="humantone-bulk-search" class="regular-text" placeholder="<?php echo esc_attr__('Hae otsikolla...', 'humantone'); ?>" />
                    </div>
                    <div class="humantone-row-actions">
                        <button type="button" id="humantone-bulk-load" class="button"><?php echo esc_html__('Hae', 'humantone'); ?></button>
                    </div>
                </div>

                <div class="humantone-row humantone-row-wide">
                    <div>
                        <label for="humantone-bulk-mode" class="humantone-label"><?php echo esc_html__('Muokkaustapa', 'humantone'); ?></label>
                        <select id="humantone-bulk-mode">
                            <option value="natural"><?php echo esc_html__('Luonnollisempi', 'humantone'); ?></option>
                            <option value="clearer"><?php echo esc_html__('Selkeämpi', 'humantone'); ?></option>
                            <option value="proofread"><?php echo esc_html__('Kielenhuolto', 'humantone'); ?></option>
                            <option value="shorter"><?php echo esc_html__('Lyhyempi', 'humantone'); ?></option>
                            <option value="simplify"><?php echo esc_html__('Yksinkertaisempi', 'humantone'); ?></option>
                            <option value="expert"><?php echo esc_html__('Asiantuntevampi', 'humantone'); ?></option>
                            <option value="sales"><?php echo esc_html__('Myyvempi', 'humantone'); ?></option>
                            <option value="more_casual"><?php echo esc_html__('Rennompi', 'humantone'); ?></option>
                            <option value="more_formal"><?php echo esc_html__('Muodollisempi', 'humantone'); ?></option>
                            <option value="warmer"><?php echo esc_html__('Lämpimämpi', 'humantone'); ?></option>
                            <option value="stronger_intro"><?php echo esc_html__('Parempi aloitus', 'humantone'); ?></option>
                            <option value="better_cta"><?php echo esc_html__('Parempi toimintakehotus', 'humantone'); ?></option>
                            <option value="paragraph_flow"><?php echo esc_html__('Parempi rytmi ja siirtymät', 'humantone'); ?></option>
                            <option value="bullets"><?php echo esc_html__('Muuta luetteloksi', 'humantone'); ?></option>
                            <option value="remove_ai_tone"><?php echo esc_html__('Poista AI-sävy', 'humantone'); ?></option>
                            <option value="fix_heading_case"><?php echo esc_html__('Korjaa otsikoiden kirjainkoko', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-bulk-content-purpose" class="humantone-label"><?php echo esc_html__('Sisällön käyttötarkoitus', 'humantone'); ?></label>
                        <select id="humantone-bulk-content-purpose">
                            <option value="general"><?php echo esc_html__('Yleinen sisältö', 'humantone'); ?></option>
                            <option value="blog"><?php echo esc_html__('Blogiartikkeli', 'humantone'); ?></option>
                            <option value="seo"><?php echo esc_html__('SEO-artikkeli', 'humantone'); ?></option>
                            <option value="landing_page"><?php echo esc_html__('Laskeutumissivu', 'humantone'); ?></option>
                            <option value="product"><?php echo esc_html__('Tuotekuvaus', 'humantone'); ?></option>
                            <option value="info_page"><?php echo esc_html__('Tietosivu', 'humantone'); ?></option>
                            <option value="news"><?php echo esc_html__('Uutinen', 'humantone'); ?></option>
                            <option value="expert"><?php echo esc_html__('Asiantuntijateksti', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-bulk-profile" class="humantone-label"><?php echo esc_html__('Brändiprofiili', 'humantone'); ?></label>
                        <select id="humantone-bulk-profile"></select>
                    </div>
                    <div>
                        <label class="humantone-label"><input type="checkbox" id="humantone-bulk-clean-ai-phrases" checked /> <?php echo esc_html__('Siivoa AI-fraasit', 'humantone'); ?></label>
                        <p class="description"><?php echo esc_html__('Raja määräytyy asetuksista. Dry run tarkistaa ja näyttää muutokset tallentamatta mitään. Voit myös luoda luonnokset tai tallentaa suoraan alkuperäisten päälle. Alkuperäisen päälle tallennus päivittää vain sisällön ja säilyttää artikkelikuvan sekä metatiedot.', 'humantone'); ?></p>
                    </div>
                </div>

                <div class="humantone-actions">
                    <label for="humantone-bulk-save-mode" class="screen-reader-text"><?php echo esc_html__('Tallennustapa', 'humantone'); ?></label>
                    <select id="humantone-bulk-save-mode">
                        <option value="dry_run"><?php echo esc_html__('Dry run – älä tallenna', 'humantone'); ?></option>
                        <option value="draft_copy"><?php echo esc_html__('Luo luonnokset', 'humantone'); ?></option>
                        <option value="update_original"><?php echo esc_html__('Korvaa alkuperäiset', 'humantone'); ?></option>
                    </select>
                    <button type="button" id="humantone-bulk-select-all" class="button"><?php echo esc_html__('Valitse näkyvät', 'humantone'); ?></button>
                    <button type="button" id="humantone-bulk-clear-selection" class="button"><?php echo esc_html__('Tyhjennä valinnat', 'humantone'); ?></button>
                    <button type="button" id="humantone-bulk-run" class="button button-primary"><?php echo esc_html__('Suorita joukkokäsittely', 'humantone'); ?></button>
                    <button type="button" id="humantone-bulk-queue-run" class="button"><?php echo esc_html__('Käynnistä tausta-ajona', 'humantone'); ?></button>
                    <button type="button" id="humantone-bulk-last-job" class="button"><?php echo esc_html__('Näytä viimeisin ajo', 'humantone'); ?></button>
                </div>

                <div id="humantone-bulk-progress" class="humantone-progress-card" hidden>
                    <div class="humantone-progress-header">
                        <strong><?php echo esc_html__('Joukkokäsittelyn eteneminen', 'humantone'); ?></strong>
                        <span id="humantone-bulk-progress-percent">0%</span>
                    </div>
                    <div class="humantone-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                        <div id="humantone-bulk-progress-fill" class="humantone-progress-fill"></div>
                    </div>
                    <p id="humantone-bulk-progress-text" class="humantone-progress-text"><?php echo esc_html__('Valmistellaan valittuja sisältöjä...', 'humantone'); ?></p>
                </div>

                <div id="humantone-bulk-list" class="humantone-bulk-list"></div>
                <div id="humantone-bulk-job-status" class="humantone-bulk-job-status"></div>
                <div id="humantone-bulk-results" class="humantone-bulk-results"></div>
            </div>

            <div class="humantone-section humantone-card" data-humantone-tool-panel="post" hidden>
                <h2><?php echo esc_html__('Kokonainen artikkeli tai sivu', 'humantone'); ?></h2>
                <p><?php echo esc_html__('Valitse olemassa oleva artikkeli tai sivu. WP Sanaseppä tekee ensin esikatselun ja näyttää rakennevertailun ennen tallennusta.', 'humantone'); ?></p>
                <?php if (!$is_pro) : ?>
                    <div class="humantone-pro-notice humantone-card-inner <?php echo 'expired' === $license_code ? 'humantone-license-expired-notice' : ''; ?>">
                        <strong><?php echo esc_html('expired' === $license_code ? __('Lisenssi on vanhentunut.', 'humantone') : __('Free-esikatselu käytössä.', 'humantone')); ?></strong>
                        <?php echo esc_html('expired' === $license_code ? __('Voit edelleen tehdä rajatun demoesikatselun, mutta koko muokatun sisällön käyttö ja tallennus avautuvat vasta, kun lisenssi uusitaan tai uusi avain aktivoidaan.', 'humantone') : __('Voit kokeilla kokonaisen artikkelin tai sivun muokkausta demoesikatseluna. Free-versiossa näytetään muutosyhteenveto ja lyhyt tekstinäyte; koko muokattu sisältö ja tallennus vaativat Pro-lisenssin.', 'humantone')); ?>
                        <a class="button button-primary button-small" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=license')); ?>"><?php echo esc_html('expired' === $license_code ? __('Uusi tai tarkista lisenssi', 'humantone') : __('Avaa lisenssi', 'humantone')); ?></a>
                    </div>
                <?php endif; ?>

                <div class="humantone-row">
                    <div>
                        <label for="humantone-post-type" class="humantone-label"><?php echo esc_html__('Sisältötyyppi', 'humantone'); ?></label>
                        <select id="humantone-post-type">
                            <option value="post"><?php echo esc_html__('Artikkelit', 'humantone'); ?></option>
                            <option value="page"><?php echo esc_html__('Sivut', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-post-search" class="humantone-label"><?php echo esc_html__('Haku', 'humantone'); ?></label>
                        <input type="search" id="humantone-post-search" class="regular-text" placeholder="<?php echo esc_attr__('Hae otsikolla...', 'humantone'); ?>" />
                    </div>
                    <div class="humantone-row-actions">
                        <button type="button" id="humantone-load-posts" class="button"><?php echo esc_html__('Hae', 'humantone'); ?></button>
                    </div>
                </div>

                <label for="humantone-post-select" class="humantone-label"><?php echo esc_html__('Valitse julkaisu', 'humantone'); ?></label>
                <select id="humantone-post-select">
                    <option value=""><?php echo esc_html__('Hae julkaisut ensin...', 'humantone'); ?></option>
                </select>

                <div class="humantone-row humantone-row-wide">
                    <div>
                        <label for="humantone-post-mode" class="humantone-label"><?php echo esc_html__('Muokkaustapa', 'humantone'); ?></label>
                        <select id="humantone-post-mode">
                            <option value="natural"><?php echo esc_html__('Luonnollisempi', 'humantone'); ?></option>
                            <option value="clearer"><?php echo esc_html__('Selkeämpi', 'humantone'); ?></option>
                            <option value="proofread"><?php echo esc_html__('Kielenhuolto', 'humantone'); ?></option>
                            <option value="shorter"><?php echo esc_html__('Lyhyempi', 'humantone'); ?></option>
                            <option value="simplify"><?php echo esc_html__('Yksinkertaisempi', 'humantone'); ?></option>
                            <option value="expert"><?php echo esc_html__('Asiantuntevampi', 'humantone'); ?></option>
                            <option value="sales"><?php echo esc_html__('Myyvempi', 'humantone'); ?></option>
                            <option value="more_casual"><?php echo esc_html__('Rennompi', 'humantone'); ?></option>
                            <option value="more_formal"><?php echo esc_html__('Muodollisempi', 'humantone'); ?></option>
                            <option value="warmer"><?php echo esc_html__('Lämpimämpi', 'humantone'); ?></option>
                            <option value="stronger_intro"><?php echo esc_html__('Parempi aloitus', 'humantone'); ?></option>
                            <option value="better_cta"><?php echo esc_html__('Parempi toimintakehotus', 'humantone'); ?></option>
                            <option value="paragraph_flow"><?php echo esc_html__('Parempi rytmi ja siirtymät', 'humantone'); ?></option>
                            <option value="bullets"><?php echo esc_html__('Muuta luetteloksi', 'humantone'); ?></option>
                            <option value="remove_ai_tone"><?php echo esc_html__('Poista AI-sävy', 'humantone'); ?></option>
                            <option value="fix_heading_case"><?php echo esc_html__('Korjaa otsikoiden kirjainkoko', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-post-content-purpose" class="humantone-label"><?php echo esc_html__('Sisällön käyttötarkoitus', 'humantone'); ?></label>
                        <select id="humantone-post-content-purpose">
                            <option value="general"><?php echo esc_html__('Yleinen sisältö', 'humantone'); ?></option>
                            <option value="blog"><?php echo esc_html__('Blogiartikkeli', 'humantone'); ?></option>
                            <option value="seo"><?php echo esc_html__('SEO-artikkeli', 'humantone'); ?></option>
                            <option value="landing_page"><?php echo esc_html__('Laskeutumissivu', 'humantone'); ?></option>
                            <option value="product"><?php echo esc_html__('Tuotekuvaus', 'humantone'); ?></option>
                            <option value="info_page"><?php echo esc_html__('Tietosivu', 'humantone'); ?></option>
                            <option value="news"><?php echo esc_html__('Uutinen', 'humantone'); ?></option>
                            <option value="expert"><?php echo esc_html__('Asiantuntijateksti', 'humantone'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="humantone-post-profile" class="humantone-label"><?php echo esc_html__('Brändiprofiili', 'humantone'); ?></label>
                        <select id="humantone-post-profile"></select>
                    </div>
                    <div>
                        <label class="humantone-label"><input type="checkbox" id="humantone-post-clean-ai-phrases" checked /> <?php echo esc_html__('Siivoa AI-fraasit', 'humantone'); ?></label>
                        <p class="description"><?php echo esc_html__('Tunnistaa ja muotoilee pois geneerisiä fraaseja, kuten “nykypäivän digitaalisessa maailmassa”.', 'humantone'); ?></p>
                    </div>
                    <div>
                        <label class="humantone-label"><?php echo esc_html__('Tallennus', 'humantone'); ?></label>
                        <p class="description"><?php echo esc_html__('Muokkaus luo aina ensin esikatselun. Tallenna vasta vertailun tarkistamisen jälkeen.', 'humantone'); ?></p>
                    </div>
                </div>

                <div class="humantone-actions">
                    <button type="button" id="humantone-load-post-content" class="button"><?php echo esc_html__('Näytä sisältö', 'humantone'); ?></button>
                    <button type="button" id="humantone-rewrite-post" class="button button-primary"><?php echo esc_html__('Muokkaa koko sisältö esikatseluun', 'humantone'); ?></button>
                    <button type="button" id="humantone-save-draft" class="button" disabled><?php echo esc_html($is_pro ? __('Tallenna uutena luonnoksena', 'humantone') : __('Tallenna uutena luonnoksena (Pro)', 'humantone')); ?></button>
                    <button type="button" id="humantone-update-original" class="button" disabled><?php echo esc_html($is_pro ? __('Korvaa alkuperäinen', 'humantone') : __('Korvaa alkuperäinen (Pro)', 'humantone')); ?></button>
                    <?php if (!$is_pro) : ?>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wp-sanaseppa-settings&tab=license')); ?>"><?php echo esc_html('expired' === $license_code ? __('Uusi tai tarkista lisenssi', 'humantone') : __('Aktivoi Pro tai tarkista lisenssi', 'humantone')); ?></a>
                    <?php endif; ?>
                    <a id="humantone-edit-link" class="button" href="#" target="_blank" rel="noopener" style="display:none;"><?php echo esc_html__('Avaa editorissa', 'humantone'); ?></a>
                </div>

                <div id="humantone-post-progress" class="humantone-progress-card" hidden aria-live="polite">
                    <div class="humantone-progress-header">
                        <strong><?php echo esc_html__('Muokkaus on käynnissä', 'humantone'); ?></strong>
                        <span id="humantone-post-progress-percent">0%</span>
                    </div>
                    <div class="humantone-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                        <div id="humantone-post-progress-fill" class="humantone-progress-fill"></div>
                    </div>
                    <p id="humantone-post-progress-text" class="humantone-progress-text"><?php echo esc_html__('Pitkän artikkelin tai sivun käsittely voi kestää. Voit odottaa rauhassa — pyyntö on käynnissä, vaikka tulosta ei vielä näy.', 'humantone'); ?></p>
                    <ol id="humantone-post-progress-steps" class="humantone-progress-steps">
                        <li><?php echo esc_html__('Valmistellaan sisältöä', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Muokataan tekstiä tekoälyllä', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Tarkistetaan rakennetta ja suojattuja elementtejä', 'humantone'); ?></li>
                        <li><?php echo esc_html__('Kootaan esikatselua', 'humantone'); ?></li>
                    </ol>
                </div>

                <div id="humantone-compare-panel" class="humantone-compare-panel" hidden>
                    <h3><?php echo esc_html__('Rakennevertailu', 'humantone'); ?></h3>
                    <div id="humantone-stats-table"></div>
                    <div id="humantone-safety-checklist" class="humantone-safety-checklist"></div>
                    <div id="humantone-ai-phrases" class="humantone-ai-phrases"></div>
                    <div id="humantone-warnings" class="humantone-warnings"></div>
                    <div id="humantone-post-diff" class="humantone-diff-panel" hidden></div>
                </div>

                <div class="humantone-post-preview-sync" id="humantone-post-preview-sync">
                    <p class="humantone-sync-scroll-control">
                        <label for="humantone-post-sync-scroll">
                            <input type="checkbox" id="humantone-post-sync-scroll" class="humantone-sync-scroll-toggle" checked />
                            <?php echo esc_html__('Synkronoi esikatselujen vieritys', 'humantone'); ?>
                        </label>
                        <span class="description"><?php echo esc_html__('Poista valinta, jos alkuperäinen ja muokattu sisältö ovat hyvin eri pituisia.', 'humantone'); ?></span>
                    </p>
                    <div class="humantone-tool-grid humantone-post-preview-grid">
                        <div>
                            <label for="humantone-post-original-preview" class="humantone-label"><?php echo esc_html__('Alkuperäinen sisältö', 'humantone'); ?></label>
                            <div id="humantone-post-original-preview" class="humantone-formatted-preview humantone-sync-scroll-pane" role="region" aria-label="<?php echo esc_attr__('Alkuperäinen sisältö', 'humantone'); ?>"></div>
                            <textarea id="humantone-post-original" rows="14" readonly hidden></textarea>
                        </div>
                        <div>
                            <label for="humantone-post-output-preview" class="humantone-label"><?php echo esc_html($is_pro ? __('Muokattu sisältö', 'humantone') : __('Lyhyt demoesikatselu', 'humantone')); ?></label>
                            <div id="humantone-post-output-preview" class="humantone-formatted-preview humantone-sync-scroll-pane" role="region" aria-label="<?php echo esc_attr($is_pro ? __('Muokattu sisältö', 'humantone') : __('Lyhyt demoesikatselu', 'humantone')); ?>"></div>
                            <textarea id="humantone-post-output" rows="14" hidden></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div class="humantone-tool-grid humantone-tool-panel-active" data-humantone-tool-panel="single">
                <div class="humantone-card">
                    <h2><?php echo esc_html__('Yksittäinen teksti', 'humantone'); ?></h2>
                    <label for="humantone-input" class="screen-reader-text"><?php echo esc_html__('Muokattava teksti', 'humantone'); ?></label>
                    <textarea id="humantone-input" rows="16" placeholder="<?php echo esc_attr__('Liitä muokattava teksti tähän...', 'humantone'); ?>"></textarea>

                    <label for="humantone-mode" class="humantone-label"><?php echo esc_html__('Muokkaustapa', 'humantone'); ?></label>
                    <select id="humantone-mode">
                        <option value="natural"><?php echo esc_html__('Luonnollisempi', 'humantone'); ?></option>
                        <option value="clearer"><?php echo esc_html__('Selkeämpi', 'humantone'); ?></option>
                        <option value="proofread"><?php echo esc_html__('Kielenhuolto', 'humantone'); ?></option>
                        <option value="shorter"><?php echo esc_html__('Lyhyempi', 'humantone'); ?></option>
                        <option value="simplify"><?php echo esc_html__('Yksinkertaisempi', 'humantone'); ?></option>
                        <option value="expert"><?php echo esc_html__('Asiantuntevampi', 'humantone'); ?></option>
                        <option value="sales"><?php echo esc_html__('Myyvempi', 'humantone'); ?></option>
                        <option value="more_casual"><?php echo esc_html__('Rennompi', 'humantone'); ?></option>
                        <option value="more_formal"><?php echo esc_html__('Muodollisempi', 'humantone'); ?></option>
                        <option value="warmer"><?php echo esc_html__('Lämpimämpi', 'humantone'); ?></option>
                        <option value="stronger_intro"><?php echo esc_html__('Parempi aloitus', 'humantone'); ?></option>
                        <option value="better_cta"><?php echo esc_html__('Parempi toimintakehotus', 'humantone'); ?></option>
                        <option value="paragraph_flow"><?php echo esc_html__('Parempi rytmi ja siirtymät', 'humantone'); ?></option>
                        <option value="bullets"><?php echo esc_html__('Muuta luetteloksi', 'humantone'); ?></option>
                        <option value="remove_ai_tone"><?php echo esc_html__('Poista AI-sävy', 'humantone'); ?></option>
                        <option value="fix_heading_case"><?php echo esc_html__('Korjaa otsikoiden kirjainkoko', 'humantone'); ?></option>
                    </select>
                    <label for="humantone-content-purpose" class="humantone-label"><?php echo esc_html__('Sisällön käyttötarkoitus', 'humantone'); ?></label>
                    <select id="humantone-content-purpose">
                        <option value="general"><?php echo esc_html__('Yleinen sisältö', 'humantone'); ?></option>
                        <option value="blog"><?php echo esc_html__('Blogiartikkeli', 'humantone'); ?></option>
                        <option value="seo"><?php echo esc_html__('SEO-artikkeli', 'humantone'); ?></option>
                        <option value="landing_page"><?php echo esc_html__('Laskeutumissivu', 'humantone'); ?></option>
                        <option value="product"><?php echo esc_html__('Tuotekuvaus', 'humantone'); ?></option>
                        <option value="info_page"><?php echo esc_html__('Tietosivu', 'humantone'); ?></option>
                        <option value="news"><?php echo esc_html__('Uutinen', 'humantone'); ?></option>
                        <option value="expert"><?php echo esc_html__('Asiantuntijateksti', 'humantone'); ?></option>
                    </select>
                    <label for="humantone-profile" class="humantone-label"><?php echo esc_html__('Brändiprofiili', 'humantone'); ?></label>
                    <select id="humantone-profile"></select>
                    <label class="humantone-label humantone-checkbox-label"><input type="checkbox" id="humantone-clean-ai-phrases" checked /> <?php echo esc_html__('Siivoa AI-fraasit', 'humantone'); ?></label>
                    <div id="humantone-single-ai-phrases" class="humantone-ai-phrases"></div>

                    <div class="humantone-actions">
                        <button type="button" id="humantone-rewrite" class="button button-primary"><?php echo esc_html__('Muokkaa teksti', 'humantone'); ?></button>
                        <button type="button" id="humantone-clear" class="button"><?php echo esc_html__('Tyhjennä', 'humantone'); ?></button>
                    </div>
                </div>

                <div class="humantone-card">
                    <h2><?php echo esc_html__('Ehdotus', 'humantone'); ?></h2>
                    <label for="humantone-output" class="screen-reader-text"><?php echo esc_html__('Muokattu teksti', 'humantone'); ?></label>
                    <textarea id="humantone-output" rows="16" placeholder="<?php echo esc_attr__('Muokattu teksti ilmestyy tähän...', 'humantone'); ?>"></textarea>

                    <div class="humantone-actions">
                        <button type="button" id="humantone-copy" class="button" disabled><?php echo esc_html__('Kopioi ehdotus', 'humantone'); ?></button>
                    </div>
                </div>
            </div>

            <p class="description">
                <?php
                printf(
                    wp_kses(
                        __('Vinkki: API-avain ja brändiprofiilit määritetään kohdassa <a href="%s">Asetukset → WP Sanaseppä</a>.', 'humantone'),
                        array('a' => array('href' => array()))
                    ),
                    esc_url(admin_url('admin.php?page=wp-sanaseppa-settings'))
                );
                ?>
            </p>
        </div>
        <?php
    }
}
