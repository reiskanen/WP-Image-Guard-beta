<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_AI_Client {
    public static function is_wordpress_ai_client_available() {
        return class_exists('WordPress\\AiClient\\AiClient') && method_exists('WordPress\\AiClient\\AiClient', 'prompt');
    }

    public static function get_openai_provider_classes() {
        return array(
            'WordPress\\OpenAiAiProvider\\Provider\\OpenAiProvider',
            'WordPress\\OpenAiProvider\\Provider\\OpenAiProvider',
            'WordPress\\OpenAIProvider\\Provider\\OpenAiProvider',
        );
    }

    public static function is_openai_provider_plugin_available() {
        foreach (self::get_openai_provider_classes() as $class_name) {
            if (class_exists($class_name)) {
                return true;
            }
        }

        if (defined('AI_PROVIDER_FOR_OPENAI_VERSION') || defined('OPENAI_AI_PROVIDER_VERSION')) {
            return true;
        }

        $active_plugins = (array) get_option('active_plugins', array());
        if (is_multisite()) {
            $network_plugins = array_keys((array) get_site_option('active_sitewide_plugins', array()));
            $active_plugins = array_merge($active_plugins, $network_plugins);
        }

        foreach ($active_plugins as $plugin) {
            $plugin = strtolower((string) $plugin);
            if (strpos($plugin, 'ai-provider-for-openai') !== false || strpos($plugin, 'openai-ai-provider') !== false || (strpos($plugin, 'openai') !== false && strpos($plugin, 'provider') !== false)) {
                return true;
            }
        }

        return false;
    }

    public static function ensure_openai_provider_registered() {
        if (!self::is_wordpress_ai_client_available()) {
            return new WP_Error('humantone_ai_client_missing', __('PHP AI Client SDK ei ole käytettävissä.', 'humantone'), array('status' => 400));
        }

        foreach (self::get_openai_provider_classes() as $class_name) {
            if (!class_exists($class_name)) {
                continue;
            }

            if (method_exists('WordPress\\AiClient\\AiClient', 'defaultRegistry')) {
                try {
                    $registry = \WordPress\AiClient\AiClient::defaultRegistry();
                    if (is_object($registry) && method_exists($registry, 'registerProvider')) {
                        $registry->registerProvider($class_name);
                    }
                } catch (Throwable $e) {
                    // Provider may already be registered or the SDK may handle registration internally.
                } catch (Exception $e) {
                    // Provider may already be registered or the SDK may handle registration internally.
                }
            }

            return true;
        }

        return new WP_Error('humantone_ai_provider_plugin_missing', self::get_provider_missing_message(), array('status' => 400));
    }

    public static function is_openai_provider_available() {
        return self::is_wordpress_ai_client_available() && self::is_openai_provider_plugin_available();
    }

    public static function is_provider_not_registered_error($error) {
        if (!is_wp_error($error)) {
            return false;
        }
        $message = strtolower($error->get_error_message());
        return strpos($message, 'provider not registered') !== false || strpos($message, 'openai-provideria ei ole rekister') !== false;
    }

    public static function get_provider_missing_message() {
        return __('PHP AI Client SDK löytyi, mutta OpenAI-provideria ei ole rekisteröity. Varmista, että AI Provider for OpenAI -lisäosa on asennettu ja aktiivinen sekä että sen OpenAI-konnektoriin on tallennettu API-avain. Voit myös vaihtaa API-lähteeksi WP Sanasepän oman API-avaimen.', 'humantone');
    }

    public static function get_configured_api_source($settings = null) {
        if ($settings === null) {
            $settings = HumanTone_Settings::get_settings();
        }
        $source = isset($settings['api_source']) ? sanitize_key($settings['api_source']) : 'auto';
        return in_array($source, array('auto', 'provider', 'own'), true) ? $source : 'auto';
    }

    public static function get_effective_api_source($settings = null) {
        if ($settings === null) {
            $settings = HumanTone_Settings::get_settings();
        }

        $configured = self::get_configured_api_source($settings);
        $provider_available = self::is_openai_provider_available();

        if ($configured === 'provider') {
            if ($provider_available) {
                return 'provider';
            }

            // If the user has selected the connector but it is not available,
            // fall back to WP Sanaseppä's own API key when one has been saved.
            // This prevents API testing from failing with connector guidance when
            // the user is actually trying to use the built-in API key field.
            if (!empty($settings['api_key'])) {
                return 'own';
            }

            return 'provider';
        }

        if ($configured === 'own') {
            /*
             * Jos käyttäjä on aiemmin valinnut WP Sanasepän oman avainkentän,
             * mutta avainta ei ole tallennettu ja AI Provider for OpenAI on
             * myöhemmin otettu käyttöön, käytetään konnektoria automaattisesti.
             * Näin käyttäjän ei tarvitse vaihtaa API-lähdettä käsin, kun
             * konnektori on jo määritetty sivustolle.
             */
            if (empty($settings['api_key']) && $provider_available) {
                return 'provider';
            }
            return 'own';
        }

        if ($provider_available) {
            return 'provider';
        }

        return 'own';
    }

    public static function get_api_source_label($source) {
        $labels = array(
            'auto' => __('Automaattinen', 'humantone'),
            'provider' => __('AI Provider for OpenAI -konnektori', 'humantone'),
            'own' => __('WP Sanasepän oma API-avain', 'humantone'),
        );
        return isset($labels[$source]) ? $labels[$source] : $source;
    }

    public function rewrite($text, $mode, $context = 'plain', $content_type = 'general', $clean_ai_phrases = false, $profile_id = '') {
        $settings = HumanTone_Settings::get_settings();
        $profile = HumanTone_Settings::get_profile($profile_id);
        $prompt = $this->build_prompt($text, $mode, $settings, $context, $content_type, $clean_ai_phrases, $profile);
        $effective_source = self::get_effective_api_source($settings);
        $configured_source = self::get_configured_api_source($settings);

        if ($effective_source === 'provider') {
            $result = $this->rewrite_with_wordpress_ai_client($prompt, $settings);
            if (is_wp_error($result)) {
                if (($configured_source === 'auto' || self::is_provider_not_registered_error($result)) && !empty($settings['api_key'])) {
                    $result = $this->rewrite_with_direct_openai($prompt, $settings);
                }
            }
        } else {
            $result = $this->rewrite_with_direct_openai($prompt, $settings);
        }

        if (is_wp_error($result)) {
            return $result;
        }

        $rewritten = trim((string) $result);

        if ($mode === 'fix_heading_case') {
            return $context === 'wordpress_content' ? HumanTone_Heading_Case::fix_content_headings($rewritten) : HumanTone_Heading_Case::fix_plain_headings($rewritten);
        }

        if ($context === 'wordpress_content') {
            $rewritten = HumanTone_Heading_Case::fix_content_headings($rewritten);
        }

        return $rewritten;
    }

    public static function get_openai_http_timeout() {
        /**
         * OpenAI-kutsut voivat kestää joillakin webhotelleilla yli 5 sekuntia,
         * etenkin AI Provider for OpenAI -konnektorin kautta. WordPressin HTTP API
         * käyttää oletuksena lyhyttä aikakatkaisua, joten nostamme vain OpenAI-kutsujen
         * timeoutin turvallisempaan arvoon.
         */
        return (int) apply_filters('humantone_openai_http_timeout', 45);
    }

    public static function openai_http_timeout_filter($args, $url) {
        if (is_string($url) && strpos($url, 'api.openai.com') !== false) {
            $args['timeout'] = max(isset($args['timeout']) ? (int) $args['timeout'] : 0, self::get_openai_http_timeout());
        }
        return $args;
    }


    public static function classify_openai_error($message, $code = '') {
        $message_lc = strtolower((string) $message);
        $code_lc = strtolower((string) $code);

        if (strpos($code_lc, 'insufficient_quota') !== false || strpos($message_lc, 'insufficient_quota') !== false || strpos($message_lc, 'exceeded your current quota') !== false || strpos($message_lc, 'quota') !== false || strpos($message_lc, 'billing') !== false) {
            return 'quota';
        }
        if (strpos($code_lc, 'invalid_api_key') !== false || strpos($code_lc, 'invalid_request_error') !== false && strpos($message_lc, 'api key') !== false || strpos($message_lc, 'incorrect api key') !== false || strpos($message_lc, 'invalid api key') !== false || strpos($message_lc, 'you didn\'t provide an api key') !== false) {
            return 'auth';
        }
        if (strpos($code_lc, 'model_not_found') !== false || strpos($message_lc, 'model') !== false && (strpos($message_lc, 'does not exist') !== false || strpos($message_lc, 'do not have access') !== false || strpos($message_lc, 'not found') !== false)) {
            return 'model';
        }
        if (strpos($message_lc, 'timed out') !== false || strpos($message_lc, 'timeout') !== false || strpos($message_lc, 'cURL error 28') !== false) {
            return 'timeout';
        }
        if (strpos($message_lc, 'rate limit') !== false || strpos($message_lc, 'too many requests') !== false) {
            return 'rate_limit';
        }

        return 'api';
    }

    public static function friendly_openai_error_message($message, $code = '', $model = '') {
        $type = self::classify_openai_error($message, $code);
        switch ($type) {
            case 'quota':
                return __('OpenAI API -saldo on loppunut tai laskutus ei ole aktiivinen. WP Sanaseppä ei voi käsitellä tekstejä ennen kuin OpenAI Platformin laskutus tai käyttöraja on kunnossa. Tarkista OpenAI Billing -sivu.', 'humantone');
            case 'auth':
                return __('OpenAI API -avain ei kelpaa tai sitä ei ole tallennettu oikein. Tarkista API-avain WP Sanasepän asetuksista ja tallenna asetukset uudelleen.', 'humantone');
            case 'model':
                if ($model !== '') {
                    return sprintf(__('Valittu OpenAI-malli "%s" ei ole käytettävissä tällä API-tilillä. Valitse toinen malli WP Sanasepän asetuksista ja testaa yhteys uudelleen.', 'humantone'), $model);
                }
                return __('Valittu OpenAI-malli ei ole käytettävissä tällä API-tilillä. Valitse toinen malli WP Sanasepän asetuksista ja testaa yhteys uudelleen.', 'humantone');
            case 'timeout':
                return __('Yhteys OpenAI:hin aikakatkaistiin. Kokeile uudelleen, käsittele pienempi erä tai tarkista palvelimen ulkoiset HTTPS-yhteydet.', 'humantone');
            case 'rate_limit':
                return __('OpenAI palautti käyttöraja-/nopeusrajoitusvirheen. Odota hetki ja kokeile uudelleen pienemmällä erällä.', 'humantone');
        }

        return self::improve_http_error_message((string) $message);
    }

    public static function improve_http_error_message($message) {
        $message = (string) $message;
        if (stripos($message, 'cURL error 28') !== false || stripos($message, 'timed out') !== false || stripos($message, 'Operation timed out') !== false) {
            return $message . ' ' . __('Yhteys OpenAI:hin aikakatkaistiin. WP Sanaseppä käyttää nyt pidempää aikakatkaisua, mutta jos virhe jatkuu, webhotelli voi estää tai hidastaa ulkoisia HTTPS-yhteyksiä. Kokeile testiä uudelleen tai käytä WP Sanasepän omaa API-avainta konnektorin sijaan.', 'humantone');
        }
        return $message;
    }

    private function rewrite_with_wordpress_ai_client($prompt, $settings) {
        if (!self::is_wordpress_ai_client_available()) {
            return new WP_Error('humantone_ai_provider_missing', __('PHP AI Client SDK ei ole käytettävissä. Käytä WP Sanasepän omaa API-avainta tai asenna ja määritä PHP AI Client SDK sekä AI Provider for OpenAI.', 'humantone'), array('status' => 400));
        }

        $registration = self::ensure_openai_provider_registered();
        if (is_wp_error($registration)) {
            return $registration;
        }

        try {
            $full_prompt = "Olet kokenut suomenkielinen sisältöeditoija. Muokkaat tekstiä selkeämmäksi, luonnollisemmaksi ja brändin ääneen sopivaksi. Et lisää uusia faktoja. Säilytät annetun rakenteen, HTML-elementit, WordPress-lohkot ja lyhytkoodit, jos niitä on.\n\n" . $prompt;
            $builder = \WordPress\AiClient\AiClient::prompt($full_prompt);

            if (is_object($builder) && method_exists($builder, 'usingProvider')) {
                $builder = $builder->usingProvider('openai');
            }

            /*
             * PHP AI Client SDK:n usingModel() ei ota vastaan mallinimeä merkkijonona,
             * vaan providerin ModelInterface-olion. AI Provider for OpenAI löytää mallin
             * konnektorin/providerin kautta, joten emme välitä WP Sanasepän omaa
             * mallinimeä usingModel()-metodille. Tämä estää TypeError-virheen:
             * usingModel(): Argument #1 ($model) must be of type ModelInterface, string given.
             *
             * Jos käyttäjä haluaa pakottaa tietyn mallin, se toimii edelleen WP Sanasepän
             * omalla API-avaimella. Konnektoritilassa käytetään providerin omaa mallireititystä.
             */

            if (!is_object($builder) || (!method_exists($builder, 'generateTextResult') && !method_exists($builder, 'generateText'))) {
                return new WP_Error('humantone_ai_provider_unsupported', __('PHP AI Client SDK:n tekstintuottorajapintaa ei löytynyt.', 'humantone'), array('status' => 500));
            }

            add_filter('http_request_args', array(__CLASS__, 'openai_http_timeout_filter'), 20, 2);
            try {
                $result = method_exists($builder, 'generateTextResult') ? $builder->generateTextResult() : $builder->generateText();
            } finally {
                remove_filter('http_request_args', array(__CLASS__, 'openai_http_timeout_filter'), 20);
            }
            if (is_object($result) && method_exists($result, 'toText')) {
                return $result->toText();
            }
            if (is_string($result)) {
                return $result;
            }
            if (is_object($result) && method_exists($result, '__toString')) {
                return (string) $result;
            }

            return new WP_Error('humantone_ai_provider_empty_response', __('AI Provider palautti vastauksen, jota WP Sanaseppä ei osannut lukea tekstinä.', 'humantone'), array('status' => 500));
        } catch (Throwable $e) {
            $message = $e->getMessage();
            if (stripos($message, 'Provider not registered') !== false) {
                return new WP_Error('humantone_ai_provider_not_registered', self::get_provider_missing_message(), array('status' => 400));
            }
            return new WP_Error('humantone_ai_provider_error', self::friendly_openai_error_message($message, '', isset($settings['model']) ? $settings['model'] : ''), array('status' => 500));
        } catch (Exception $e) {
            $message = $e->getMessage();
            if (stripos($message, 'Provider not registered') !== false) {
                return new WP_Error('humantone_ai_provider_not_registered', self::get_provider_missing_message(), array('status' => 400));
            }
            return new WP_Error('humantone_ai_provider_error', self::friendly_openai_error_message($message, '', isset($settings['model']) ? $settings['model'] : ''), array('status' => 500));
        }
    }

    private function rewrite_with_direct_openai($prompt, $settings) {
        if (empty($settings['api_key'])) {
            return new WP_Error('humantone_missing_api_key', __('OpenAI API -avain puuttuu. Lisää avain WP Sanasepän asetuksiin tai määritä WordPressin AI Provider for OpenAI -konnektori.', 'humantone'), array('status' => 400));
        }

        $body = array(
            'model' => $settings['model'],
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => 'Olet kokenut suomenkielinen sisältöeditoija. Muokkaat tekstiä selkeämmäksi, luonnollisemmaksi ja brändin ääneen sopivaksi. Et lisää uusia faktoja. Säilytät annetun rakenteen, HTML-elementit, WordPress-lohkot ja lyhytkoodit, jos niitä on.'
                ),
                array(
                    'role' => 'user',
                    'content' => $prompt,
                ),
            ),
            'temperature' => 0.55,
        );

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => self::get_openai_http_timeout(),
            'headers' => array(
                'Authorization' => 'Bearer ' . $settings['api_key'],
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($body),
        ));

        if (is_wp_error($response)) {
            return new WP_Error($response->get_error_code(), self::improve_http_error_message($response->get_error_message()), $response->get_error_data());
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        if ($status_code < 200 || $status_code >= 300) {
            $message = isset($response_body['error']['message']) ? $response_body['error']['message'] : __('Tuntematon API-virhe.', 'humantone');
            $code = isset($response_body['error']['code']) ? $response_body['error']['code'] : '';
            return new WP_Error('humantone_api_error', self::friendly_openai_error_message($message, $code, isset($settings['model']) ? $settings['model'] : ''), array('status' => $status_code, 'error_type' => self::classify_openai_error($message, $code)));
        }

        if (empty($response_body['choices'][0]['message']['content'])) {
            return new WP_Error('humantone_empty_response', __('API palautti tyhjän vastauksen.', 'humantone'), array('status' => 500));
        }

        if (class_exists('HumanTone_Costs') && !empty($response_body['usage']) && is_array($response_body['usage'])) {
            HumanTone_Costs::log_usage(isset($settings['model']) ? $settings['model'] : '', $response_body['usage'], 'direct', 'rewrite');
        }

        return $response_body['choices'][0]['message']['content'];
    }

    public function rewrite_long_content($content, $mode, $content_type = 'general', $clean_ai_phrases = false, $profile_id = '') {
        $chunks = $this->split_content($content, 6500);
        $rewritten = array();

        foreach ($chunks as $index => $chunk) {
            $result = $this->rewrite($chunk, $mode, 'wordpress_content', $content_type, $clean_ai_phrases, $profile_id);
            if (is_wp_error($result)) {
                return $result;
            }
            $rewritten[] = $result;
        }

        return implode("\n\n", $rewritten);
    }

    public function rewrite_gutenberg_content($content, $mode, $content_type = 'general', $clean_ai_phrases = false, $profile_id = '') {
        $content = (string) $content;

        if (!function_exists('parse_blocks') || !function_exists('serialize_blocks') || strpos($content, '<!-- wp:') === false) {
            return $this->rewrite_long_content($content, $mode, $content_type, $clean_ai_phrases, $profile_id);
        }

        $blocks = parse_blocks($content);
        if (!is_array($blocks) || empty($blocks)) {
            return $this->rewrite_long_content($content, $mode, $content_type, $clean_ai_phrases, $profile_id);
        }

        $rewritten_blocks = $this->rewrite_block_tree($blocks, $mode, $content_type, $clean_ai_phrases, $profile_id);
        if (is_wp_error($rewritten_blocks)) {
            return $rewritten_blocks;
        }

        return serialize_blocks($rewritten_blocks);
    }

    private function rewrite_block_tree($blocks, $mode, $content_type, $clean_ai_phrases, $profile_id) {
        foreach ($blocks as $index => $block) {
            if (!is_array($block)) {
                continue;
            }

            if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
                $inner_blocks = $this->rewrite_block_tree($block['innerBlocks'], $mode, $content_type, $clean_ai_phrases, $profile_id);
                if (is_wp_error($inner_blocks)) {
                    return $inner_blocks;
                }
                $block['innerBlocks'] = $inner_blocks;
            }

            if ($this->is_supported_text_block($block) && empty($block['innerBlocks'])) {
                $html = isset($block['innerHTML']) ? (string) $block['innerHTML'] : '';
                if ($this->should_rewrite_block_html($html)) {
                    $result = $this->rewrite($html, $mode, 'wordpress_block_text', $content_type, $clean_ai_phrases, $profile_id);
                    if (is_wp_error($result)) {
                        return $result;
                    }
                    $block['innerHTML'] = $result;
                    $block['innerContent'] = array($result);
                }
            }

            $blocks[$index] = $block;
        }

        return $blocks;
    }

    private function is_supported_text_block($block) {
        $name = isset($block['blockName']) ? (string) $block['blockName'] : '';
        $supported = array(
            'core/paragraph',
            'core/heading',
            'core/list',
            'core/list-item',
            'core/quote',
            'core/pullquote',
            'core/preformatted',
            'core/verse',
            'core/table',
            'core/button',
        );

        return in_array($name, $supported, true);
    }

    private function should_rewrite_block_html($html) {
        $html = trim((string) $html);
        if ($html === '') {
            return false;
        }

        $plain = trim(wp_strip_all_tags($html));
        if ($plain === '') {
            return false;
        }

        if (preg_match('/<(img|video|audio|iframe|script|style|form|input|textarea|select|button)\b/i', $html)) {
            return false;
        }

        return true;
    }

    private function split_content($content, $max_chars) {
        $content = trim((string) $content);
        if (humantone_strlen($content) <= $max_chars) {
            return array($content);
        }

        $parts = preg_split('/(\n\s*\n|<!--\s*\/wp:[^>]+-->|<\/p>|<\/h[1-6]>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $chunks = array();
        $current = '';

        foreach ($parts as $part) {
            if (humantone_strlen($current . $part) > $max_chars && trim($current) !== '') {
                $chunks[] = trim($current);
                $current = '';
            }
            $current .= $part;
        }

        if (trim($current) !== '') {
            $chunks[] = trim($current);
        }

        $final_chunks = array();
        foreach ($chunks as $chunk) {
            if (humantone_strlen($chunk) <= $max_chars) {
                $final_chunks[] = $chunk;
                continue;
            }

            $offset = 0;
            $length = humantone_strlen($chunk);
            while ($offset < $length) {
                $final_chunks[] = humantone_substr($chunk, $offset, $max_chars);
                $offset += $max_chars;
            }
        }

        return $final_chunks;
    }

    private function build_prompt($text, $mode, $settings, $context = 'plain', $content_type = 'general', $clean_ai_phrases = false, $profile = array()) {
        $mode_instructions = array(
            'natural' => 'Tee tekstistä luonnollisempi, ihmismäisempi ja vähemmän geneerinen.',
            'clearer' => 'Tee tekstistä selkeämpi ja helpommin ymmärrettävä. Poista epäselvät rakenteet ja turha kiertely.',
            'proofread' => 'Korjaa kielioppi, kirjoitusvirheet, pilkutus ja kankeat ilmaisut. Älä muuta tekstin sävyä tai sisältöä tarpeettomasti.',
            'shorter' => 'Lyhennä tekstiä selvästi, mutta säilytä tärkein merkitys.',
            'simplify' => 'Yksinkertaista tekstiä niin, että se on helpompi lukea myös kiireiselle tai aihetta vähemmän tuntevalle lukijalle.',
            'expert' => 'Tee tekstistä asiantuntevampi, täsmällisempi ja uskottavampi ilman jäykkyyttä.',
            'sales' => 'Tee tekstistä myyvempi, mutta vältä ylisanoja ja epäuskottavaa markkinointikieltä.',
            'more_casual' => 'Tee tekstistä rennompi ja helposti lähestyttävä, mutta säilytä asiallisuus.',
            'more_formal' => 'Tee tekstistä muodollisempi, viimeistellympi ja yritysviestintään sopiva.',
            'warmer' => 'Tee tekstistä lämpimämpi, ystävällisempi ja lukijaa paremmin huomioiva.',
            'stronger_intro' => 'Paranna tekstin aloitusta niin, että lukija ymmärtää nopeammin hyödyn ja aiheen. Älä lisää uusia faktoja.',
            'better_cta' => 'Paranna toimintakehotuksia ja lopetusta. Tee niistä selkeämpiä, luontevampia ja vähemmän tyrkyttäviä.',
            'paragraph_flow' => 'Paranna kappaleiden rytmiä, siirtymiä ja tekstin kokonaisvirtausta muuttamatta ydinsisältöä.',
            'bullets' => 'Muotoile teksti selkeämmiksi luettelokohdiksi silloin, kun se parantaa luettavuutta. Säilytä kaikki olennaiset faktat.',
            'remove_ai_tone' => 'Poista geneerinen AI-sävy, toisteisuus ja liian siloteltu rakenne.',
            'fix_heading_case' => 'Korjaa otsikoiden kirjainkoko suomen kielen normaaliksi otsikkotyyliksi. Älä tee muita sisällöllisiä muutoksia.',
        );

        $content_type_instructions = array(
            'general' => 'Yleinen sisältö: paranna luettavuutta ja luonnollisuutta muuttamatta tekstin tarkoitusta.',
            'blog' => 'Blogiartikkeli: tee rytmistä luonteva, poista geneeriset aloitukset ja paranna kappaleiden välisiä siirtymiä.',
            'seo' => 'SEO-artikkeli: säilytä pääavainsanat, otsikkorakenne, sisäiset linkit ja aiheellinen terminologia. Älä lisää keyword stuffingia.',
            'landing_page' => 'Laskeutumissivu: kirkasta arvolupausta, tee tekstistä tiiviimpi ja toimintaa ohjaava, mutta vältä liioittelua.',
            'product' => 'Tuotekuvaus: säilytä tuotenimet, mallinimet, hinnat, mitat, SKU:t ja tekniset tiedot. Korosta hyötyjä ilman uusien ominaisuuksien keksimistä.',
            'info_page' => 'Tietosivu: tee tekstistä selkeä, rauhallinen ja luotettava. Vältä markkinointimaista sävyä.',
            'news' => 'Uutinen: säilytä neutraali sävy, faktajärjestys, nimet, päivämäärät ja lähteisiin viittaavat kohdat. Älä lisää tulkintaa.',
            'expert' => 'Asiantuntijateksti: tee sävystä täsmällinen, perusteltu ja hillitty. Säilytä termit ja vältä ylisanoja.',
        );

        $instruction = isset($mode_instructions[$mode]) ? $mode_instructions[$mode] : $mode_instructions['natural'];
        $content_type_instruction = isset($content_type_instructions[$content_type]) ? $content_type_instructions[$content_type] : $content_type_instructions['general'];
        $structure_instruction = '';
        $ai_phrase_instruction = '';

        if ($context === 'wordpress_content') {
            $structure_instruction = "\n- Säilytä WordPressin lohkokommentit, HTML-tagit, linkit, kuvat, taulukot, lyhytkoodit ja attribuutit.\n- Muokkaa vain näkyvää tekstisisältöä.\n- Älä muuta URL-osoitteita, kuvien alt-tekstejä ellei ne selvästi kaipaa kielellistä korjausta, luokkia, id-arvoja tai lohkorakennetta.\n- Palauta sama rakenne muokatuilla tekstisisällöillä.";
        } elseif ($context === 'wordpress_block_text') {
            $structure_instruction = "\n- Saat käsiteltäväksi yhden WordPress-lohkon sisäisen HTML-sisällön.\n- Säilytä kaikki HTML-tagit, attribuutit, linkit, listarakenteet ja taulukon solut.\n- Muokkaa vain näkyvää suomenkielistä tekstiä tagien sisällä.\n- Älä lisää WordPress-lohkokommentteja, älä poista tageja ja älä palauta selityksiä.";
        }

        if ($clean_ai_phrases) {
            $ai_phrase_instruction = "\n- Etsi ja korvaa luontevammilla ilmaisuilla yleiset AI-tyyliset fraasit, kuten 'nykypäivän digitaalisessa maailmassa', 'on tärkeää huomata', 'kattava opas', 'sukelletaan aiheeseen' ja 'yhteenvetona voidaan todeta'. Älä poista olennaista asiaa, vaan muotoile se konkreettisemmin.";
        }

        $profile = wp_parse_args(is_array($profile) ? $profile : array(), array(
            'name' => 'Oletusprofiili',
            'brand_voice' => isset($settings['brand_voice']) ? $settings['brand_voice'] : '',
            'audience' => '',
            'banned_phrases' => isset($settings['banned_phrases']) ? $settings['banned_phrases'] : '',
            'example_text' => '',
        ));

        $example_instruction = '';
        if (!empty($profile['example_text'])) {
            $example_instruction = "\n\nTyyliesimerkki, jonka sävyä ja rytmiä voi jäljitellä lisäämättä sen faktoja tekstiin:\n" . $profile['example_text'];
        }

        return sprintf(
            "Muokkaa seuraava suomenkielinen teksti.\n\nTavoite:\n- %s\n- Sisältötyypin ohje: %s\n- Säilytä alkuperäinen merkitys.\n- Älä lisää uusia faktoja, nimiä, tilastoja tai lupauksia.\n- Älä muuta tekstin totuusväitteitä.\n- Tee virkkeistä luontevia ja vaihtelevia.\n- Poista turhia ylisanoja ja geneerisiä fraaseja.%s\n- Käytä otsikoissa suomenkielistä kirjoitusasua: älä kirjoita jokaista sanaa isolla alkukirjaimella. Esimerkiksi 'Näin Parannat Verkkosivusi Sisältöä' korjataan muotoon 'Näin parannat verkkosivusi sisältöä'. Säilytä lyhenteet kuten SEO ja AI sekä selvästi brändimäiset kirjoitusasut kuten WordPress.%s\n- Palauta vain muokattu teksti, ei selityksiä.\n\nKäytettävä brändiprofiili: %s\n\nKohdeyleisö:\n%s\n\nBrändin tyyli:\n%s\n\nVältettävät fraasit:\n%s%s\n\nTeksti:\n%s",
            $instruction,
            $content_type_instruction,
            $ai_phrase_instruction,
            $structure_instruction,
            $profile['name'],
            $profile['audience'],
            $profile['brand_voice'],
            $profile['banned_phrases'],
            $example_instruction,
            $text
        );
    }
}
