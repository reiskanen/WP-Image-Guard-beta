<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_REST {
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('humantone_process_bulk_job', array($this, 'process_bulk_job'), 10, 1);
    }

    public function register_routes() {
        register_rest_route('humantone/v1', '/diagnostics', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'diagnostics'),
            'permission_callback' => array($this, 'diagnostics_permissions_check'),
            'args' => array(
                'run_api_test' => array(
                    'required' => false,
                    'type' => 'boolean',
                ),
            ),
        ));

        register_rest_route('humantone/v1', '/rewrite', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'rewrite'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'text' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'content_type' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'profile_id' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'clean_ai_phrases' => array(
                    'required' => false,
                    'type' => 'boolean',
                ),
            ),
        ));

        register_rest_route('humantone/v1', '/posts', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'list_posts'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'type' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'search' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));

        register_rest_route('humantone/v1', '/post/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_post_content'),
            'permission_callback' => array($this, 'post_permissions_check'),
        ));

        register_rest_route('humantone/v1', '/post/(?P<id>\d+)/rewrite', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'rewrite_post'),
            'permission_callback' => array($this, 'post_permissions_check'),
            'args' => array(
                'mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'save_mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'content_type' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'profile_id' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'clean_ai_phrases' => array(
                    'required' => false,
                    'type' => 'boolean',
                ),
            ),
        ));

        register_rest_route('humantone/v1', '/post/(?P<id>\d+)/save', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'save_post_version'),
            'permission_callback' => array($this, 'post_permissions_check'),
            'args' => array(
                'content' => array(
                    'required' => true,
                    'type' => 'string',
                ),
                'save_mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
            ),
        ));


        register_rest_route('humantone/v1', '/bulk/rewrite', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'bulk_rewrite_posts'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'post_ids' => array(
                    'required' => true,
                    'type' => 'array',
                ),
                'mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'content_type' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'profile_id' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'clean_ai_phrases' => array(
                    'required' => false,
                    'type' => 'boolean',
                ),
            ),
        ));


        register_rest_route('humantone/v1', '/bulk/jobs', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'start_bulk_job'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'post_ids' => array('required' => true, 'type' => 'array'),
                'mode' => array('required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_key'),
                'content_type' => array('required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_key'),
                'profile_id' => array('required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_key'),
                'save_mode' => array('required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_key'),
                'clean_ai_phrases' => array('required' => false, 'type' => 'boolean'),
            ),
        ));

        register_rest_route('humantone/v1', '/bulk/jobs/(?P<id>[A-Za-z0-9_\-]+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_bulk_job'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        register_rest_route('humantone/v1', '/bulk/jobs/last', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_last_bulk_job'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        register_rest_route('humantone/v1', '/products', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'list_products'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'search' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));

        register_rest_route('humantone/v1', '/product/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_product_content'),
            'permission_callback' => array($this, 'product_permissions_check'),
        ));

        register_rest_route('humantone/v1', '/product/(?P<id>\d+)/rewrite', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'rewrite_product'),
            'permission_callback' => array($this, 'product_permissions_check'),
            'args' => array(
                'field' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'profile_id' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'clean_ai_phrases' => array(
                    'required' => false,
                    'type' => 'boolean',
                ),
            ),
        ));

        register_rest_route('humantone/v1', '/product/(?P<id>\d+)/save', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'save_product_version'),
            'permission_callback' => array($this, 'product_permissions_check'),
            'args' => array(
                'field' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'content' => array(
                    'required' => true,
                    'type' => 'string',
                ),
                'save_mode' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
            ),
        ));


        register_rest_route('humantone/v1', '/history', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'list_history'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        register_rest_route('humantone/v1', '/history/(?P<id>[A-Za-z0-9_\-]+)/restore', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'restore_history_item'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        register_rest_route('humantone/v1', '/history/prune', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'prune_history'),
            'permission_callback' => array($this, 'diagnostics_permissions_check'),
            'args' => array(
                'keep' => array(
                    'required' => false,
                    'type' => 'integer',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ));

    }


    public function diagnostics_permissions_check() {
        return current_user_can('manage_options');
    }

    public function diagnostics(WP_REST_Request $request) {
        $settings = HumanTone_Settings::get_settings();
        $run_api_test = (bool) $request->get_param('run_api_test');
        $api_key_set = !empty($settings['api_key']);
        $model = isset($settings['model']) ? (string) $settings['model'] : '';
        $configured_api_source = class_exists('HumanTone_AI_Client') ? HumanTone_AI_Client::get_configured_api_source($settings) : 'own';
        $effective_api_source = class_exists('HumanTone_AI_Client') ? HumanTone_AI_Client::get_effective_api_source($settings) : 'own';
        $provider_available = class_exists('HumanTone_AI_Client') ? HumanTone_AI_Client::is_openai_provider_available() : false;
        $profiles = isset($settings['profiles']) && is_array($settings['profiles']) ? $settings['profiles'] : array();
        $limits = isset($settings['limits']) && is_array($settings['limits']) ? $settings['limits'] : array();
        $items = array();

        $items[] = array(
            'key' => 'api_source',
            'label' => __('API-lähde', 'humantone'),
            'status' => ($effective_api_source === 'provider' && !$provider_available) ? 'fail' : 'ok',
            'message' => ($configured_api_source === 'provider' && $effective_api_source === 'own')
                ? __('Valittuna on AI Provider for OpenAI -konnektori, mutta sitä ei havaittu käyttövalmiina. Koska WP Sanasepän oma API-avain on tallennettu, testissä käytetään omaa API-avainta.', 'humantone')
                : sprintf(
                    __('Valittu: %1$s. Käytössä testissä: %2$s.', 'humantone'),
                    HumanTone_AI_Client::get_api_source_label($configured_api_source),
                    HumanTone_AI_Client::get_api_source_label($effective_api_source)
                ),
        );

        $items[] = array(
            'key' => 'ai_provider_openai',
            'label' => __('AI Provider for OpenAI', 'humantone'),
            'status' => $provider_available ? 'ok' : 'info',
            'message' => $provider_available ? __('PHP AI Client SDK ja OpenAI-provider havaittiin. WP Sanaseppä voi käyttää OpenAI-konnektoria.', 'humantone') : __('OpenAI-provideria ei ole rekisteröity. Tämä on ok, jos käytät WP Sanasepän omaa API-avainta. Jos haluat käyttää Konnektorit-näkymää, aktivoi AI Provider for OpenAI ja tallenna sen API-avain.', 'humantone'),
        );

        $items[] = array(
            'key' => 'api_key',
            'label' => __('WP Sanasepän oma API-avain', 'humantone'),
            'status' => ($effective_api_source === 'provider' || $api_key_set) ? 'ok' : 'fail',
            'message' => $api_key_set ? __('Oma API-avain on tallennettu palvelinpuolelle.', 'humantone') : __('Omaa API-avainta ei ole tallennettu. Tämä on ok, jos käytät AI Provider for OpenAI -konnektoria.', 'humantone'),
        );

        $items[] = array(
            'key' => 'model',
            'label' => __('Valittu malli', 'humantone'),
            'status' => $model !== '' ? 'ok' : 'fail',
            'message' => $model !== '' ? sprintf(__('Käytössä oleva malli: %s', 'humantone'), $model) : __('Mallia ei ole valittu.', 'humantone'),
        );

        $items[] = array(
            'key' => 'php',
            'label' => __('PHP-versio', 'humantone'),
            'status' => version_compare(PHP_VERSION, '7.4', '>=') ? 'ok' : 'fail',
            'message' => sprintf(__('PHP %s. WP Sanaseppä vaatii vähintään PHP 7.4.', 'humantone'), PHP_VERSION),
        );

        $items[] = array(
            'key' => 'wordpress',
            'label' => __('WordPress-versio', 'humantone'),
            'status' => version_compare(get_bloginfo('version'), '6.0', '>=') ? 'ok' : 'warning',
            'message' => sprintf(__('WordPress %s. Suositus on vähintään WordPress 6.0.', 'humantone'), get_bloginfo('version')),
        );

        $items[] = array(
            'key' => 'mbstring',
            'label' => __('Monitavumerkkien tuki', 'humantone'),
            'status' => function_exists('mb_strlen') ? 'ok' : 'warning',
            'message' => function_exists('mb_strlen') ? __('mbstring on käytettävissä. Suomenkielisen tekstin pituuslaskenta toimii paremmin.', 'humantone') : __('mbstring ei näytä olevan käytössä. WordPress toimii silti, mutta pitkien tekstien merkkilaskenta voi olla epätarkempaa.', 'humantone'),
        );

        $items[] = array(
            'key' => 'http',
            'label' => __('Palvelimen HTTP-yhteydet', 'humantone'),
            'status' => function_exists('wp_remote_post') ? 'ok' : 'fail',
            'message' => function_exists('wp_remote_post') ? __('WordPressin HTTP API on käytettävissä.', 'humantone') : __('WordPressin HTTP API ei ole käytettävissä.', 'humantone'),
        );

        $items[] = array(
            'key' => 'rest',
            'label' => __('REST API', 'humantone'),
            'status' => 'ok',
            'message' => __('WP Sanaseppä REST -rajapinta vastaa tähän testipyyntöön.', 'humantone'),
        );

        $items[] = array(
            'key' => 'profiles',
            'label' => __('Brändiprofiilit', 'humantone'),
            'status' => count($profiles) > 0 ? 'ok' : 'warning',
            'message' => sprintf(__('Brändiprofiileja käytössä: %d.', 'humantone'), count($profiles)),
        );

        $items[] = array(
            'key' => 'limits',
            'label' => __('Käyttörajat', 'humantone'),
            'status' => !empty($limits) ? 'ok' : 'warning',
            'message' => !empty($limits) ? __('Käyttörajat on määritetty.', 'humantone') : __('Käyttörajoja ei löytynyt asetuksista.', 'humantone'),
        );

        $safety = HumanTone_Settings::get_safety();
        $items[] = array(
            'key' => 'safety',
            'label' => __('Turvallinen tallennus', 'humantone'),
            'status' => !empty($safety['block_structure_loss']) ? 'ok' : 'warning',
            'message' => !empty($safety['block_structure_loss']) ? __('Rakenne-elementtien katoaminen estää tallennuksen.', 'humantone') : __('Rakenne-elementtien katoaminen ei tällä hetkellä estä tallennusta.', 'humantone'),
        );

        $items[] = array(
            'key' => 'page_builder_safety',
            'label' => __('Sivunrakentajien turvatila', 'humantone'),
            'status' => !empty($safety['block_page_builder_overwrite']) ? 'ok' : 'warning',
            'message' => !empty($safety['block_page_builder_overwrite']) ? __('Elementor-, Divi- ja WPBakery-sisältöjen alkuperäisen korvaaminen estetään oletuksena.', 'humantone') : __('Sivunrakentajasisältöjen alkuperäisen korvaamista ei estetä.', 'humantone'),
        );

        $items[] = array(
            'key' => 'woocommerce',
            'label' => __('WooCommerce', 'humantone'),
            'status' => post_type_exists('product') ? 'ok' : 'info',
            'message' => post_type_exists('product') ? __('WooCommerce-tuotetyyppi löytyi. Tuotetyökalu on käytettävissä.', 'humantone') : __('WooCommerce ei ole käytössä tai product-sisältötyyppiä ei löydy. Tämä on ok, jos et käytä tuotetyökalua.', 'humantone'),
        );

        $seo_plugins = $this->detect_seo_plugins();
        $items[] = array(
            'key' => 'seo_plugins',
            'label' => __('SEO-lisäosat', 'humantone'),
            'status' => !empty($seo_plugins) ? 'ok' : 'info',
            'message' => !empty($seo_plugins) ? sprintf(__('Havaittu: %s. SEO-metatietojen suojaus on käytössä luonnoskopioissa.', 'humantone'), implode(', ', $seo_plugins)) : __('Yoast SEO-, Rank Math- tai AIOSEO-lisäosaa ei havaittu. Tämä on ok, jos et käytä SEO-lisäosaa.', 'humantone'),
        );

        $acf_detected = function_exists('acf_get_field_groups') || class_exists('ACF');
        $items[] = array(
            'key' => 'acf',
            'label' => __('Advanced Custom Fields', 'humantone'),
            'status' => $acf_detected ? 'ok' : 'info',
            'message' => $acf_detected ? __('ACF havaittu. ACF-kenttien arvoja suojataan luonnoskopioissa.', 'humantone') : __('ACF-lisäosaa ei havaittu. Tämä on ok, jos et käytä ACF-kenttiä.', 'humantone'),
        );

        $api_test = array(
            'run' => false,
            'status' => 'not_run',
            'message' => __('API-yhteystestiä ei suoritettu.', 'humantone'),
            'model' => $model,
            'source' => class_exists('HumanTone_AI_Client') ? HumanTone_AI_Client::get_api_source_label($effective_api_source) : '',
            'error_type' => '',
        );

        if ($run_api_test) {
            $api_test['run'] = true;
            $api_test['source'] = HumanTone_AI_Client::get_api_source_label($effective_api_source);

            if ($model === '') {
                $api_test['status'] = 'fail';
                $api_test['message'] = __('API-yhteystestiä ei voi suorittaa, koska mallia ei ole valittu.', 'humantone');
                $api_test['error_type'] = 'model';
                HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], isset($api_test['error_type']) ? $api_test['error_type'] : '');
            } elseif ($effective_api_source === 'provider') {
                if (!$provider_available) {
                    $api_test['status'] = 'fail';
                    $api_test['message'] = HumanTone_AI_Client::get_provider_missing_message();
                    $api_test['error_type'] = 'provider';
                    HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], $api_test['error_type']);
                } else {
                    $client = new HumanTone_AI_Client();
                    $result = $client->rewrite('Vastaa vain sanalla: toimii', 'proofread', 'plain', 'general', false, '');
                    if (is_wp_error($result)) {
                        $api_test['status'] = 'fail';
                        $api_test['message'] = HumanTone_AI_Client::friendly_openai_error_message($result->get_error_message(), '', $model);
                        $api_test['error_type'] = HumanTone_AI_Client::classify_openai_error($result->get_error_message());
                        HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], $api_test['error_type']);
                    } else {
                        $api_test['status'] = 'ok';
                        $api_test['message'] = sprintf(__('OpenAI-yhteys toimii lähteellä: %s.', 'humantone'), $api_test['source']);
                        HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], isset($api_test['error_type']) ? $api_test['error_type'] : '');
                    }
                }
            } else {
                if (!$api_key_set) {
                    $api_test['status'] = 'fail';
                    $api_test['message'] = __('API-yhteystestiä ei voi suorittaa, koska WP Sanasepän oma API-avain puuttuu.', 'humantone');
                    $api_test['error_type'] = 'auth';
                    HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], isset($api_test['error_type']) ? $api_test['error_type'] : '');
                } else {
                    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
                        'timeout' => HumanTone_AI_Client::get_openai_http_timeout(),
                        'headers' => array(
                            'Authorization' => 'Bearer ' . $settings['api_key'],
                            'Content-Type' => 'application/json',
                        ),
                        'body' => wp_json_encode(array(
                            'model' => $model,
                            'messages' => array(
                                array('role' => 'system', 'content' => 'Vastaa lyhyesti.'),
                                array('role' => 'user', 'content' => 'Vastaa vain sanalla: toimii'),
                            ),
                            // Do not send max_tokens/max_completion_tokens/temperature in the diagnostics call.
                            // Newer OpenAI models can reject one of these parameters even though the model itself works.
                            // The short prompt below is enough to keep this test lightweight.
                        )),
                    ));

                    if (is_wp_error($response)) {
                        $api_test['status'] = 'fail';
                        $api_test['message'] = HumanTone_AI_Client::friendly_openai_error_message($response->get_error_message(), '', $model);
                        $api_test['error_type'] = HumanTone_AI_Client::classify_openai_error($response->get_error_message());
                        HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], $api_test['error_type']);
                    } else {
                        $status_code = wp_remote_retrieve_response_code($response);
                        $body = json_decode(wp_remote_retrieve_body($response), true);
                        if ($status_code >= 200 && $status_code < 300) {
                            $api_test['status'] = 'ok';
                            $api_test['message'] = sprintf(__('OpenAI-yhteys toimii. API-avain, laskutus ja malli %s ovat käyttökelpoisia.', 'humantone'), $model);
                            $api_test['error_type'] = '';
                            HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], '');
                        } else {
                            $raw_message = isset($body['error']['message']) ? $body['error']['message'] : sprintf(__('OpenAI palautti HTTP-koodin %d.', 'humantone'), $status_code);
                            $raw_code = isset($body['error']['code']) ? $body['error']['code'] : '';
                            $api_test['status'] = 'fail';
                            $api_test['error_type'] = HumanTone_AI_Client::classify_openai_error($raw_message, $raw_code);
                            $api_test['message'] = HumanTone_AI_Client::friendly_openai_error_message($raw_message, $raw_code, $model);
                            HumanTone_Settings::update_api_test_status($api_test['status'], $api_test['message'], $model, $api_test['source'], $api_test['error_type']);
                        }
                    }
                }
            }
        }

        return rest_ensure_response(array(
            'version' => defined('HUMANTONE_VERSION') ? HUMANTONE_VERSION : '',
            'generated_at' => current_time('mysql'),
            'items' => $items,
            'api_test' => $api_test,
        ));
    }

    public function list_history(WP_REST_Request $request) {
        $limit = absint($request->get_param('limit'));
        if (!$limit) {
            $limit = HumanTone_History::DEFAULT_VISIBLE_ITEMS;
        }
        return rest_ensure_response(array(
            'items' => HumanTone_History::get_all($limit),
            'limit' => $limit,
            'total' => HumanTone_History::count_viewable(),
            'storedTotal' => HumanTone_History::count_all(),
            'maxItems' => HumanTone_History::MAX_ITEMS,
        ));
    }

    public function prune_history(WP_REST_Request $request) {
        $keep = absint($request->get_param('keep'));
        if (!$keep) {
            $keep = 50;
        }
        $result = HumanTone_History::prune($keep);
        if (is_wp_error($result)) {
            return $result;
        }
        return rest_ensure_response($result);
    }

    public function restore_history_item(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('Historia ja palautus', 'humantone'));
        }
        $id = sanitize_text_field((string) $request->get_param('id'));
        $result = HumanTone_History::restore($id);
        if (is_wp_error($result)) {
            return $result;
        }
        return rest_ensure_response($result);
    }

    public function permissions_check() {
        return HumanTone_Settings::current_user_can_use_ai();
    }

    public function post_permissions_check(WP_REST_Request $request) {
        $post_id = absint($request->get_param('id'));
        return $post_id && HumanTone_Settings::current_user_can_use_ai() && current_user_can('edit_post', $post_id);
    }

    public function product_permissions_check(WP_REST_Request $request) {
        $product_id = absint($request->get_param('id'));
        return $product_id && HumanTone_Settings::current_user_can_use_ai() && current_user_can('edit_post', $product_id);
    }

    public function rewrite(WP_REST_Request $request) {
        $text = trim((string) $request->get_param('text'));
        $mode = $this->normalize_mode($request->get_param('mode') ?: 'natural');
        $content_type = $this->normalize_content_type($request->get_param('content_type') ?: 'general');
        $clean_ai_phrases = (bool) $request->get_param('clean_ai_phrases');
        $profile_id = $this->normalize_profile_id($request->get_param('profile_id') ?: '');

        if (empty($text)) {
            return new WP_Error('humantone_empty_text', __('Teksti puuttuu.', 'humantone'), array('status' => 400));
        }

        $plain_max_chars = HumanTone_Settings::get_limit('plain_max_chars');
        if (humantone_strlen($text) > $plain_max_chars) {
            return new WP_Error('humantone_text_too_long', sprintf(__('Teksti on liian pitkä. Nykyinen raja on %d merkkiä. Käytä kokonaisen artikkelin työkalua tai lyhennä tekstiä.', 'humantone'), $plain_max_chars), array('status' => 400));
        }

        if ($mode === 'fix_heading_case') {
            $result = HumanTone_Heading_Case::fix_plain_headings($text);
        } else {
            $client = new HumanTone_AI_Client();
            $result = $client->rewrite($text, $mode, 'plain', $content_type, $clean_ai_phrases, $profile_id);
        }

        if (is_wp_error($result)) {
            return $result;
        }


        return rest_ensure_response(array(
            'success' => true,
            'text' => $result,
            'aiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($result),
        ));
    }

    public function list_posts(WP_REST_Request $request) {
        $type = $request->get_param('type') ?: 'post';
        $search = $request->get_param('search') ?: '';
        $allowed_types = array('post', 'page');

        if (!in_array($type, $allowed_types, true)) {
            $type = 'post';
        }

        $query = new WP_Query(array(
            'post_type' => $type,
            'post_status' => array('publish', 'draft', 'pending', 'future', 'private'),
            'posts_per_page' => 50,
            's' => $search,
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true,
        ));

        $items = array();
        foreach ($query->posts as $post) {
            if (!current_user_can('edit_post', $post->ID)) {
                continue;
            }
            $items[] = array(
                'id' => $post->ID,
                'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                'status' => $post->post_status,
                'type' => $post->post_type,
                'modified' => get_post_modified_time('Y-m-d H:i', false, $post),
                'pageBuilder' => $this->detect_page_builder($post->ID),
            );
        }

        return rest_ensure_response(array('posts' => $items));
    }

    public function get_post_content(WP_REST_Request $request) {
        $post_id = absint($request->get_param('id'));
        $post = get_post($post_id);

        if (!$post) {
            return new WP_Error('humantone_post_not_found', __('Julkaisua ei löytynyt.', 'humantone'), array('status' => 404));
        }

        return rest_ensure_response(array(
            'id' => $post->ID,
            'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
            'type' => $post->post_type,
            'status' => $post->post_status,
            'content' => $post->post_content,
            'readableContent' => $this->readable_content_text($post->post_content),
            'editLink' => get_edit_post_link($post->ID, 'raw'),
            'length' => humantone_strlen($post->post_content),
            'stats' => $this->analyze_content($post->post_content),
            'aiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($post->post_content),
            'pageBuilder' => $this->detect_page_builder($post->ID),
        ));
    }

    public function rewrite_post(WP_REST_Request $request) {
        $save_mode = $request->get_param('save_mode') ?: 'preview';
        if (!HumanTone_License::is_pro_enabled() && $save_mode !== 'preview') {
            return HumanTone_License::pro_error_response(__('Kokonaisen artikkelin tai sivun tallennus', 'humantone'));
        }

        $post_id = absint($request->get_param('id'));
        $post = get_post($post_id);

        if (!$post) {
            return new WP_Error('humantone_post_not_found', __('Julkaisua ei löytynyt.', 'humantone'), array('status' => 404));
        }

        $mode = $this->normalize_mode($request->get_param('mode') ?: 'natural');
        $content_type = $this->normalize_content_type($request->get_param('content_type') ?: 'general');
        $clean_ai_phrases = (bool) $request->get_param('clean_ai_phrases');
        $profile_id = $this->normalize_profile_id($request->get_param('profile_id') ?: '');
        $allowed_save_modes = array('preview', 'draft_copy', 'update_original');

        if (!in_array($save_mode, $allowed_save_modes, true)) {
            $save_mode = 'preview';
        }

        $content = trim((string) $post->post_content);
        if ($content === '') {
            return new WP_Error('humantone_empty_content', __('Julkaisun sisältö on tyhjä.', 'humantone'), array('status' => 400));
        }

        $post_max_chars = HumanTone_Settings::get_limit('post_max_chars');
        if (humantone_strlen($content) > $post_max_chars) {
            return new WP_Error('humantone_content_too_long', sprintf(__('Sisältö ylittää nykyisen artikkeli-/sivurajan (%d merkkiä). Nosta rajaa asetuksista tai käsittele sisältö osissa.', 'humantone'), $post_max_chars), array('status' => 400));
        }

        if ($mode === 'fix_heading_case') {
            $rewritten = HumanTone_Heading_Case::fix_content_headings($content);
        } else {
            $client = new HumanTone_AI_Client();
            $rewritten = $client->rewrite_gutenberg_content($content, $mode, $content_type, $clean_ai_phrases, $profile_id);
        }

        if (is_wp_error($rewritten)) {
            return $rewritten;
        }

        $original_stats = $this->analyze_content($content);
        $rewritten_stats = $this->analyze_content($rewritten);
        $warnings = $this->compare_content_stats($original_stats, $rewritten_stats);
        $safety_checklist = $this->build_content_safety_checklist($post, $original_stats, $rewritten_stats, $warnings);

        if ($save_mode === 'preview') {
            $is_pro = HumanTone_License::is_pro_enabled();
            $response = array(
                'success' => true,
                'content' => $is_pro ? $rewritten : '',
                'originalContent' => $is_pro ? $content : '',
                'originalReadableContent' => $this->readable_content_text($content),
                'rewrittenReadableContent' => $is_pro ? $this->readable_content_text($rewritten) : '',
                'originalPreviewHtml' => $this->preview_content_html($content),
                'rewrittenPreviewHtml' => $is_pro ? $this->preview_content_html($rewritten) : '',
                'originalStats' => $original_stats,
                'rewrittenStats' => $rewritten_stats,
                'warnings' => $warnings,
                'safetyChecklist' => $safety_checklist,
                'safeToSave' => $is_pro ? !$this->has_blocking_warnings($warnings) : null,
                'pageBuilder' => $this->detect_page_builder($post->ID),
                'originalAiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($content),
                'rewrittenAiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($rewritten),
                'canSave' => $is_pro,
                'previewLocked' => !$is_pro,
                'message' => $is_pro ? __('Sisältö muokattu esikatselua varten. Tarkista vertailu ja tallenna vasta sen jälkeen.', 'humantone') : __('Demoesikatselu valmis. Free-versio näyttää muutosyhteenvedon ja lyhyen tekstinäytteen, mutta koko sisällön käyttö ja tallennus vaativat Pro-lisenssin.', 'humantone'),
            );

            if (!$is_pro) {
                // Free demo: show a limited but readable and formatted sample. Do not return full rewritten HTML/content.
                $plain_preview = $this->readable_content_text($rewritten);
                $response['previewContent'] = $this->trim_readable_text_preserving_paragraphs($plain_preview, 260);
                $response['rewrittenReadableContent'] = $response['previewContent'];
                $response['rewrittenPreviewHtml'] = $this->preview_content_html_excerpt($rewritten, 260);
                if ($response['rewrittenPreviewHtml'] === '') {
                    $response['rewrittenPreviewHtml'] = $this->preview_text_as_html($response['previewContent']);
                }
                $response['previewNotice'] = __('Tämä on demo-esikatselun rajattu tekstinäyte. Koko muokatun sisällön käyttö ja tallennus ovat Pro-ominaisuuksia.', 'humantone');
            }

            return rest_ensure_response($response);
        }

        return $this->save_rewritten_content($post, $rewritten, $save_mode, $original_stats, $rewritten_stats, $warnings, array(
            'mode' => $mode,
            'content_type' => $content_type,
            'profile_id' => $profile_id,
            'action' => 'rewrite_post',
        ));
    }

    public function bulk_rewrite_posts(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('Joukkokäsittely', 'humantone'));
        }
        $raw_ids = $request->get_param('post_ids');
        if (!is_array($raw_ids)) {
            return new WP_Error('humantone_bulk_invalid_ids', __('Valitse vähintään yksi sisältö joukkokäsittelyyn.', 'humantone'), array('status' => 400));
        }

        $post_ids = array_values(array_unique(array_filter(array_map('absint', $raw_ids))));
        if (empty($post_ids)) {
            return new WP_Error('humantone_bulk_empty_ids', __('Valitse vähintään yksi sisältö joukkokäsittelyyn.', 'humantone'), array('status' => 400));
        }

        $bulk_max_items = HumanTone_Settings::get_limit('bulk_max_items');
        if (count($post_ids) > $bulk_max_items) {
            return new WP_Error('humantone_bulk_limit', sprintf(__('Joukkokäsittelyssä voi käsitellä enintään %d sisältöä kerralla.', 'humantone'), $bulk_max_items), array('status' => 400));
        }

        $mode = $this->normalize_mode($request->get_param('mode') ?: 'natural');
        $content_type = $this->normalize_content_type($request->get_param('content_type') ?: 'general');
        $clean_ai_phrases = (bool) $request->get_param('clean_ai_phrases');
        $profile_id = $this->normalize_profile_id($request->get_param('profile_id') ?: '');
        $requested_save_mode = (string) $request->get_param('save_mode');
        if ($requested_save_mode === 'dry_run') {
            $save_mode = 'dry_run';
        } elseif ($requested_save_mode === 'update_original') {
            $save_mode = 'update_original';
        } else {
            $save_mode = 'draft_copy';
        }
        $results = array();
        $created = 0;
        $updated = 0;
        $dry_run_count = 0;
        $client = null;

        foreach ($post_ids as $post_id) {
            $post = get_post($post_id);
            if (!$post || !in_array($post->post_type, array('post', 'page'), true)) {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => __('Tuntematon sisältö', 'humantone'),
                    'message' => __('Julkaisua ei löytynyt tai sisältötyyppiä ei tueta.', 'humantone'),
                    'skipped' => true,
                );
                continue;
            }

            if (!current_user_can('edit_post', $post_id)) {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'message' => __('Sinulla ei ole oikeutta muokata tätä sisältöä.', 'humantone'),
                    'skipped' => true,
                );
                continue;
            }

            $content = trim((string) $post->post_content);
            if ($content === '') {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'message' => __('Sisältö on tyhjä.', 'humantone'),
                    'skipped' => true,
                );
                continue;
            }

            $post_max_chars = HumanTone_Settings::get_limit('post_max_chars');
            if (humantone_strlen($content) > $post_max_chars) {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'message' => sprintf(__('Sisältö on liian pitkä joukkokäsittelyyn. Nykyinen raja on %d merkkiä.', 'humantone'), $post_max_chars),
                    'skipped' => true,
                );
                continue;
            }

            if ($mode === 'fix_heading_case') {
                $rewritten = HumanTone_Heading_Case::fix_content_headings($content);
            } else {
                if (!$client) {
                    $client = new HumanTone_AI_Client();
                }
                $rewritten = $client->rewrite_gutenberg_content($content, $mode, $content_type, $clean_ai_phrases, $profile_id);
            }

            if (is_wp_error($rewritten)) {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'message' => $rewritten->get_error_message(),
                );
                continue;
            }

            $original_stats = $this->analyze_content($content);
            $rewritten_stats = $this->analyze_content($rewritten);
            $warnings = $this->compare_content_stats($original_stats, $rewritten_stats);
            if ($this->has_blocking_warnings($warnings)) {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'message' => __('Turvallinen tallennus esti luonnoksen luonnin, koska muokattu sisältö näyttää kadottavan tärkeitä elementtejä.', 'humantone'),
                    'warningCount' => count($warnings),
                    'warnings' => $warnings,
                );
                continue;
            }
            if ($save_mode === 'dry_run') {
                $dry_run_count++;
                $results[] = array(
                    'sourceId' => $post_id,
                    'historyId' => '',
                    'success' => true,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'resultLabel' => __('Dry run valmis – ei tallennettu', 'humantone'),
                    'saveMode' => $save_mode,
                    'targetId' => 0,
                    'draftId' => 0,
                    'draftTitle' => '',
                    'editLink' => get_edit_post_link($post->ID, 'raw'),
                    'warningCount' => count($warnings),
                    'warnings' => $warnings,
                    'changed' => $content !== $rewritten,
                    'originalPreview' => $this->trim_readable_text_preserving_paragraphs(wp_strip_all_tags($content), 180),
                    'rewrittenPreview' => $this->trim_readable_text_preserving_paragraphs(wp_strip_all_tags($rewritten), 180),
                    'originalReadableContent' => $this->readable_content_text($content),
                    'rewrittenReadableContent' => $this->readable_content_text($rewritten),
                    'originalPreviewHtml' => $this->preview_content_html($content),
                    'rewrittenPreviewHtml' => $this->preview_content_html($rewritten),
                    'originalContent' => $content,
                    'rewrittenContent' => $rewritten,
                    'pageBuilder' => $this->detect_page_builder($post->ID),
                    'originalStats' => $original_stats,
                    'rewrittenStats' => $rewritten_stats,
                );
                continue;
            }

            $target_id = 0;
            $result_label = '';
            $edit_link = '';

            if ($save_mode === 'update_original') {
                $page_builder = $this->detect_page_builder($post->ID);
                if (HumanTone_Settings::get_safety_flag('block_page_builder_overwrite') && !empty($page_builder['detected'])) {
                    $results[] = array(
                        'sourceId' => $post_id,
                        'success' => false,
                        'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                        'message' => sprintf(__('Alkuperäisen korvaaminen estettiin, koska sisältö näyttää käyttävän sivunrakentajaa: %s.', 'humantone'), implode(', ', $page_builder['builders'])),
                        'pageBuilder' => $page_builder,
                    );
                    continue;
                }

                $original_thumbnail_id = absint(get_post_thumbnail_id($post->ID));
                $saved = wp_update_post(array(
                    'ID' => $post->ID,
                    // Päivitä vain sisältökenttä. Älä luo uutta julkaisua äläkä koske otsikkoon,
                    // artikkelikuvaan, kategorioihin, avainsanoihin, SEO-/ACF-metaan tai muihin metatietoihin.
                    'post_content' => wp_slash($rewritten),
                ), true);
                if (!is_wp_error($saved) && $original_thumbnail_id) {
                    // Varmistus: wp_update_post ei normaalisti poista artikkelikuvaa, mutta pidetään
                    // alkuperäinen kuva eksplisiittisesti paikallaan myös lisäosien sivuvaikutuksia vastaan.
                    set_post_thumbnail($post->ID, $original_thumbnail_id);
                }
                $target_id = $post->ID;
                $result_label = __('Alkuperäinen päivitetty', 'humantone');
                $edit_link = get_edit_post_link($post->ID, 'raw');
            } else {
                $saved = $this->create_draft_copy($post, $rewritten);
                if (!is_wp_error($saved)) {
                    $asset_error = $this->maybe_block_copied_asset_loss($post, $saved);
                    if (is_wp_error($asset_error)) {
                        wp_trash_post($saved);
                        $saved = $asset_error;
                    }
                }
                $target_id = is_wp_error($saved) ? 0 : (int) $saved;
                $result_label = __('Luonnos luotu', 'humantone');
                $edit_link = $target_id ? get_edit_post_link($target_id, 'raw') : '';
            }

            if (is_wp_error($saved)) {
                $results[] = array(
                    'sourceId' => $post_id,
                    'success' => false,
                    'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                    'message' => $saved->get_error_message(),
                );
                continue;
            }

            $history_id = $this->log_history($post, $target_id, $rewritten, array(
                'save_mode' => $save_mode,
                'mode' => $mode,
                'content_type' => $content_type,
                'profile_id' => $profile_id,
                'action' => 'bulk_rewrite',
                'warnings' => $warnings,
            ));

            if ($save_mode === 'update_original') {
                $updated++;
            } else {
                $created++;
            }

            $results[] = array(
                'sourceId' => $post_id,
                'historyId' => $history_id,
                'success' => true,
                'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                'resultLabel' => $result_label,
                'saveMode' => $save_mode,
                'targetId' => $target_id,
                'draftId' => $save_mode === 'draft_copy' ? $target_id : 0,
                'draftTitle' => $save_mode === 'draft_copy' ? (get_the_title($target_id) ?: __('(ei otsikkoa)', 'humantone')) : '',
                'editLink' => $edit_link,
                'warningCount' => count($warnings),
                'pageBuilder' => $this->detect_page_builder($post->ID),
                'originalStats' => $original_stats,
                'rewrittenStats' => $rewritten_stats,
            );
        }

        $summary = array('ok' => 0, 'skipped' => 0, 'failed' => 0, 'total' => count($post_ids));
        foreach ($results as $item) {
            if (!empty($item['success'])) {
                $summary['ok']++;
            } elseif (!empty($item['skipped'])) {
                $summary['skipped']++;
            } else {
                $summary['failed']++;
            }
        }

        return rest_ensure_response(array(
            'success' => true,
            'created' => $created,
            'updated' => $updated,
            'dryRun' => $dry_run_count,
            'saveMode' => $save_mode,
            'total' => count($post_ids),
            'summary' => $summary,
            'results' => $results,
            'message' => $save_mode === 'dry_run'
                ? sprintf(__('Dry run valmis. Tarkistettuja sisältöjä: %1$d/%2$d. Mitään ei tallennettu.', 'humantone'), $dry_run_count, count($post_ids))
                : ($save_mode === 'update_original'
                    ? sprintf(__('Joukkokäsittely valmis. Päivitettyjä alkuperäisiä: %1$d/%2$d.', 'humantone'), $updated, count($post_ids))
                    : sprintf(__('Joukkokäsittely valmis. Luotuja luonnoksia: %1$d/%2$d.', 'humantone'), $created, count($post_ids))),
        ));
    }


    public function start_bulk_job(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('Joukkokäsittely', 'humantone'));
        }
        $raw_ids = $request->get_param('post_ids');
        if (!is_array($raw_ids)) {
            return new WP_Error('humantone_bulk_invalid_ids', __('Valitse vähintään yksi sisältö joukkokäsittelyyn.', 'humantone'), array('status' => 400));
        }
        $post_ids = array_values(array_unique(array_filter(array_map('absint', $raw_ids))));
        if (empty($post_ids)) {
            return new WP_Error('humantone_bulk_empty_ids', __('Valitse vähintään yksi sisältö joukkokäsittelyyn.', 'humantone'), array('status' => 400));
        }
        $bulk_max_items = HumanTone_Settings::get_limit('bulk_max_items');
        if (count($post_ids) > $bulk_max_items) {
            return new WP_Error('humantone_bulk_limit', sprintf(__('Joukkokäsittelyssä voi käsitellä enintään %d sisältöä kerralla.', 'humantone'), $bulk_max_items), array('status' => 400));
        }

        $save_mode = sanitize_key((string) $request->get_param('save_mode'));
        if (!in_array($save_mode, array('dry_run', 'draft_copy', 'update_original'), true)) {
            $save_mode = 'draft_copy';
        }

        $job_id = 'job_' . wp_generate_uuid4();
        $job = array(
            'id' => $job_id,
            'user_id' => get_current_user_id(),
            'status' => 'queued',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
            'started_at' => '',
            'finished_at' => '',
            'post_ids' => $post_ids,
            'total' => count($post_ids),
            'done' => 0,
            'created' => 0,
            'updated' => 0,
            'dryRun' => 0,
            'summary' => array('ok' => 0, 'skipped' => 0, 'failed' => 0, 'total' => count($post_ids)),
            'results' => array(),
            'message' => __('Tausta-ajo on jonossa.', 'humantone'),
            'args' => array(
                'mode' => $this->normalize_mode($request->get_param('mode') ?: 'natural'),
                'content_type' => $this->normalize_content_type($request->get_param('content_type') ?: 'general'),
                'profile_id' => $this->normalize_profile_id($request->get_param('profile_id') ?: ''),
                'save_mode' => $save_mode,
                'clean_ai_phrases' => (bool) $request->get_param('clean_ai_phrases'),
            ),
        );

        $jobs = $this->get_bulk_jobs();
        $jobs[$job_id] = $job;
        $this->save_bulk_jobs($jobs);
        update_option('humantone_last_bulk_job_id', $job_id, false);
        $this->schedule_bulk_job($job_id, 1);
        if (class_exists('HumanTone_Settings')) {
            HumanTone_Settings::add_beta_log('Tausta-ajo käynnistetty', 'ok', sprintf('%d sisältöä, tila: %s', count($post_ids), $save_mode), array('job_id' => $job_id, 'save_mode' => $save_mode));
        }

        return rest_ensure_response($job);
    }

    public function get_bulk_job(WP_REST_Request $request) {
        $job_id = sanitize_text_field((string) $request->get_param('id'));
        if ($job_id === 'last') {
            return $this->get_last_bulk_job($request);
        }
        $jobs = $this->get_bulk_jobs();
        if (empty($jobs[$job_id])) {
            return new WP_Error('humantone_bulk_job_missing', __('Tausta-ajoa ei löytynyt.', 'humantone'), array('status' => 404));
        }
        $job = $jobs[$job_id];
        if (!$this->can_view_bulk_job($job)) {
            return new WP_Error('humantone_bulk_job_forbidden', __('Sinulla ei ole oikeutta tähän tausta-ajoon.', 'humantone'), array('status' => 403));
        }
        return rest_ensure_response($job);
    }

    public function get_last_bulk_job(WP_REST_Request $request) {
        $job_id = (string) get_option('humantone_last_bulk_job_id', '');
        $jobs = $this->get_bulk_jobs();
        if ($job_id === '' || empty($jobs[$job_id]) || !$this->can_view_bulk_job($jobs[$job_id])) {
            return rest_ensure_response(array('found' => false));
        }
        $job = $jobs[$job_id];
        $job['found'] = true;
        return rest_ensure_response($job);
    }

    public function process_bulk_job($job_id) {
        $job_id = sanitize_text_field((string) $job_id);
        $jobs = $this->get_bulk_jobs();
        if (empty($jobs[$job_id])) {
            return;
        }
        $job = $jobs[$job_id];
        if (in_array($job['status'], array('done', 'failed'), true)) {
            return;
        }

        if (empty($job['started_at'])) {
            $job['started_at'] = current_time('mysql');
        }
        $job['status'] = 'running';
        $job['updated_at'] = current_time('mysql');
        $jobs[$job_id] = $job;
        $this->save_bulk_jobs($jobs);

        $index = absint($job['done']);
        $post_ids = isset($job['post_ids']) && is_array($job['post_ids']) ? $job['post_ids'] : array();
        if ($index >= count($post_ids)) {
            $job['status'] = 'done';
            $job['finished_at'] = current_time('mysql');
            $job['updated_at'] = current_time('mysql');
            $job['message'] = $this->bulk_job_message($job);
            $jobs[$job_id] = $job;
            $this->save_bulk_jobs($jobs);
            if (class_exists('HumanTone_Settings')) {
                HumanTone_Settings::add_beta_log('Tausta-ajo valmis', 'ok', $job['message'], array('job_id' => $job_id));
            }
            return;
        }

        $user_id = absint($job['user_id']);
        wp_set_current_user($user_id);
        $single_request = new WP_REST_Request('POST', '/humantone/v1/bulk/rewrite');
        $args = isset($job['args']) && is_array($job['args']) ? $job['args'] : array();
        $single_request->set_param('post_ids', array(absint($post_ids[$index])));
        $single_request->set_param('mode', isset($args['mode']) ? $args['mode'] : 'natural');
        $single_request->set_param('content_type', isset($args['content_type']) ? $args['content_type'] : 'general');
        $single_request->set_param('profile_id', isset($args['profile_id']) ? $args['profile_id'] : '');
        $single_request->set_param('save_mode', isset($args['save_mode']) ? $args['save_mode'] : 'draft_copy');
        $single_request->set_param('clean_ai_phrases', !empty($args['clean_ai_phrases']));

        $response = $this->bulk_rewrite_posts($single_request);
        $data = null;
        if (is_wp_error($response)) {
            $data = array(
                'created' => 0,
                'updated' => 0,
                'dryRun' => 0,
                'results' => array(array(
                    'sourceId' => absint($post_ids[$index]),
                    'success' => false,
                    'title' => (string) absint($post_ids[$index]),
                    'message' => $response->get_error_message(),
                )),
            );
        } elseif ($response instanceof WP_REST_Response) {
            $data = $response->get_data();
        } else {
            $data = (array) $response;
        }

        $job['created'] += !empty($data['created']) ? absint($data['created']) : 0;
        $job['updated'] += !empty($data['updated']) ? absint($data['updated']) : 0;
        $job['dryRun'] += !empty($data['dryRun']) ? absint($data['dryRun']) : 0;
        if (!empty($data['results']) && is_array($data['results'])) {
            foreach ($data['results'] as $item) {
                $job['results'][] = $item;
                if (!empty($item['success'])) {
                    $job['summary']['ok']++;
                } elseif (!empty($item['skipped'])) {
                    $job['summary']['skipped']++;
                } else {
                    $job['summary']['failed']++;
                }
            }
        }
        $job['done'] = $index + 1;
        $job['updated_at'] = current_time('mysql');

        if ($job['done'] >= $job['total']) {
            $job['status'] = 'done';
            $job['finished_at'] = current_time('mysql');
            $job['message'] = $this->bulk_job_message($job);
        } else {
            $job['status'] = 'running';
            $job['message'] = sprintf(__('Tausta-ajo käynnissä: %1$d/%2$d käsitelty.', 'humantone'), $job['done'], $job['total']);
            $jobs[$job_id] = $job;
            $this->save_bulk_jobs($jobs);
            $this->schedule_bulk_job($job_id, 5);
            return;
        }
        $jobs[$job_id] = $job;
        $this->save_bulk_jobs($jobs);
        if (class_exists('HumanTone_Settings')) {
            HumanTone_Settings::add_beta_log('Tausta-ajo valmis', empty($job['summary']['failed']) ? 'ok' : 'warning', $job['message'], array('job_id' => $job_id, 'failed' => isset($job['summary']['failed']) ? $job['summary']['failed'] : 0));
        }
    }

    private function bulk_job_message($job) {
        $mode = isset($job['args']['save_mode']) ? $job['args']['save_mode'] : 'draft_copy';
        if ($mode === 'dry_run') {
            return sprintf(__('Dry run valmis. Tarkistettuja sisältöjä: %1$d/%2$d. Mitään ei tallennettu.', 'humantone'), absint($job['dryRun']), absint($job['total']));
        }
        if ($mode === 'update_original') {
            return sprintf(__('Tausta-ajo valmis. Päivitettyjä alkuperäisiä: %1$d/%2$d.', 'humantone'), absint($job['updated']), absint($job['total']));
        }
        return sprintf(__('Tausta-ajo valmis. Luotuja luonnoksia: %1$d/%2$d.', 'humantone'), absint($job['created']), absint($job['total']));
    }

    private function schedule_bulk_job($job_id, $delay = 5) {
        if (!wp_next_scheduled('humantone_process_bulk_job', array($job_id))) {
            wp_schedule_single_event(time() + absint($delay), 'humantone_process_bulk_job', array($job_id));
        }
    }

    private function get_bulk_jobs() {
        $jobs = get_option('humantone_bulk_jobs', array());
        return is_array($jobs) ? $jobs : array();
    }

    private function save_bulk_jobs($jobs) {
        if (!is_array($jobs)) {
            $jobs = array();
        }
        if (count($jobs) > 20) {
            uasort($jobs, function ($a, $b) {
                return strcmp(isset($b['updated_at']) ? $b['updated_at'] : '', isset($a['updated_at']) ? $a['updated_at'] : '');
            });
            $jobs = array_slice($jobs, 0, 20, true);
        }
        update_option('humantone_bulk_jobs', $jobs, false);
    }

    private function can_view_bulk_job($job) {
        if (current_user_can('manage_options')) {
            return true;
        }
        return !empty($job['user_id']) && absint($job['user_id']) === get_current_user_id();
    }



    public function list_products(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('WooCommerce-tuotteet', 'humantone'));
        }
        if (!post_type_exists('product')) {
            return rest_ensure_response(array(
                'active' => false,
                'products' => array(),
                'message' => __('WooCommerce ei ole käytössä tai product-sisältötyyppiä ei löydy.', 'humantone'),
            ));
        }

        $search = $request->get_param('search') ?: '';
        $query = new WP_Query(array(
            'post_type' => 'product',
            'post_status' => array('publish', 'draft', 'pending', 'future', 'private'),
            'posts_per_page' => 50,
            's' => $search,
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true,
        ));

        $items = array();
        foreach ($query->posts as $post) {
            if (!current_user_can('edit_post', $post->ID)) {
                continue;
            }
            $items[] = array(
                'id' => $post->ID,
                'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
                'status' => $post->post_status,
                'sku' => (string) get_post_meta($post->ID, '_sku', true),
                'price' => (string) get_post_meta($post->ID, '_price', true),
                'modified' => get_post_modified_time('Y-m-d H:i', false, $post),
                'pageBuilder' => $this->detect_page_builder($post->ID),
            );
        }

        return rest_ensure_response(array(
            'active' => true,
            'products' => $items,
        ));
    }

    public function get_product_content(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('WooCommerce-tuotteet', 'humantone'));
        }
        $product_id = absint($request->get_param('id'));
        $post = get_post($product_id);

        if (!$post || $post->post_type !== 'product') {
            return new WP_Error('humantone_product_not_found', __('Tuotetta ei löytynyt.', 'humantone'), array('status' => 404));
        }

        return rest_ensure_response(array(
            'id' => $post->ID,
            'title' => get_the_title($post) ?: __('(ei otsikkoa)', 'humantone'),
            'status' => $post->post_status,
            'longDescription' => $post->post_content,
            'shortDescription' => $post->post_excerpt,
            'editLink' => get_edit_post_link($post->ID, 'raw'),
            'productMeta' => $this->get_product_meta_summary($post->ID),
            'longFacts' => $this->analyze_product_facts($post->post_content, $post->ID),
            'shortFacts' => $this->analyze_product_facts($post->post_excerpt, $post->ID),
        ));
    }

    public function rewrite_product(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('WooCommerce-tuotteet', 'humantone'));
        }
        $product_id = absint($request->get_param('id'));
        $post = get_post($product_id);

        if (!$post || $post->post_type !== 'product') {
            return new WP_Error('humantone_product_not_found', __('Tuotetta ei löytynyt.', 'humantone'), array('status' => 404));
        }

        $field = $this->normalize_product_field($request->get_param('field') ?: 'long');
        $mode = $this->normalize_mode($request->get_param('mode') ?: 'natural');
        $profile_id = $this->normalize_profile_id($request->get_param('profile_id') ?: '');
        $clean_ai_phrases = (bool) $request->get_param('clean_ai_phrases');
        $content = $field === 'short' ? (string) $post->post_excerpt : (string) $post->post_content;

        if (trim($content) === '') {
            return new WP_Error('humantone_empty_product_content', __('Tuotekuvaus on tyhjä.', 'humantone'), array('status' => 400));
        }

        $product_max_chars = HumanTone_Settings::get_limit('product_max_chars');
        if (humantone_strlen($content) > $product_max_chars) {
            return new WP_Error('humantone_product_content_too_long', sprintf(__('Tuotekuvaus ylittää nykyisen rajan (%d merkkiä). Nosta rajaa asetuksista tai käsittele se osissa.', 'humantone'), $product_max_chars), array('status' => 400));
        }

        if ($mode === 'fix_heading_case') {
            $rewritten = $field === 'short' ? HumanTone_Heading_Case::fix_plain_headings($content) : HumanTone_Heading_Case::fix_content_headings($content);
        } else {
            $client = new HumanTone_AI_Client();
            $product_context = $this->build_product_context($post);
            $source = $product_context . "\n\nMuokattava tuotekuvaus:\n" . $content;
            $rewritten = $client->rewrite($source, $mode, $field === 'short' ? 'plain' : 'wordpress_content', 'product', $clean_ai_phrases, $profile_id);
            if (!is_wp_error($rewritten)) {
                $rewritten = $this->strip_product_context_from_response($rewritten);
            }
        }

        if (is_wp_error($rewritten)) {
            return $rewritten;
        }

        $comparison = $this->compare_product_facts($content, $rewritten, $post->ID);


        return rest_ensure_response(array(
            'success' => true,
            'content' => $rewritten,
            'field' => $field,
            'originalFacts' => $comparison['originalFacts'],
            'rewrittenFacts' => $comparison['rewrittenFacts'],
            'warnings' => $comparison['warnings'],
            'message' => __('Tuotekuvaus muokattu esikatselua varten. Tarkista tuotetiedot ennen tallennusta.', 'humantone'),
        ));
    }

    public function save_product_version(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('WooCommerce-tuotteet', 'humantone'));
        }
        $product_id = absint($request->get_param('id'));
        $post = get_post($product_id);

        if (!$post || $post->post_type !== 'product') {
            return new WP_Error('humantone_product_not_found', __('Tuotetta ei löytynyt.', 'humantone'), array('status' => 404));
        }

        $field = $this->normalize_product_field($request->get_param('field') ?: 'long');
        $content = (string) $request->get_param('content');
        $save_mode = $request->get_param('save_mode') ?: 'draft_copy';

        if (trim($content) === '') {
            return new WP_Error('humantone_empty_product_content', __('Tallennettava tuotekuvaus on tyhjä.', 'humantone'), array('status' => 400));
        }

        if (!in_array($save_mode, array('draft_copy', 'update_original'), true)) {
            $save_mode = 'draft_copy';
        }

        $original = $field === 'short' ? (string) $post->post_excerpt : (string) $post->post_content;
        $comparison = $this->compare_product_facts($original, $content, $post->ID);
        $blocking_error = $this->maybe_block_save($comparison['warnings']);
        if (is_wp_error($blocking_error)) {
            return $blocking_error;
        }

        if ($save_mode === 'update_original') {
            $update = array('ID' => $post->ID);
            if ($field === 'short') {
                $update['post_excerpt'] = wp_slash($content);
            } else {
                $update['post_content'] = wp_slash($content);
            }
            $updated = wp_update_post($update, true);
            if (is_wp_error($updated)) {
                return $updated;
            }
            $history_id = $this->log_history($post, $post->ID, $content, array(
                'save_mode' => 'update_original',
                'mode' => '',
                'content_type' => 'product',
                'profile_id' => '',
                'field' => $field,
                'action' => 'save_product',
                'warnings' => $comparison['warnings'],
            ));

            return rest_ensure_response(array(
                'success' => true,
                'historyId' => $history_id,
                'postId' => $post->ID,
                'editLink' => get_edit_post_link($post->ID, 'raw'),
                'warnings' => $comparison['warnings'],
                'originalFacts' => $comparison['originalFacts'],
                'rewrittenFacts' => $comparison['rewrittenFacts'],
                'message' => __('Alkuperäinen tuote päivitettiin.', 'humantone'),
            ));
        }

        $draft_id = $this->create_product_draft_copy($post, $content, $field);
        if (is_wp_error($draft_id)) {
            return $draft_id;
        }

        $history_id = $this->log_history($post, $draft_id, $content, array(
            'save_mode' => 'draft_copy',
            'mode' => '',
            'content_type' => 'product',
            'profile_id' => '',
            'field' => $field,
            'action' => 'save_product',
            'warnings' => $comparison['warnings'],
        ));


        return rest_ensure_response(array(
            'success' => true,
            'historyId' => $history_id,
            'postId' => $draft_id,
            'editLink' => get_edit_post_link($draft_id, 'raw'),
            'warnings' => $comparison['warnings'],
            'originalFacts' => $comparison['originalFacts'],
            'rewrittenFacts' => $comparison['rewrittenFacts'],
            'message' => __('Muokattu tuotekuvaus tallennettiin uutena luonnostuotteena.', 'humantone'),
        ));
    }

    public function save_post_version(WP_REST_Request $request) {
        if (!HumanTone_License::is_pro_enabled()) {
            return HumanTone_License::pro_error_response(__('Kokonaisen artikkelin tai sivun tallennus', 'humantone'));
        }
        $post_id = absint($request->get_param('id'));
        $post = get_post($post_id);

        if (!$post) {
            return new WP_Error('humantone_post_not_found', __('Julkaisua ei löytynyt.', 'humantone'), array('status' => 404));
        }

        $content = (string) $request->get_param('content');
        $save_mode = $request->get_param('save_mode') ?: 'draft_copy';

        if (trim($content) === '') {
            return new WP_Error('humantone_empty_content', __('Tallennettava sisältö on tyhjä.', 'humantone'), array('status' => 400));
        }

        if (!in_array($save_mode, array('draft_copy', 'update_original'), true)) {
            $save_mode = 'draft_copy';
        }

        $original_stats = $this->analyze_content($post->post_content);
        $rewritten_stats = $this->analyze_content($content);
        $warnings = $this->compare_content_stats($original_stats, $rewritten_stats);

        return $this->save_rewritten_content($post, $content, $save_mode, $original_stats, $rewritten_stats, $warnings);
    }




    private function log_history($post, $target_post_id, $rewritten, $args = array()) {
        if (!$post) {
            return '';
        }
        $profile_id = isset($args['profile_id']) ? $args['profile_id'] : '';
        $profile_name = '';
        if ($profile_id) {
            $profiles = HumanTone_Settings::get_profiles();
            if (isset($profiles[$profile_id]['name'])) {
                $profile_name = $profiles[$profile_id]['name'];
            }
        }

        $field = isset($args['field']) ? $args['field'] : 'content';

        return HumanTone_History::add(array(
            'source_post_id' => $post->ID,
            'target_post_id' => absint($target_post_id),
            'post_type' => $post->post_type,
            'field' => $field,
            'action' => isset($args['action']) ? $args['action'] : 'rewrite',
            'save_mode' => isset($args['save_mode']) ? $args['save_mode'] : '',
            'mode' => isset($args['mode']) ? $args['mode'] : '',
            'content_type' => isset($args['content_type']) ? $args['content_type'] : '',
            'profile_id' => $profile_id,
            'profile_name' => $profile_name,
            'original_title' => get_the_title($post) ?: '',
            'original_content' => (string) $post->post_content,
            'original_excerpt' => (string) $post->post_excerpt,
            'original_thumbnail_id' => absint(get_post_thumbnail_id($post->ID)),
            'new_thumbnail_id' => $target_post_id ? absint(get_post_thumbnail_id($target_post_id)) : absint(get_post_thumbnail_id($post->ID)),
            'new_title' => $target_post_id ? (get_the_title($target_post_id) ?: '') : (get_the_title($post) ?: ''),
            'warnings' => isset($args['warnings']) && is_array($args['warnings']) ? $args['warnings'] : array(),
        ));
    }

    private function normalize_product_field($field) {
        return $field === 'short' ? 'short' : 'long';
    }

    private function build_product_context($post) {
        $meta = $this->get_product_meta_summary($post->ID);
        $lines = array(
            'Tuotetietojen suojaus:',
            '- Muokkaa vain tuotekuvauksen esitystapaa.',
            '- Älä muuta tuotteen nimeä, SKU:ta, hintaa, mittoja, painoa, EAN/GTIN-koodeja, mallinumeroita, materiaaleja, takuutietoja tai toimitustietoja.',
            '- Älä keksi uusia ominaisuuksia, teknisiä arvoja tai lupauksia.',
            '- Jos jokin tuotetieto näkyy alkuperäisessä kuvauksessa, säilytä se täsmälleen samana.',
            '',
            'Tuotteen nimi: ' . (get_the_title($post) ?: ''),
        );

        foreach ($meta as $label => $value) {
            if ($value !== '') {
                $lines[] = $label . ': ' . $value;
            }
        }

        return implode("\n", $lines);
    }

    private function strip_product_context_from_response($text) {
        $text = trim((string) $text);
        $markers = array('Muokattava tuotekuvaus:', 'Tuotekuvaus:', 'Muokattu tuotekuvaus:');
        foreach ($markers as $marker) {
            $pos = humantone_stripos($text, $marker);
            if ($pos !== false) {
                $text = trim(humantone_substr($text, $pos + humantone_strlen($marker)));
            }
        }
        return $text;
    }

    private function get_product_meta_summary($product_id) {
        $meta = array(
            'SKU' => (string) get_post_meta($product_id, '_sku', true),
            'Hinta' => (string) get_post_meta($product_id, '_price', true),
            'Normaalihinta' => (string) get_post_meta($product_id, '_regular_price', true),
            'Alennushinta' => (string) get_post_meta($product_id, '_sale_price', true),
            'Paino' => (string) get_post_meta($product_id, '_weight', true),
            'Pituus' => (string) get_post_meta($product_id, '_length', true),
            'Leveys' => (string) get_post_meta($product_id, '_width', true),
            'Korkeus' => (string) get_post_meta($product_id, '_height', true),
        );
        return array_filter($meta, function ($value) {
            return $value !== '';
        });
    }

    private function analyze_product_facts($content, $product_id = 0) {
        $content = wp_strip_all_tags((string) $content);
        $facts = array(
            'numbers' => array(),
            'codes' => array(),
            'sku' => array(),
            'meta' => array(),
        );

        if (preg_match_all('/\b\d+(?:[,.]\d+)?\s?(?:cm|mm|m|kg|g|ml|l|w|kw|v|hz|mah|gb|tb|€|eur|%|kpl)?\b/iu', $content, $matches)) {
            $facts['numbers'] = array_values(array_unique(array_map('trim', $matches[0])));
        }

        if (preg_match_all('/\b[A-ZÅÄÖ0-9]{2,}(?:[-_\/][A-ZÅÄÖ0-9]{2,})+\b/u', $content, $matches)) {
            $facts['codes'] = array_values(array_unique(array_map('trim', $matches[0])));
        }

        if (preg_match_all('/\b(?:SKU|EAN|GTIN|malli|mallinumero|tuotekoodi)\s*[:#-]?\s*([A-ZÅÄÖ0-9][A-ZÅÄÖ0-9._\-\/]{2,})\b/iu', $content, $matches)) {
            $facts['sku'] = array_values(array_unique(array_map('trim', $matches[1])));
        }

        if ($product_id) {
            foreach ($this->get_product_meta_summary($product_id) as $label => $value) {
                $facts['meta'][$label] = $value;
            }
        }

        return $facts;
    }

    private function compare_product_facts($original, $rewritten, $product_id = 0) {
        $original_facts = $this->analyze_product_facts($original, $product_id);
        $rewritten_facts = $this->analyze_product_facts($rewritten, $product_id);
        $warnings = array();

        foreach (array('numbers' => __('Numeroarvoja puuttuu muokatusta kuvauksesta.', 'humantone'), 'codes' => __('Koodeja tai mallinumeroita puuttuu muokatusta kuvauksesta.', 'humantone'), 'sku' => __('SKU/EAN/GTIN-tyyppisiä tunnisteita puuttuu muokatusta kuvauksesta.', 'humantone')) as $key => $message) {
            $missing = array_values(array_diff($original_facts[$key], $rewritten_facts[$key]));
            if (!empty($missing)) {
                $warnings[] = array(
                    'type' => $key,
                    'message' => $message,
                    'missing' => $missing,
                    'original' => count($original_facts[$key]),
                    'rewritten' => count($rewritten_facts[$key]),
                    'severity' => 'blocking',
                    'blocking' => true,
                );
            }
        }

        foreach ($original_facts['meta'] as $label => $value) {
            if ($value !== '' && stripos((string) $rewritten, (string) $value) === false && stripos((string) $original, (string) $value) !== false) {
                $warnings[] = array(
                    'type' => 'meta',
                    'message' => sprintf(__('%s-arvo saattaa puuttua muokatusta kuvauksesta.', 'humantone'), $label),
                    'missing' => array($value),
                    'original' => 1,
                    'rewritten' => 0,
                    'severity' => 'blocking',
                    'blocking' => true,
                );
            }
        }

        return array(
            'originalFacts' => $original_facts,
            'rewrittenFacts' => $rewritten_facts,
            'warnings' => $warnings,
        );
    }

    private function copy_post_assets_to_draft($source_post, $target_post_id) {
        $target_post_id = absint($target_post_id);
        if (!$source_post || !$target_post_id) {
            return;
        }

        $all_meta = get_post_meta($source_post->ID);
        foreach ($all_meta as $key => $values) {
            if (in_array($key, array('_edit_lock', '_edit_last'), true)) {
                continue;
            }
            foreach ($values as $value) {
                add_post_meta($target_post_id, $key, maybe_unserialize($value));
            }
        }

        $thumbnail_id = get_post_thumbnail_id($source_post->ID);
        if ($thumbnail_id) {
            set_post_thumbnail($target_post_id, $thumbnail_id);
        }

        $taxonomies = get_object_taxonomies($source_post->post_type);
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_object_terms($source_post->ID, $taxonomy, array('fields' => 'ids'));
            if (!is_wp_error($terms)) {
                wp_set_object_terms($target_post_id, $terms, $taxonomy);
            }
        }
    }

    private function create_product_draft_copy($post, $rewritten, $field) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'draft',
            'post_title' => sprintf(__('WP Sanasepän tuoteversio: %s', 'humantone'), get_the_title($post) ?: __('(ei otsikkoa)', 'humantone')),
            'post_content' => $field === 'long' ? wp_slash($rewritten) : $post->post_content,
            'post_excerpt' => $field === 'short' ? wp_slash($rewritten) : $post->post_excerpt,
            'post_author' => get_current_user_id(),
            'post_parent' => $post->post_parent,
            'comment_status' => $post->comment_status,
            'ping_status' => $post->ping_status,
        );

        $new_id = wp_insert_post($args, true);
        if (is_wp_error($new_id)) {
            return $new_id;
        }

        $all_meta = get_post_meta($post->ID);
        $skip_meta = array(
            '_edit_lock',
            '_edit_last',
            '_sku',
            '_global_unique_id',
        );
        foreach ($all_meta as $key => $values) {
            if (in_array($key, $skip_meta, true)) {
                continue;
            }
            foreach ($values as $value) {
                add_post_meta($new_id, $key, maybe_unserialize($value));
            }
        }
        add_post_meta($new_id, '_humantone_source_product_id', (int) $post->ID, true);

        $taxonomies = get_object_taxonomies('product');
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_object_terms($post->ID, $taxonomy, array('fields' => 'ids'));
            if (!is_wp_error($terms)) {
                wp_set_object_terms($new_id, $terms, $taxonomy);
            }
        }

        return $new_id;
    }

    private function create_draft_copy($post, $rewritten) {
        $new_id = wp_insert_post(array(
            'post_type' => $post->post_type,
            'post_status' => 'draft',
            'post_title' => sprintf(__('WP Sanasepän versio: %s', 'humantone'), get_the_title($post) ?: __('(ei otsikkoa)', 'humantone')),
            'post_content' => wp_slash($rewritten),
            'post_author' => get_current_user_id(),
            'post_parent' => $post->post_parent,
            'post_excerpt' => $post->post_excerpt,
            'menu_order' => $post->menu_order,
            'comment_status' => $post->comment_status,
            'ping_status' => $post->ping_status,
        ), true);

        if (is_wp_error($new_id)) {
            return $new_id;
        }

        $this->copy_post_assets_to_draft($post, $new_id);

        return $new_id;
    }

    private function save_rewritten_content($post, $rewritten, $save_mode, $original_stats, $rewritten_stats, $warnings, $history_args = array()) {
        $blocking_error = $this->maybe_block_save($warnings);
        if (is_wp_error($blocking_error)) {
            return $blocking_error;
        }

        if ($save_mode === 'update_original') {
            $page_builder = $this->detect_page_builder($post->ID);
            if (HumanTone_Settings::get_safety_flag('block_page_builder_overwrite') && !empty($page_builder['detected'])) {
                return new WP_Error(
                    'humantone_page_builder_overwrite_blocked',
                    sprintf(__('Turvallinen tallennus esti alkuperäisen korvaamisen, koska sisältö näyttää käyttävän sivunrakentajaa: %s. Tallenna muokattu versio uutena luonnoksena tai poista esto asetuksista.', 'humantone'), implode(', ', $page_builder['builders'])),
                    array('status' => 400, 'pageBuilder' => $page_builder)
                );
            }

            $updated = wp_update_post(array(
                'ID' => $post->ID,
                'post_content' => wp_slash($rewritten),
            ), true);

            if (is_wp_error($updated)) {
                return $updated;
            }

            $history_args['save_mode'] = 'update_original';
            $history_args['warnings'] = $warnings;
            if (empty($history_args['action'])) {
                $history_args['action'] = 'save_post';
            }
            $history_id = $this->log_history($post, $post->ID, $rewritten, $history_args);

            return rest_ensure_response(array(
                'success' => true,
                'historyId' => $history_id,
                'content' => $rewritten,
                'postId' => $post->ID,
                'editLink' => get_edit_post_link($post->ID, 'raw'),
                'originalStats' => $original_stats,
                'rewrittenStats' => $rewritten_stats,
                'warnings' => $warnings,
                'safetyChecklist' => $this->build_content_safety_checklist($post, $original_stats, $rewritten_stats, $warnings, $post->ID),
                'safeToSave' => !$this->has_blocking_warnings($warnings),
                'pageBuilder' => $this->detect_page_builder($post->ID),
                'originalAiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($post->post_content),
                'rewrittenAiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($rewritten),
                'message' => __('Alkuperäinen julkaisu päivitettiin.', 'humantone'),
            ));
        }

        $new_post_id = $this->create_draft_copy($post, $rewritten);

        if (is_wp_error($new_post_id)) {
            return $new_post_id;
        }

        $asset_error = $this->maybe_block_copied_asset_loss($post, $new_post_id);
        if (is_wp_error($asset_error)) {
            wp_trash_post($new_post_id);
            return $asset_error;
        }

        $history_args['save_mode'] = 'draft_copy';
        $history_args['warnings'] = $warnings;
        if (empty($history_args['action'])) {
            $history_args['action'] = 'save_post';
        }
        $history_id = $this->log_history($post, $new_post_id, $rewritten, $history_args);


        return rest_ensure_response(array(
            'success' => true,
            'historyId' => $history_id,
            'content' => $rewritten,
            'postId' => $new_post_id,
            'editLink' => get_edit_post_link($new_post_id, 'raw'),
            'originalStats' => $original_stats,
            'rewrittenStats' => $rewritten_stats,
            'warnings' => $warnings,
            'safetyChecklist' => $this->build_content_safety_checklist($post, $original_stats, $rewritten_stats, $warnings, $new_post_id),
            'safeToSave' => !$this->has_blocking_warnings($warnings),
            'originalAiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($post->post_content),
            'rewrittenAiPhraseAnalysis' => HumanTone_AI_Phrases::analyze($rewritten),
            'message' => __('Muokattu versio tallennettiin uutena luonnoksena.', 'humantone'),
        ));
    }

    private function analyze_content($content) {
        $content = (string) $content;
        $plain = wp_strip_all_tags(strip_shortcodes($content));
        $word_count = str_word_count($plain, 0, 'ÅÄÖåäö');

        return array(
            'characters' => humantone_strlen($content),
            'words' => $word_count,
            'headings' => $this->count_pattern('/<h[1-6][^>]*>/i', $content) + $this->count_pattern('/<!--\s*wp:heading\b/i', $content),
            'links' => $this->count_pattern('/<a\s[^>]*href=/i', $content),
            'images' => $this->count_pattern('/<img\s/i', $content) + $this->count_pattern('/<!--\s*wp:image\b/i', $content),
            'shortcodes' => $this->count_pattern('/\[[A-Za-z_][A-Za-z0-9_:-]*(?:\s[^\]]*)?\]/', $content),
            'blocks' => $this->count_pattern('/<!--\s*wp:/i', $content),
            'titleCaseHeadings' => HumanTone_Heading_Case::count_title_case_headings($content),
            'aiPhrases' => HumanTone_AI_Phrases::count_total($content),
        );
    }

    private function compare_content_stats($original, $rewritten) {
        $warnings = array();
        $exact_keys = array(
            'headings' => __('Otsikoiden määrä muuttui.', 'humantone'),
            'links' => __('Linkkien määrä muuttui.', 'humantone'),
            'images' => __('Kuvien määrä muuttui.', 'humantone'),
            'shortcodes' => __('Lyhytkoodien määrä muuttui.', 'humantone'),
            'blocks' => __('WordPress-lohkojen määrä muuttui.', 'humantone'),
        );
        $structure_block_keys = array('links', 'images', 'shortcodes', 'blocks');
        $block_structure_loss = HumanTone_Settings::get_safety_flag('block_structure_loss');

        foreach ($exact_keys as $key => $message) {
            $original_count = isset($original[$key]) ? (int) $original[$key] : 0;
            $rewritten_count = isset($rewritten[$key]) ? (int) $rewritten[$key] : 0;
            if ($original_count !== $rewritten_count) {
                $is_loss = $rewritten_count < $original_count;
                $blocking = $block_structure_loss && $is_loss && in_array($key, $structure_block_keys, true);
                $warnings[] = array(
                    'type' => $key,
                    'message' => $blocking ? $message . ' ' . __('Tallennus estetään, koska elementtejä katosi.', 'humantone') : $message,
                    'original' => $original_count,
                    'rewritten' => $rewritten_count,
                    'severity' => $blocking ? 'blocking' : 'warning',
                    'blocking' => $blocking,
                );
            }
        }

        $original_words = max(1, (int) $original['words']);
        $change_percent = round(((int) $rewritten['words'] - $original_words) / $original_words * 100);
        if (abs($change_percent) >= 30) {
            $warnings[] = array(
                'type' => 'length',
                'message' => sprintf(__('Sanamäärä muuttui %s%%. Tarkista, että merkitys säilyi.', 'humantone'), $change_percent > 0 ? '+' . $change_percent : (string) $change_percent),
                'original' => (int) $original['words'],
                'rewritten' => (int) $rewritten['words'],
                'severity' => 'warning',
                'blocking' => false,
            );
        }

        if ((int) $rewritten['aiPhrases'] > 0 && (int) $rewritten['aiPhrases'] >= (int) $original['aiPhrases']) {
            $warnings[] = array(
                'type' => 'ai_phrases',
                'message' => __('Muokatussa sisällössä on yhä mahdollisia AI-fraaseja.', 'humantone'),
                'original' => (int) $original['aiPhrases'],
                'rewritten' => (int) $rewritten['aiPhrases'],
                'severity' => 'warning',
                'blocking' => false,
            );
        }

        if ((int) $rewritten['titleCaseHeadings'] > 0) {
            $warnings[] = array(
                'type' => 'title_case_headings',
                'message' => __('Muokatussa sisällössä on yhä otsikoita, joissa moni sana alkaa isolla alkukirjaimella.', 'humantone'),
                'original' => (int) $original['titleCaseHeadings'],
                'rewritten' => (int) $rewritten['titleCaseHeadings'],
                'severity' => 'warning',
                'blocking' => false,
            );
        }

        return $warnings;
    }

    private function has_blocking_warnings($warnings) {
        if (!is_array($warnings)) {
            return false;
        }
        foreach ($warnings as $warning) {
            if (!empty($warning['blocking']) || (isset($warning['severity']) && $warning['severity'] === 'blocking')) {
                return true;
            }
        }
        return false;
    }

    private function maybe_block_save($warnings) {
        if (!$this->has_blocking_warnings($warnings)) {
            return null;
        }
        return new WP_Error(
            'humantone_safe_save_blocked',
            __('Turvallinen tallennus esti tallennuksen, koska muokattu sisältö näyttää kadottavan linkkejä, kuvia, lyhytkoodeja, lohkoja tai tuotteen faktatietoja. Korjaa sisältö käsin tai muuta asetusta kohdassa Asetukset → WP Sanaseppä → Turvallinen tallennus.', 'humantone'),
            array('status' => 400, 'warnings' => $warnings)
        );
    }

    private function maybe_block_copied_asset_loss($source_post, $target_post_id) {
        if (!$source_post || !$target_post_id) {
            return null;
        }

        $problems = array();

        $source_thumb = absint(get_post_thumbnail_id($source_post->ID));
        $target_thumb = absint(get_post_thumbnail_id($target_post_id));
        if (HumanTone_Settings::get_safety_flag('block_thumbnail_loss') && $source_thumb && $source_thumb !== $target_thumb) {
            $problems[] = __('artikkelikuva', 'humantone');
        }

        if (HumanTone_Settings::get_safety_flag('block_excerpt_loss') && trim((string) $source_post->post_excerpt) !== '' && trim((string) get_post_field('post_excerpt', $target_post_id)) === '') {
            $problems[] = __('ote', 'humantone');
        }

        if (HumanTone_Settings::get_safety_flag('block_taxonomy_loss')) {
            $taxonomies = get_object_taxonomies($source_post->post_type);
            foreach ($taxonomies as $taxonomy) {
                $source_terms = wp_get_object_terms($source_post->ID, $taxonomy, array('fields' => 'ids'));
                $target_terms = wp_get_object_terms($target_post_id, $taxonomy, array('fields' => 'ids'));
                if (!is_wp_error($source_terms) && !is_wp_error($target_terms) && count($source_terms) > count($target_terms)) {
                    $problems[] = __('kategoriat tai avainsanat', 'humantone');
                    break;
                }
            }
        }

        if (HumanTone_Settings::get_safety_flag('block_seo_meta_loss')) {
            $source_seo = $this->get_seo_meta_summary($source_post->ID);
            $target_seo = $this->get_seo_meta_summary($target_post_id);
            foreach ($source_seo as $key => $value) {
                if ($value !== '' && (!isset($target_seo[$key]) || (string) $target_seo[$key] !== (string) $value)) {
                    $problems[] = __('SEO-metatiedot', 'humantone');
                    break;
                }
            }
        }


        if (HumanTone_Settings::get_safety_flag('block_acf_meta_loss')) {
            $source_acf = $this->get_acf_meta_summary($source_post->ID);
            $target_acf = $this->get_acf_meta_summary($target_post_id);
            foreach ($source_acf as $key => $value) {
                if (!isset($target_acf[$key]) || (string) $target_acf[$key] !== (string) $value) {
                    $problems[] = __('ACF-kentät', 'humantone');
                    break;
                }
            }
        }

        if (empty($problems)) {
            return null;
        }

        return new WP_Error(
            'humantone_asset_copy_blocked',
            sprintf(__('Turvallinen tallennus esti luonnoksen luonnin, koska seuraavia tietoja ei saatu säilytettyä: %s.', 'humantone'), implode(', ', array_unique($problems))),
            array('status' => 400)
        );
    }

    private function build_content_safety_checklist($post, $original_stats, $rewritten_stats, $warnings, $target_post_id = 0) {
        $items = array();
        $warning_map = array();
        foreach ((array) $warnings as $warning) {
            if (isset($warning['type'])) {
                $warning_map[$warning['type']] = $warning;
            }
        }

        foreach (array(
            'links' => __('Linkit', 'humantone'),
            'images' => __('Sisällön kuvat', 'humantone'),
            'shortcodes' => __('Lyhytkoodit', 'humantone'),
            'blocks' => __('WordPress-lohkot', 'humantone'),
            'headings' => __('Otsikot', 'humantone'),
        ) as $key => $label) {
            $original_count = isset($original_stats[$key]) ? (int) $original_stats[$key] : 0;
            $rewritten_count = isset($rewritten_stats[$key]) ? (int) $rewritten_stats[$key] : 0;
            $warning = isset($warning_map[$key]) ? $warning_map[$key] : array();
            $items[] = array(
                'key' => $key,
                'label' => $label,
                'original' => $original_count,
                'rewritten' => $rewritten_count,
                'status' => !empty($warning['blocking']) ? 'blocked' : ($original_count === $rewritten_count ? 'ok' : 'warning'),
                'message' => !empty($warning['message']) ? $warning['message'] : __('Säilyy', 'humantone'),
            );
        }

        $source_thumb = $post ? absint(get_post_thumbnail_id($post->ID)) : 0;
        $target_thumb = $target_post_id ? absint(get_post_thumbnail_id($target_post_id)) : 0;
        $thumb_status = 'ok';
        $thumb_message = $source_thumb ? __('Artikkelikuva säilyy tallennuksessa.', 'humantone') : __('Alkuperäisessä sisällössä ei ole artikkelikuvaa.', 'humantone');
        if ($target_post_id && $source_thumb && $source_thumb !== $target_thumb) {
            $thumb_status = HumanTone_Settings::get_safety_flag('block_thumbnail_loss') ? 'blocked' : 'warning';
            $thumb_message = __('Artikkelikuva ei siirtynyt uuteen luonnokseen.', 'humantone');
        }
        $items[] = array(
            'key' => 'featured_image',
            'label' => __('Artikkelikuva', 'humantone'),
            'original' => $source_thumb ? 1 : 0,
            'rewritten' => $target_post_id ? ($target_thumb ? 1 : 0) : ($source_thumb ? 1 : 0),
            'status' => $thumb_status,
            'message' => $thumb_message,
        );

        $source_excerpt = $post && trim((string) $post->post_excerpt) !== '' ? 1 : 0;
        $target_excerpt = $source_excerpt;
        if ($target_post_id) {
            $target_excerpt = trim((string) get_post_field('post_excerpt', $target_post_id)) !== '' ? 1 : 0;
        }
        $excerpt_status = ($source_excerpt && !$target_excerpt) ? (HumanTone_Settings::get_safety_flag('block_excerpt_loss') ? 'blocked' : 'warning') : 'ok';
        $items[] = array(
            'key' => 'excerpt',
            'label' => __('Ote', 'humantone'),
            'original' => $source_excerpt,
            'rewritten' => $target_excerpt,
            'status' => $excerpt_status,
            'message' => $source_excerpt ? ($target_excerpt ? __('Säilyy', 'humantone') : __('Ote puuttuu muokatusta versiosta.', 'humantone')) : __('Alkuperäisessä sisällössä ei ole otetta.', 'humantone'),
        );

        $source_terms_count = 0;
        $target_terms_count = 0;
        if ($post) {
            $taxonomies = get_object_taxonomies($post->post_type);
            foreach ($taxonomies as $taxonomy) {
                $source_terms = wp_get_object_terms($post->ID, $taxonomy, array('fields' => 'ids'));
                if (!is_wp_error($source_terms)) {
                    $source_terms_count += count($source_terms);
                }
                if ($target_post_id) {
                    $target_terms = wp_get_object_terms($target_post_id, $taxonomy, array('fields' => 'ids'));
                    if (!is_wp_error($target_terms)) {
                        $target_terms_count += count($target_terms);
                    }
                }
            }
        }
        if (!$target_post_id) {
            $target_terms_count = $source_terms_count;
        }
        $taxonomy_status = ($source_terms_count > $target_terms_count) ? (HumanTone_Settings::get_safety_flag('block_taxonomy_loss') ? 'blocked' : 'warning') : 'ok';
        $items[] = array(
            'key' => 'taxonomies',
            'label' => __('Kategoriat ja avainsanat', 'humantone'),
            'original' => $source_terms_count,
            'rewritten' => $target_terms_count,
            'status' => $taxonomy_status,
            'message' => $source_terms_count ? ($source_terms_count === $target_terms_count ? __('Säilyvät', 'humantone') : __('Kaikki termit eivät siirtyneet.', 'humantone')) : __('Alkuperäisessä sisällössä ei ole termejä.', 'humantone'),
        );

        $source_seo = $post ? $this->get_seo_meta_summary($post->ID) : array();
        $target_seo = $target_post_id ? $this->get_seo_meta_summary($target_post_id) : $source_seo;
        $source_seo_count = count($source_seo);
        $target_seo_count = count($target_seo);
        $seo_missing = array();
        foreach ($source_seo as $key => $value) {
            if ($value !== '' && (!isset($target_seo[$key]) || (string) $target_seo[$key] !== (string) $value)) {
                $seo_missing[] = $key;
            }
        }
        $seo_status = !empty($seo_missing) ? (HumanTone_Settings::get_safety_flag('block_seo_meta_loss') ? 'blocked' : 'warning') : 'ok';
        $items[] = array(
            'key' => 'seo_meta',
            'label' => __('SEO-metatiedot', 'humantone'),
            'original' => $source_seo_count,
            'rewritten' => $target_seo_count,
            'status' => $seo_status,
            'message' => $source_seo_count ? (empty($seo_missing) ? __('SEO-metatiedot säilyvät.', 'humantone') : __('Osa SEO-metatiedoista ei siirtynyt täsmälleen.', 'humantone')) : __('Alkuperäisessä sisällössä ei ole tunnistettuja SEO-metatietoja.', 'humantone'),
        );


        $source_acf = $post ? $this->get_acf_meta_summary($post->ID) : array();
        $target_acf = $target_post_id ? $this->get_acf_meta_summary($target_post_id) : $source_acf;
        $source_acf_count = count($source_acf);
        $target_acf_count = count($target_acf);
        $acf_missing = array();
        foreach ($source_acf as $key => $value) {
            if (!isset($target_acf[$key]) || (string) $target_acf[$key] !== (string) $value) {
                $acf_missing[] = $key;
            }
        }
        $acf_status = !empty($acf_missing) ? (HumanTone_Settings::get_safety_flag('block_acf_meta_loss') ? 'blocked' : 'warning') : 'ok';
        $items[] = array(
            'key' => 'acf_meta',
            'label' => __('ACF-kentät', 'humantone'),
            'original' => $source_acf_count,
            'rewritten' => $target_acf_count,
            'status' => $acf_status,
            'message' => $source_acf_count ? (empty($acf_missing) ? __('ACF-kenttien arvot säilyvät.', 'humantone') : __('Osa ACF-kenttien arvoista ei siirtynyt täsmälleen.', 'humantone')) : __('Alkuperäisessä sisällössä ei ole tunnistettuja ACF-kenttiä.', 'humantone'),
        );

        $page_builder = $post ? $this->detect_page_builder($post->ID) : array('detected' => false, 'builders' => array());
        $builder_names = !empty($page_builder['builders']) ? implode(', ', $page_builder['builders']) : '';
        $builder_blocked = !empty($page_builder['detected']) && HumanTone_Settings::get_safety_flag('block_page_builder_overwrite');
        $items[] = array(
            'key' => 'page_builder',
            'label' => __('Sivunrakentaja', 'humantone'),
            'original' => !empty($page_builder['detected']) ? 1 : 0,
            'rewritten' => !empty($page_builder['detected']) ? 1 : 0,
            'status' => $builder_blocked ? 'warning' : 'ok',
            'message' => !empty($page_builder['detected']) ? sprintf(__('Havaittu: %s. Alkuperäisen korvaaminen estetään, mutta uuden luonnoksen luonti on sallittu.', 'humantone'), $builder_names) : __('Sivunrakentajaa ei havaittu.', 'humantone'),
        );

        return $items;
    }

    private function get_seo_meta_keys() {
        return array(
            '_yoast_wpseo_title',
            '_yoast_wpseo_metadesc',
            '_yoast_wpseo_focuskw',
            '_yoast_wpseo_canonical',
            '_yoast_wpseo_opengraph-title',
            '_yoast_wpseo_opengraph-description',
            '_yoast_wpseo_twitter-title',
            '_yoast_wpseo_twitter-description',
            'rank_math_title',
            'rank_math_description',
            'rank_math_focus_keyword',
            'rank_math_canonical_url',
            'rank_math_facebook_title',
            'rank_math_facebook_description',
            'rank_math_twitter_title',
            'rank_math_twitter_description',
            '_aioseo_title',
            '_aioseo_description',
            '_aioseo_keywords',
        );
    }

    private function get_seo_meta_summary($post_id) {
        $post_id = absint($post_id);
        $summary = array();
        if (!$post_id) {
            return $summary;
        }

        foreach ($this->get_seo_meta_keys() as $key) {
            $value = get_post_meta($post_id, $key, true);
            if (is_array($value) || is_object($value)) {
                $value = wp_json_encode($value);
            }
            $value = trim((string) $value);
            if ($value !== '') {
                $summary[$key] = $value;
            }
        }

        return $summary;
    }

    private function get_acf_meta_summary($post_id) {
        $post_id = absint($post_id);
        $summary = array();
        if (!$post_id) {
            return $summary;
        }

        $all_meta = get_post_meta($post_id);
        if (!is_array($all_meta)) {
            return $summary;
        }

        foreach ($all_meta as $key => $values) {
            $key = (string) $key;
            if ($key === '' || strpos($key, '_') === 0) {
                continue;
            }

            $reference = get_post_meta($post_id, '_' . $key, true);
            if (!is_string($reference) || strpos($reference, 'field_') !== 0) {
                continue;
            }

            $value = get_post_meta($post_id, $key, true);
            $summary[$key] = $this->normalize_meta_value_for_compare($value);
        }

        ksort($summary);
        return $summary;
    }

    private function normalize_meta_value_for_compare($value) {
        if (is_array($value) || is_object($value)) {
            $encoded = wp_json_encode($value);
            return $encoded ? $encoded : serialize($value);
        }
        return (string) $value;
    }



    private function preview_content_html($content) {
        $content = (string) $content;
        if ($content === '') {
            return '';
        }

        // Remove WordPress block comments but keep the actual human-facing HTML markup.
        $content = preg_replace('/<!--\s*\/?wp:[\s\S]*?-->/', "\n", $content);

        // Avoid rendering risky/non-readable elements in the admin preview.
        $content = preg_replace('/<\s*(script|style|iframe|object|embed|svg)\b[\s\S]*?<\s*\/\s*\1\s*>/i', '', $content);

        $allowed = wp_kses_allowed_html('post');
        unset($allowed['script'], $allowed['style'], $allowed['iframe'], $allowed['object'], $allowed['embed'], $allowed['svg']);

        $html = wp_kses($content, $allowed);
        $html = trim($html);

        if ($html === '') {
            return $this->preview_text_as_html($this->readable_content_text($content));
        }

        return $html;
    }

    private function preview_text_as_html($text) {
        $text = trim((string) $text);
        if ($text === '') {
            return '';
        }

        $paragraphs = preg_split('/\n{2,}/', $text);
        $html = '';
        foreach ($paragraphs as $paragraph) {
            $paragraph = trim($paragraph);
            if ($paragraph === '') {
                continue;
            }
            $html .= '<p>' . esc_html($paragraph) . '</p>';
        }

        return $html;
    }


    private function trim_readable_text_preserving_paragraphs($text, $word_limit = 260) {
        $text = trim((string) $text);
        if ($text === '') {
            return '';
        }

        $paragraphs = preg_split('/\n{2,}/', $text);
        $out = array();
        $used = 0;
        $limit = max(20, absint($word_limit));

        foreach ($paragraphs as $paragraph) {
            $paragraph = trim($paragraph);
            if ($paragraph === '') {
                continue;
            }

            $words = preg_split('/\s+/u', $paragraph, -1, PREG_SPLIT_NO_EMPTY);
            if (!$words) {
                continue;
            }

            $remaining = $limit - $used;
            if ($remaining <= 0) {
                break;
            }

            if (count($words) <= $remaining) {
                $out[] = $paragraph;
                $used += count($words);
                continue;
            }

            $out[] = implode(' ', array_slice($words, 0, $remaining)) . '...';
            $used = $limit;
            break;
        }

        return trim(implode("\n\n", $out));
    }

    private function preview_content_html_excerpt($content, $word_limit = 260) {
        $html = $this->preview_content_html($content);
        if ($html === '') {
            return '';
        }

        $blocks = preg_split('/(<\/?(?:h[1-6]|p|ul|ol|li|blockquote|table|tr|td|th|figure|figcaption|pre)\b[^>]*>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        if (!$blocks) {
            return $this->preview_text_as_html($this->trim_readable_text_preserving_paragraphs($this->readable_content_text($html), $word_limit));
        }

        $out = '';
        $used = 0;
        $limit = max(20, absint($word_limit));

        foreach ($blocks as $part) {
            if (preg_match('/^<\/?(?:h[1-6]|p|ul|ol|li|blockquote|table|tr|td|th|figure|figcaption|pre)\b[^>]*>$/i', $part)) {
                $out .= $part;
                continue;
            }

            $plain = trim(wp_strip_all_tags($part, true));
            if ($plain === '') {
                $out .= $part;
                continue;
            }

            $words = preg_split('/\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY);
            $remaining = $limit - $used;
            if ($remaining <= 0) {
                break;
            }

            if (count($words) <= $remaining) {
                $out .= $part;
                $used += count($words);
                continue;
            }

            $trimmed = implode(' ', array_slice($words, 0, $remaining)) . '...';
            $out .= esc_html($trimmed);
            $used = $limit;
            break;
        }

        $out = trim($out);
        if ($out === '') {
            return $this->preview_text_as_html($this->trim_readable_text_preserving_paragraphs($this->readable_content_text($html), $word_limit));
        }

        $out = force_balance_tags($out);
        $allowed = wp_kses_allowed_html('post');
        unset($allowed['script'], $allowed['style'], $allowed['iframe'], $allowed['object'], $allowed['embed'], $allowed['svg']);
        return wp_kses($out, $allowed);
    }

    private function readable_content_text($content) {
        $content = (string) $content;
        if ($content === '') {
            return '';
        }

        // Remove WordPress block comments while keeping the human-facing HTML inside blocks.
        $content = preg_replace('/<!--\s*\/?wp:[\s\S]*?-->/', "\n", $content);

        // Add line breaks around common block-level elements before stripping tags.
        $content = preg_replace('/<\s*br\s*\/?>/i', "\n", $content);
        $content = preg_replace('/<\s*\/(p|div|section|article|header|footer|li|ul|ol|h[1-6]|blockquote|tr|table)\s*>/i', "\n", $content);
        $content = preg_replace('/<\s*(h[1-6]|p|li|blockquote|tr|table|ul|ol)\b[^>]*>/i', "\n", $content);

        $text = wp_strip_all_tags($content, true);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
        $text = str_replace("\xc2\xa0", ' ', $text);
        $text = preg_replace('/[ \t]+/', ' ', $text);
        $text = preg_replace('/\n[ \t]+/', "\n", $text);
        $text = preg_replace('/\n{3,}/', "\n\n", $text);

        return trim($text);
    }

    private function detect_page_builder($post_id) {
        $post_id = absint($post_id);
        $builders = array();

        if (!$post_id) {
            return array('detected' => false, 'builders' => array());
        }

        $post = get_post($post_id);
        $content = $post ? (string) $post->post_content : '';

        $elementor_data = get_post_meta($post_id, '_elementor_data', true);
        $elementor_mode = get_post_meta($post_id, '_elementor_edit_mode', true);
        if (!empty($elementor_data) || $elementor_mode === 'builder') {
            $builders[] = 'Elementor';
        }

        $divi_builder = get_post_meta($post_id, '_et_pb_use_builder', true);
        if ($divi_builder === 'on' || strpos($content, '[et_pb_') !== false || strpos($content, 'et_pb_section') !== false) {
            $builders[] = 'Divi';
        }

        $wpbakery_status = get_post_meta($post_id, '_wpb_vc_js_status', true);
        if ($wpbakery_status !== '' || strpos($content, '[vc_row') !== false || strpos($content, '[vc_column') !== false) {
            $builders[] = 'WPBakery';
        }

        $builders = array_values(array_unique($builders));

        return array(
            'detected' => !empty($builders),
            'builders' => $builders,
            'blockUpdateOriginal' => !empty($builders) && HumanTone_Settings::get_safety_flag('block_page_builder_overwrite'),
        );
    }

    private function detect_seo_plugins() {
        $plugins = array();
        if (defined('WPSEO_VERSION') || class_exists('WPSEO_Options')) {
            $plugins[] = 'Yoast SEO';
        }
        if (defined('RANK_MATH_VERSION') || class_exists('RankMath')) {
            $plugins[] = 'Rank Math';
        }
        if (defined('AIOSEO_VERSION') || class_exists('AIOSEO\Plugin\AIOSEO')) {
            $plugins[] = 'AIOSEO';
        }
        return $plugins;
    }

    private function count_pattern($pattern, $content) {
        if (preg_match_all($pattern, $content, $matches)) {
            return count($matches[0]);
        }
        return 0;
    }

    private function normalize_mode($mode) {
        $allowed_modes = array('natural', 'clearer', 'proofread', 'shorter', 'simplify', 'expert', 'sales', 'more_casual', 'more_formal', 'warmer', 'stronger_intro', 'better_cta', 'paragraph_flow', 'bullets', 'remove_ai_tone', 'fix_heading_case');
        return in_array($mode, $allowed_modes, true) ? $mode : 'natural';
    }

    private function normalize_content_type($content_type) {
        $allowed_types = array('general', 'blog', 'seo', 'landing_page', 'product', 'info_page', 'news', 'expert');
        return in_array($content_type, $allowed_types, true) ? $content_type : 'general';
    }

    private function normalize_profile_id($profile_id) {
        $profile_id = sanitize_key((string) $profile_id);
        $profiles = HumanTone_Settings::get_profiles();

        if ($profile_id && isset($profiles[$profile_id])) {
            return $profile_id;
        }

        return HumanTone_Settings::get_default_profile_id();
    }
}
