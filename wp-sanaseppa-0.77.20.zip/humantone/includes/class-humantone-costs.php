<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_Costs {
    const OPTION_NAME = 'humantone_cost_usage';
    const MAX_RECENT_CALLS = 100;
    const DEFAULT_VISIBLE_CALLS = 20;
    const DEFAULT_KEEP_CALLS = 50;

    public static function get_pricing_table() {
        return array(
            // USD per 1M tokens. Päivitä tarvittaessa OpenAI:n hinnaston muuttuessa.
            'gpt-5.4-nano' => array('input' => 0.05, 'output' => 0.20),
            'gpt-5.4-mini' => array('input' => 0.15, 'output' => 0.60),
            'gpt-5.4' => array('input' => 1.25, 'output' => 10.00),
            'gpt-5.5' => array('input' => 2.50, 'output' => 15.00),
            'gpt-4.1' => array('input' => 2.00, 'output' => 8.00),
            'gpt-4.1-mini' => array('input' => 0.40, 'output' => 1.60),
            'gpt-4.1-nano' => array('input' => 0.10, 'output' => 0.40),
        );
    }

    public static function price_for_model($model) {
        $model = (string) $model;
        $prices = self::get_pricing_table();
        if (isset($prices[$model])) {
            return $prices[$model];
        }
        foreach ($prices as $prefix => $price) {
            if (strpos($model, $prefix) === 0) {
                return $price;
            }
        }
        return array('input' => 0, 'output' => 0);
    }

    public static function normalize_usage($usage) {
        $usage = is_array($usage) ? $usage : array();
        $input = 0;
        $output = 0;
        if (isset($usage['prompt_tokens'])) {
            $input = absint($usage['prompt_tokens']);
        } elseif (isset($usage['input_tokens'])) {
            $input = absint($usage['input_tokens']);
        }
        if (isset($usage['completion_tokens'])) {
            $output = absint($usage['completion_tokens']);
        } elseif (isset($usage['output_tokens'])) {
            $output = absint($usage['output_tokens']);
        }
        return array(
            'input_tokens' => $input,
            'output_tokens' => $output,
            'total_tokens' => isset($usage['total_tokens']) ? absint($usage['total_tokens']) : ($input + $output),
            'estimated' => empty($usage),
        );
    }

    public static function calculate_cost_usd($model, $input_tokens, $output_tokens) {
        $price = self::price_for_model($model);
        if (empty($price['input']) && empty($price['output'])) {
            return 0;
        }
        return (($input_tokens / 1000000) * (float) $price['input']) + (($output_tokens / 1000000) * (float) $price['output']);
    }

    public static function log_usage($model, $usage, $source = 'direct', $context = 'rewrite') {
        $normalized = self::normalize_usage($usage);
        if ($normalized['input_tokens'] <= 0 && $normalized['output_tokens'] <= 0) {
            return;
        }
        $model = sanitize_text_field((string) $model);
        $source = sanitize_key((string) $source);
        $context = sanitize_key((string) $context);
        $cost = self::calculate_cost_usd($model, $normalized['input_tokens'], $normalized['output_tokens']);
        $date = current_time('Y-m-d');
        $month = current_time('Y-m');
        $data = get_option(self::OPTION_NAME, array());
        $data = is_array($data) ? $data : array();
        foreach (array('days', 'months', 'models') as $key) {
            if (!isset($data[$key]) || !is_array($data[$key])) {
                $data[$key] = array();
            }
        }
        foreach (array($date => 'days', $month => 'months', $model => 'models') as $bucket => $group) {
            if (!isset($data[$group][$bucket]) || !is_array($data[$group][$bucket])) {
                $data[$group][$bucket] = array('requests' => 0, 'input_tokens' => 0, 'output_tokens' => 0, 'total_tokens' => 0, 'cost_usd' => 0, 'estimated_requests' => 0);
            }
            $data[$group][$bucket]['requests'] += 1;
            $data[$group][$bucket]['input_tokens'] += $normalized['input_tokens'];
            $data[$group][$bucket]['output_tokens'] += $normalized['output_tokens'];
            $data[$group][$bucket]['total_tokens'] += $normalized['total_tokens'];
            $data[$group][$bucket]['cost_usd'] += $cost;
            if (!empty($normalized['estimated'])) {
                $data[$group][$bucket]['estimated_requests'] += 1;
            }
        }
        $event = array(
            'time' => current_time('mysql'),
            'model' => $model,
            'source' => $source,
            'context' => $context,
            'input_tokens' => $normalized['input_tokens'],
            'output_tokens' => $normalized['output_tokens'],
            'total_tokens' => $normalized['total_tokens'],
            'cost_usd' => $cost,
            'estimated' => !empty($normalized['estimated']) ? 1 : 0,
        );
        $data['recent'] = isset($data['recent']) && is_array($data['recent']) ? $data['recent'] : array();
        array_unshift($data['recent'], $event);
        $data['recent'] = array_slice($data['recent'], 0, self::MAX_RECENT_CALLS);
        $data['updated_at'] = current_time('mysql');
        update_option(self::OPTION_NAME, $data, false);
    }

    public static function get_summary() {
        $data = get_option(self::OPTION_NAME, array());
        $data = is_array($data) ? $data : array();
        $today = current_time('Y-m-d');
        $month = current_time('Y-m');
        $empty = array('requests' => 0, 'input_tokens' => 0, 'output_tokens' => 0, 'total_tokens' => 0, 'cost_usd' => 0, 'estimated_requests' => 0);
        return array(
            'today' => isset($data['days'][$today]) ? wp_parse_args($data['days'][$today], $empty) : $empty,
            'month' => isset($data['months'][$month]) ? wp_parse_args($data['months'][$month], $empty) : $empty,
            'recent' => isset($data['recent']) && is_array($data['recent']) ? $data['recent'] : array(),
            'updated_at' => isset($data['updated_at']) ? $data['updated_at'] : '',
        );
    }


    public static function count_recent() {
        $data = get_option(self::OPTION_NAME, array());
        $data = is_array($data) ? $data : array();
        return isset($data['recent']) && is_array($data['recent']) ? count($data['recent']) : 0;
    }

    public static function get_recent($limit = self::DEFAULT_VISIBLE_CALLS) {
        $data = get_option(self::OPTION_NAME, array());
        $data = is_array($data) ? $data : array();
        $recent = isset($data['recent']) && is_array($data['recent']) ? $data['recent'] : array();
        $limit = max(1, min(self::MAX_RECENT_CALLS, absint($limit)));
        return array_slice($recent, 0, $limit);
    }

    public static function prune_recent($keep = self::DEFAULT_KEEP_CALLS) {
        if (!current_user_can('manage_options')) {
            return new WP_Error('humantone_api_log_prune_no_permission', __('Vain pääkäyttäjä voi siivota API-kutsulokia.', 'humantone'), array('status' => 403));
        }

        $keep = max(10, min(self::MAX_RECENT_CALLS, absint($keep)));
        $data = get_option(self::OPTION_NAME, array());
        $data = is_array($data) ? $data : array();
        $recent = isset($data['recent']) && is_array($data['recent']) ? $data['recent'] : array();
        $before = count($recent);
        $data['recent'] = array_slice($recent, 0, $keep);
        $data['updated_at'] = current_time('mysql');
        update_option(self::OPTION_NAME, $data, false);

        return array(
            'success' => true,
            'kept' => count($data['recent']),
            'removed' => max(0, $before - count($data['recent'])),
            'message' => sprintf(__('API-kutsuloki siivottiin. Säilytettyjä rivejä: %1$d. Poistettuja rivejä: %2$d.', 'humantone'), count($data['recent']), max(0, $before - count($data['recent']))),
        );
    }

    public static function format_usd($amount) {
        return '$' . number_format_i18n((float) $amount, 4);
    }
}
