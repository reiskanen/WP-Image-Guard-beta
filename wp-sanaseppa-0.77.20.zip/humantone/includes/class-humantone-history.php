<?php
if (!defined('ABSPATH')) {
    exit;
}

class HumanTone_History {
    const OPTION_NAME = 'humantone_history';
    const MAX_ITEMS = 100;
    const DEFAULT_VISIBLE_ITEMS = 25;

    public static function add($data) {
        $items = self::get_all_raw();
        $record = wp_parse_args($data, array(
            'id' => self::generate_id(),
            'created_at' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'user_name' => self::current_user_name(),
            'source_post_id' => 0,
            'target_post_id' => 0,
            'post_type' => '',
            'field' => 'content',
            'action' => '',
            'save_mode' => '',
            'mode' => '',
            'content_type' => '',
            'profile_id' => '',
            'profile_name' => '',
            'original_title' => '',
            'original_content' => '',
            'original_excerpt' => '',
            'original_thumbnail_id' => 0,
            'new_title' => '',
            'new_content' => '',
            'new_excerpt' => '',
            'new_thumbnail_id' => 0,
            'warnings' => array(),
        ));

        array_unshift($items, $record);
        $items = array_slice($items, 0, self::MAX_ITEMS);
        update_option(self::OPTION_NAME, $items, false);
        return $record['id'];
    }

    public static function get_all($limit = self::DEFAULT_VISIBLE_ITEMS) {
        $items = array_filter(self::get_all_raw(), array(__CLASS__, 'current_user_can_view_record'));
        $items = array_slice(array_values($items), 0, max(1, min(self::MAX_ITEMS, absint($limit))));
        return array_map(array(__CLASS__, 'summarize'), $items);
    }

    public static function count_viewable() {
        return count(array_filter(self::get_all_raw(), array(__CLASS__, 'current_user_can_view_record')));
    }

    public static function count_all() {
        return count(self::get_all_raw());
    }

    public static function prune($keep = 50) {
        if (!current_user_can('manage_options')) {
            return new WP_Error('humantone_history_prune_no_permission', __('Vain pääkäyttäjä voi siivota historiaa.', 'humantone'), array('status' => 403));
        }

        $keep = max(10, min(self::MAX_ITEMS, absint($keep)));
        $items = self::get_all_raw();
        $before = count($items);
        $items = array_slice($items, 0, $keep);
        update_option(self::OPTION_NAME, $items, false);

        return array(
            'success' => true,
            'kept' => count($items),
            'removed' => max(0, $before - count($items)),
            'message' => sprintf(__('Historia siivottiin. Säilytettyjä rivejä: %1$d. Poistettuja rivejä: %2$d.', 'humantone'), count($items), max(0, $before - count($items))),
        );
    }

    public static function get($id) {
        $id = sanitize_text_field((string) $id);
        foreach (self::get_all_raw() as $record) {
            if (!empty($record['id']) && $record['id'] === $id) {
                return $record;
            }
        }
        return null;
    }

    public static function restore($id) {
        $record = self::get($id);
        if (!$record) {
            return new WP_Error('humantone_history_not_found', __('Historiatietoa ei löytynyt.', 'humantone'), array('status' => 404));
        }

        $post_id = absint($record['source_post_id']);
        if (!$post_id || !current_user_can('edit_post', $post_id)) {
            return new WP_Error('humantone_history_no_permission', __('Sinulla ei ole oikeutta palauttaa tätä sisältöä.', 'humantone'), array('status' => 403));
        }

        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('humantone_history_post_missing', __('Alkuperäistä sisältöä ei löytynyt.', 'humantone'), array('status' => 404));
        }

        $update = array('ID' => $post_id);
        if (isset($record['original_title']) && $record['original_title'] !== '') {
            $update['post_title'] = wp_slash($record['original_title']);
        }

        $field = isset($record['field']) ? $record['field'] : 'content';
        if ($post->post_type === 'product' && $field === 'short') {
            $update['post_excerpt'] = wp_slash(isset($record['original_excerpt']) ? $record['original_excerpt'] : '');
        } else {
            $update['post_content'] = wp_slash(isset($record['original_content']) ? $record['original_content'] : '');
            if ($post->post_type === 'product' && isset($record['original_excerpt'])) {
                $update['post_excerpt'] = wp_slash($record['original_excerpt']);
            }
        }

        $result = wp_update_post($update, true);
        if (is_wp_error($result)) {
            return $result;
        }

        if (array_key_exists('original_thumbnail_id', $record)) {
            $thumbnail_id = absint($record['original_thumbnail_id']);
            if ($thumbnail_id) {
                set_post_thumbnail($post_id, $thumbnail_id);
            } else {
                delete_post_thumbnail($post_id);
            }
        }

        self::mark_restored($id);

        return array(
            'success' => true,
            'postId' => $post_id,
            'editLink' => get_edit_post_link($post_id, 'raw'),
            'message' => __('Alkuperäinen versio palautettiin.', 'humantone'),
        );
    }

    private static function mark_restored($id) {
        $items = self::get_all_raw();
        foreach ($items as &$record) {
            if (!empty($record['id']) && $record['id'] === $id) {
                $record['restored_at'] = current_time('mysql');
                $record['restored_by'] = get_current_user_id();
                break;
            }
        }
        update_option(self::OPTION_NAME, $items, false);
    }


    private static function current_user_can_view_record($record) {
        if (current_user_can('manage_options')) {
            return true;
        }

        $current_user_id = get_current_user_id();
        if ($current_user_id && !empty($record['user_id']) && absint($record['user_id']) === $current_user_id) {
            return true;
        }

        $source_id = absint(isset($record['source_post_id']) ? $record['source_post_id'] : 0);
        $target_id = absint(isset($record['target_post_id']) ? $record['target_post_id'] : 0);

        return ($source_id && current_user_can('edit_post', $source_id)) || ($target_id && current_user_can('edit_post', $target_id));
    }

    private static function summarize($record) {
        $source_id = absint(isset($record['source_post_id']) ? $record['source_post_id'] : 0);
        $target_id = absint(isset($record['target_post_id']) ? $record['target_post_id'] : 0);
        $warnings = isset($record['warnings']) && is_array($record['warnings']) ? $record['warnings'] : array();
        return array(
            'id' => isset($record['id']) ? $record['id'] : '',
            'createdAt' => isset($record['created_at']) ? $record['created_at'] : '',
            'userName' => isset($record['user_name']) ? $record['user_name'] : '',
            'sourcePostId' => $source_id,
            'targetPostId' => $target_id,
            'sourceTitle' => $source_id ? (get_the_title($source_id) ?: (isset($record['original_title']) ? $record['original_title'] : '')) : '',
            'targetTitle' => $target_id ? (get_the_title($target_id) ?: '') : '',
            'postType' => isset($record['post_type']) ? $record['post_type'] : '',
            'field' => isset($record['field']) ? $record['field'] : 'content',
            'action' => isset($record['action']) ? $record['action'] : '',
            'saveMode' => isset($record['save_mode']) ? $record['save_mode'] : '',
            'mode' => isset($record['mode']) ? $record['mode'] : '',
            'contentType' => isset($record['content_type']) ? $record['content_type'] : '',
            'profileName' => isset($record['profile_name']) ? $record['profile_name'] : '',
            'warningCount' => count($warnings),
            'sourceThumbnailId' => absint(isset($record['original_thumbnail_id']) ? $record['original_thumbnail_id'] : 0),
            'targetThumbnailId' => absint(isset($record['new_thumbnail_id']) ? $record['new_thumbnail_id'] : 0),
            'restoredAt' => isset($record['restored_at']) ? $record['restored_at'] : '',
            'sourceEditLink' => ($source_id && current_user_can('edit_post', $source_id)) ? get_edit_post_link($source_id, 'raw') : '',
            'targetEditLink' => ($target_id && current_user_can('edit_post', $target_id)) ? get_edit_post_link($target_id, 'raw') : '',
            'canRestore' => $source_id && current_user_can('edit_post', $source_id) && (isset($record['save_mode']) && $record['save_mode'] === 'update_original') && empty($record['restored_at']),
        );
    }

    private static function get_all_raw() {
        $items = get_option(self::OPTION_NAME, array());
        return is_array($items) ? $items : array();
    }

    private static function generate_id() {
        return 'ht_' . gmdate('YmdHis') . '_' . wp_generate_password(8, false, false);
    }

    private static function current_user_name() {
        $user = wp_get_current_user();
        if ($user && $user->exists()) {
            return $user->display_name ?: $user->user_login;
        }
        return '';
    }
}
