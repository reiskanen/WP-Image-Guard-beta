<?php
/**
 * Plugin Name: WP Sanaseppä – suomenkielinen tekstityökalu
 * Plugin URI: https://wpplugi.com/wp-sanaseppa/
 * Description: Suomenkielinen WordPress-lisäosa tekstien korjaamiseen, brändiääneen ja sisällön siistimiseen.
 * Version: 0.77.20
 * Author: www.wppluggi.com
 * Author URI: https://www.wppluggi.com
 * Text Domain: humantone
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('HUMANTONE_VERSION', '0.77.20');
define('HUMANTONE_PLUGIN_FILE', __FILE__);
define('HUMANTONE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('HUMANTONE_PLUGIN_URL', plugin_dir_url(__FILE__));

if (!function_exists('humantone_strlen')) {
    function humantone_strlen($text) {
        $text = (string) $text;
        return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    }
}

if (!function_exists('humantone_substr')) {
    function humantone_substr($text, $start, $length = null) {
        $text = (string) $text;
        if (function_exists('mb_substr')) {
            return $length === null ? mb_substr($text, $start, null, 'UTF-8') : mb_substr($text, $start, $length, 'UTF-8');
        }
        return $length === null ? substr($text, $start) : substr($text, $start, $length);
    }
}

if (!function_exists('humantone_stripos')) {
    function humantone_stripos($haystack, $needle, $offset = 0) {
        $haystack = (string) $haystack;
        $needle = (string) $needle;
        if (function_exists('mb_stripos')) {
            return mb_stripos($haystack, $needle, $offset, 'UTF-8');
        }
        return stripos($haystack, $needle, $offset);
    }
}

require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-license.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-settings.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-costs.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-heading-case.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-ai-phrases.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-ai-client.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-history.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-rest.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-editor.php';
require_once HUMANTONE_PLUGIN_DIR . 'includes/class-humantone-tools.php';

final class HumanTone_Plugin {
    public function __construct() {
        new HumanTone_License();
        new HumanTone_Settings();
        new HumanTone_REST();
        new HumanTone_Editor();
        new HumanTone_Tools();

        add_filter('plugin_action_links_' . plugin_basename(HUMANTONE_PLUGIN_FILE), array($this, 'add_plugin_action_links'));
        add_action('admin_init', array($this, 'redirect_legacy_admin_pages'));
    }

    public function redirect_legacy_admin_pages() {
        if (!is_admin() || !isset($_GET['page'])) {
            return;
        }

        $page = sanitize_key(wp_unslash($_GET['page']));
        if ($page !== 'humantone' && $page !== 'humantone-tool') {
            return;
        }

        $target_page = $page === 'humantone-tool' ? 'wp-sanaseppa' : 'wp-sanaseppa-settings';
        $args = array('page' => $target_page);

        if (isset($_GET['tab'])) {
            $args['tab'] = sanitize_key(wp_unslash($_GET['tab']));
        }
        if (isset($_GET['tool_tab'])) {
            $args['tool_tab'] = sanitize_key(wp_unslash($_GET['tool_tab']));
        }

        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    public function add_plugin_action_links($links) {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=wp-sanaseppa-settings')),
            esc_html__('Asetukset', 'humantone')
        );

        $tool_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=wp-sanaseppa')),
            esc_html__('Avaa työkalu', 'humantone')
        );

        array_unshift($links, $tool_link, $settings_link);

        return $links;
    }

}

add_action('plugins_loaded', function () {
    new HumanTone_Plugin();
});
