# WP Sanaseppä - käyttöohje

WP Sanaseppä on suomenkielinen WordPress-lisäosa tekstien korjaamiseen, brändiääneen ja sisällön siistimiseen.

## Käyttöönotto

1. Avaa **Asetukset > WP Sanaseppä**.
2. Lisää OpenAI API -avain.
3. Valitse käytettävä malli.
4. Luo vähintään yksi brändiprofiili.
5. Suorita perustesti ja tarvittaessa OpenAI-yhteystesti.
6. Testaa ensin lyhyellä tekstillä.

## Työkalut

### Yksittäinen teksti

Käytä tätä lyhyisiin tekstipätkiin, otsikoihin, metakuvauksiin ja kappaleisiin. Työkalu ei tallenna mitään WordPress-julkaisuun, vaan antaa kopioitavan ehdotuksen.

### Artikkeli tai sivu

Käytä tätä kokonaisen artikkelin tai sivun muokkaukseen. Tarkista aina ennen tallennusta:

- ennen-jälkeen-muutosnäkymä
- suojattujen elementtien tarkistuslista
- linkit, kuvat, lyhytkoodit ja lohkot
- artikkelikuva, ote, kategoriat ja avainsanat

Turvallisin tallennustapa on **Tallenna uutena luonnoksena**.

### Joukkokäsittely

Joukkokäsittely luo aina uudet luonnokset eikä korvaa alkuperäisiä. Kokeile ensin pienellä erällä ennen suurta käsittelyä.

### WooCommerce-tuotteet

Tuotetyökalu muokkaa pitkää tai lyhyttä tuotekuvausta. Tarkista aina ennen tallennusta SKU:t, hinnat, mitat, mallikoodit ja muut tuotefaktat.

### Historia ja palautus

Jos alkuperäinen sisältö korvataan, WP Sanaseppä tallentaa palautuspisteen historiaan.

## Brändiprofiilit

Hyvä brändiprofiili sisältää:

- kohdeyleisön
- halutun sävyn
- vältettävät sanat ja fraasit
- lyhyen tyyliesimerkin

Älä liitä tyyliesimerkkiin arkaluontoista dataa.

## Turvallinen tallennus

Pidä turvallisen tallennuksen suojaukset päällä, jos käsittelet kokonaisia artikkeleita, sivuja, tuotteita, SEO-metatietoja, ACF-kenttiä tai sivunrakentajilla tehtyjä sivuja.



## OpenAI API -avaimen luominen

WP Sanaseppä tarvitsee OpenAI API -avaimen, jotta se voi lähettää tekstin muokattavaksi OpenAI:n mallille. Avaa WordPressissä Asetukset → WP Sanaseppä → API-avaimen ohje. Välilehdellä on aloittelijalle tarkoitettu vaiheittainen ohje, linkit OpenAI Platformiin, API keys -sivulle ja laskutusasetuksiin sekä ohje yhteystestin suorittamiseen.

Tärkeää: ChatGPT-tilaus ja OpenAI API -laskutus ovat eri asioita. API-käyttö vaatii yleensä maksutavan tai prepaid-saldoa OpenAI Platformin puolella.


## Suorat linkit WordPress-adminissa

- Työkalut: `admin.php?page=wp-sanaseppa`
- Yksittäinen teksti: `admin.php?page=wp-sanaseppa&tool_tab=single`
- Artikkeli tai sivu: `admin.php?page=wp-sanaseppa&tool_tab=post`
- Joukkokäsittely: `admin.php?page=wp-sanaseppa&tool_tab=bulk`
- WooCommerce-tuotteet: `admin.php?page=wp-sanaseppa&tool_tab=product`
- Historia ja palautus: `admin.php?page=wp-sanaseppa&tool_tab=history`
- Käyttöopas: `admin.php?page=wp-sanaseppa&tool_tab=guide`
- API ja malli: `admin.php?page=wp-sanaseppa-settings&tab=api`
- API-avaimen ohje: `admin.php?page=wp-sanaseppa-settings&tab=api-guide`
- Brändiprofiilit: `admin.php?page=wp-sanaseppa-settings&tab=profiles`
- Lisenssi: `admin.php?page=wp-sanaseppa-settings&tab=license`
- Turvallinen tallennus: `admin.php?page=wp-sanaseppa-settings&tab=safety`
- Käyttöönotto ja testit: `admin.php?page=wp-sanaseppa-settings&tab=diagnostics`
