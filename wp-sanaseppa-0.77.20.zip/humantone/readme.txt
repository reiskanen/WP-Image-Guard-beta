=== WP Sanaseppä – suomenkielinen tekstityökalu ===
Contributors: wp-sanaseppa
Tags: ai, writing, finnish, seo, woocommerce
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 0.77.20
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Suomenkielinen WordPress-lisäosa tekstien korjaamiseen, brändiääneen ja sisällön siistimiseen.

== Description ==

WP Sanaseppä on suomenkieliseen käyttöön tehty WordPress-lisäosa tekstien viimeistelyyn suoraan WordPressin hallinnasta. Se auttaa muokkaamaan kankeita, geneerisiä tai tekoälymäisiä tekstejä selkeämmäksi ja luontevammaksi suomeksi.

Lisäosa soveltuu esimerkiksi blogitekstien, sivusisältöjen, WooCommerce-tuotekuvausten ja brändinmukaisten tekstien viimeistelyyn.

== Free-version ominaisuudet ==

* Yksittäisen tekstin muokkaus.
* Suomenkielisten otsikoiden kirjainkoon korjaus.
* AI-fraasien tunnistus.
* Yksi brändiprofiili.
* Kokonaisen artikkelin tai sivun esikatselu ilman tallennusta.
* OpenAI API -avaimen ohje ja yhteystestit.

== Pro-version ominaisuudet ==

* Kokonaisten artikkelien ja sivujen tallennus uutena luonnoksena tai alkuperäiseen sisältöön.
* Ennen–jälkeen-muutosnäkymä.
* Turvallinen tallennus ja rakennevertailu.
* Historia ja palautus.
* Useita brändiprofiileja.
* Joukkokäsittely.
* WooCommerce-tuotekuvausten muokkaus.
* SEO-metatietojen, ACF-kenttien ja keskeisten sisältöelementtien suojaus.
* Elementor-, Divi- ja WPBakery-turvatila.
* Asetusten vienti ja tuonti.

== Installation ==

1. Lataa lisäosan zip-tiedosto WordPressin Lisäosat-näkymässä.
2. Aktivoi lisäosa.
3. Avaa WP Sanaseppä -valikko WordPressin hallinnassa.
4. Lisää OpenAI API -avain tai käytä AI Provider for OpenAI -konnektoria.
5. Luo ensimmäinen brändiprofiili ohjatun käyttöönoton avulla.

== Frequently Asked Questions ==

= Tarvitsenko OpenAI API -avaimen? =

Kyllä. Voit käyttää joko WP Sanasepän omaa API-avainkenttää tai AI Provider for OpenAI -konnektoria, jos se on asennettu ja määritetty.

= Toimiiko lisäosa ilman Pro-lisenssiä? =

Kyllä. Free-versiossa voi muokata yksittäisiä tekstejä ja tehdä kokonaisen artikkelin tai sivun esikatselun. Tallennus, joukkokäsittely, WooCommerce-työkalut ja palautustoiminnot vaativat Pro-lisenssin.

= Voiko lisäosa rikkoa sivun rakennetta? =

Pro-versiossa on turvallisen tallennuksen tarkistuksia, jotka auttavat havaitsemaan esimerkiksi linkkien, kuvien, lyhytkoodien, lohkojen ja metatietojen katoamisen ennen tallennusta.

== Changelog ==

= 0.77.9 =
* Lisätty näkyvä OpenAI-yhteyden tilakortti ja selkokieliset quota-, billing-, avain- ja mallivirheet.
* API-testi tekee kevyen todellisen mallikutsun, jotta laskutus-/quota-ongelmat löytyvät.


= 0.77.5 =
* Lisätty historiaan palautustoiminto alkuperäisen version palauttamiseksi, kun alkuperäinen sisältö on korvattu.
* Palautus säilyttää artikkelikuvan ja palauttaa tallennetun alkuperäisen otsikon/sisällön turvallisesti.


Tarkempi kehityshistoria ei ole mukana julkisessa readme-tiedostossa.
