(function () {
    var lastPreviewPostId = '';
    var lastPreviewProductId = '';
    var lastPreviewPostContent = '';
    var currentProductData = null;
    var lastPreviewPageBuilderBlocksUpdate = false;
    var postProgressTimer = null;
    var postRewriteWatchdog = null;
    var postRewriteInFlight = false;
    var postRewriteResetTimer = null;


    function byId(id) {
        return document.getElementById(id);
    }

    function setMessage(text, type) {
        var box = byId('humantone-message');
        if (!box) return;
        box.textContent = text || '';
        box.className = 'humantone-message';
        if (text) {
            box.classList.add(type === 'error' ? 'notice-error' : 'notice-success');
            box.classList.add('notice');
        }
    }

    function apiFetch(url, options) {
        options = options || {};
        options.credentials = 'same-origin';
        options.headers = options.headers || {};
        options.headers['X-WP-Nonce'] = HumanToneTool.nonce;
        if (options.body && !options.headers['Content-Type']) {
            options.headers['Content-Type'] = 'application/json';
        }

        var timeoutMs = options.timeoutMs || 240000;
        var timeoutId = null;
        if (window.AbortController && !options.signal) {
            var controller = new AbortController();
            options.signal = controller.signal;
            timeoutId = window.setTimeout(function () {
                controller.abort();
            }, timeoutMs);
        }
        delete options.timeoutMs;

        return fetch(url, options).then(function (response) {
            return response.text().then(function (text) {
                var data = null;
                try {
                    data = text ? JSON.parse(text) : {};
                } catch (e) {
                    data = null;
                }
                if (!response.ok) {
                    var message = data && data.message ? data.message : '';
                    if (!message && response.status === 504) {
                        message = 'Pyyntö aikakatkaistiin palvelimella. Pitkä sivu voi vaatia pidemmän palvelimen timeout-asetuksen tai pienemmän käsittelyrajan.';
                    }
                    if (!message && text) {
                        message = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 220);
                    }
                    throw new Error(message || ((HumanToneTool.messages.failed || 'Pyyntö epäonnistui.') + ' HTTP ' + response.status));
                }
                if (!data) {
                    throw new Error('Palvelin palautti odottamattoman vastauksen. Kokeile uudelleen ja tarkista WordPressin virheloki, jos ongelma jatkuu.');
                }
                return data;
            });
        }).catch(function (error) {
            if (error && error.name === 'AbortError') {
                throw new Error('Pyyntö aikakatkaistiin selaimessa. Pitkän sivun käsittely voi kestää, mutta tämä pyyntö ylitti aikarajan. Kokeile lyhyemmällä sisällöllä tai nosta palvelimen aikarajoja.');
            }
            throw error;
        }).finally(function () {
            if (timeoutId) window.clearTimeout(timeoutId);
        });
    }

    function setButtonLoading(button, text, isLoading, normalText) {
        if (!button) return;
        var apiBlocked = HumanToneTool.apiStatus && HumanToneTool.apiStatus.blocking && ['humantone-rewrite', 'humantone-rewrite-post', 'humantone-bulk-run', 'humantone-rewrite-product'].indexOf(button.id) !== -1;
        button.disabled = isLoading || apiBlocked;
        if (apiBlocked) button.title = HumanToneTool.apiStatus.message || 'OpenAI-yhteys ei toimi.';
        button.textContent = isLoading ? text : normalText;
    }

    function clearPostRewriteWatchdog() {
        if (postRewriteWatchdog) {
            window.clearTimeout(postRewriteWatchdog);
            postRewriteWatchdog = null;
        }
    }

    function resetPostRewriteButton() {
        postRewriteInFlight = false;
        if (postRewriteResetTimer) {
            window.clearInterval(postRewriteResetTimer);
            postRewriteResetTimer = null;
        }
        var button = byId('humantone-rewrite-post');
        if (button) {
            var apiBlocked = HumanToneTool.apiStatus && HumanToneTool.apiStatus.blocking;
            button.disabled = !!apiBlocked;
            if (!apiBlocked) button.removeAttribute('disabled');
            button.classList.remove('is-busy');
            button.textContent = 'Muokkaa koko sisältö esikatseluun';
            if (apiBlocked) button.title = HumanToneTool.apiStatus.message || 'OpenAI-yhteys ei toimi.';
        }
    }

    function setPostRewriteBusy(isBusy) {
        postRewriteInFlight = !!isBusy;
        var button = byId('humantone-rewrite-post');
        if (!button) return;
        button.type = 'button';
        var apiBlocked = HumanToneTool.apiStatus && HumanToneTool.apiStatus.blocking;
        button.disabled = !!apiBlocked;
        if (!apiBlocked) button.removeAttribute('disabled');
        button.classList.toggle('is-busy', !!isBusy);
        button.textContent = isBusy ? HumanToneTool.messages.workingPost : 'Muokkaa koko sisältö esikatseluun';
        if (apiBlocked) button.title = HumanToneTool.apiStatus.message || 'OpenAI-yhteys ei toimi.';
    }

    function setLoading(isLoading) {
        setButtonLoading(byId('humantone-rewrite'), HumanToneTool.messages.working, isLoading, 'Muokkaa teksti');
    }

    function setSaveButtonsEnabled(enabled) {
        var draft = byId('humantone-save-draft');
        var update = byId('humantone-update-original');
        if (draft) draft.disabled = !enabled;
        if (update) update.disabled = !enabled;
    }

    function updatePostProgress(percent, text) {
        var card = byId('humantone-post-progress');
        var fill = byId('humantone-post-progress-fill');
        var pct = byId('humantone-post-progress-percent');
        var progressBar = card ? card.querySelector('.humantone-progress-bar') : null;
        var progressText = byId('humantone-post-progress-text');
        var steps = byId('humantone-post-progress-steps');
        percent = Math.max(0, Math.min(100, percent || 0));
        if (fill) fill.style.width = percent + '%';
        if (pct) pct.textContent = percent + '%';
        if (progressBar) progressBar.setAttribute('aria-valuenow', String(percent));
        if (progressText && text) progressText.textContent = text;
        if (steps) {
            var activeIndex = percent < 25 ? 0 : (percent < 55 ? 1 : (percent < 82 ? 2 : 3));
            Array.prototype.slice.call(steps.querySelectorAll('li')).forEach(function (item, index) {
                item.classList.toggle('is-active', index === activeIndex);
                item.classList.toggle('is-done', index < activeIndex);
            });
        }
    }

    function showPostProgress() {
        var card = byId('humantone-post-progress');
        if (!card) return;
        var percent = 8;
        card.hidden = false;
        card.classList.remove('has-error');
        updatePostProgress(percent, 'Valmistellaan sisältöä. Pitkän artikkelin tai sivun käsittely voi kestää useita kymmeniä sekunteja.');
        if (postProgressTimer) window.clearInterval(postProgressTimer);
        postProgressTimer = window.setInterval(function () {
            if (percent < 35) {
                percent += 4;
            } else if (percent < 70) {
                percent += 2;
            } else if (percent < 92) {
                percent += 1;
            }
            var text = 'Muokkaus on edelleen käynnissä. Älä sulje sivua — eteneminen jatkuu taustalla.';
            if (percent < 35) text = 'Sisältöä valmistellaan ja jaetaan käsiteltäviin osiin.';
            else if (percent < 70) text = 'Tekstiä muokataan tekoälyllä. Tämä voi kestää etenkin pitkissä artikkeleissa.';
            else if (percent < 92) text = 'Tarkistetaan rakennetta, linkkejä, kuvia ja muita suojattuja elementtejä.';
            updatePostProgress(percent, text);
        }, 1800);
    }

    function resetPostProgress() {
        if (postProgressTimer) {
            window.clearInterval(postProgressTimer);
            postProgressTimer = null;
        }
        var card = byId('humantone-post-progress');
        if (!card) return;
        card.hidden = true;
        card.classList.remove('has-error');
        updatePostProgress(0, '');
        var steps = byId('humantone-post-progress-steps');
        if (steps) {
            Array.prototype.slice.call(steps.querySelectorAll('li')).forEach(function (item) {
                item.classList.remove('is-active');
                item.classList.remove('is-done');
            });
        }
    }

    function finishPostProgress(success, message) {
        if (postProgressTimer) {
            window.clearInterval(postProgressTimer);
            postProgressTimer = null;
        }
        var card = byId('humantone-post-progress');
        if (!card) return;
        if (success) {
            card.classList.remove('has-error');
            updatePostProgress(100, message || 'Esikatselu on valmis. Tarkista tulos ja rakennevertailu ennen tallennusta.');
            var fill = byId('humantone-post-progress-fill');
            var pct = byId('humantone-post-progress-percent');
            var progressBar = card.querySelector('.humantone-progress-bar');
            if (fill) fill.style.width = '100%';
            if (pct) pct.textContent = '100%';
            if (progressBar) progressBar.setAttribute('aria-valuenow', '100');
            window.setTimeout(function () { resetPostProgress(); }, 1600);
        } else {
            updatePostProgress(100, message || 'Käsittely keskeytyi tai palvelin palautti virheen. Painike on palautettu käyttöön. Virheilmoitus näkyy sivun yläosassa.');
            card.hidden = false;
            card.classList.add('has-error');
        }
    }

    function applyPageBuilderGuard(data) {
        var update = byId('humantone-update-original');
        var builder = data && data.pageBuilder ? data.pageBuilder : null;
        lastPreviewPageBuilderBlocksUpdate = !!(builder && builder.blockUpdateOriginal);
        if (update && lastPreviewPageBuilderBlocksUpdate) {
            update.disabled = true;
            update.title = 'Alkuperäisen korvaaminen on estetty, koska sisältö käyttää sivunrakentajaa. Tallenna uutena luonnoksena.';
        } else if (update) {
            update.title = '';
        }
    }

    function populateProfileSelect(selectId) {
        var select = byId(selectId);
        if (!select) return;

        select.innerHTML = '';
        var profiles = HumanToneTool.profiles || [];
        if (!profiles.length) {
            var fallback = document.createElement('option');
            fallback.value = '';
            fallback.textContent = 'Oletusprofiili';
            select.appendChild(fallback);
            return;
        }

        profiles.forEach(function (profile) {
            var option = document.createElement('option');
            option.value = profile.id;
            option.textContent = profile.name;
            if (profile.id === HumanToneTool.defaultProfile) {
                option.selected = true;
            }
            select.appendChild(option);
        });
    }

    function resetComparePanel() {
        var panel = byId('humantone-compare-panel');
        var stats = byId('humantone-stats-table');
        var warnings = byId('humantone-warnings');
        var aiPhrases = byId('humantone-ai-phrases');
        var safety = byId('humantone-safety-checklist');
        var diff = byId('humantone-post-diff');
        if (panel) panel.hidden = true;
        if (stats) stats.innerHTML = '';
        if (warnings) warnings.innerHTML = '';
        if (aiPhrases) aiPhrases.innerHTML = '';
        if (safety) safety.innerHTML = '';
        if (diff) { diff.innerHTML = ''; diff.hidden = true; }
        resetPostProgress();
        setSaveButtonsEnabled(false);
        lastPreviewPostId = '';
        lastPreviewPageBuilderBlocksUpdate = false;
    }

    function renderAiPhraseAnalysis(containerId, analysis, title) {
        var box = byId(containerId);
        if (!box) return;
        box.innerHTML = '';
        if (!analysis || !analysis.total) {
            box.textContent = 'Mahdollisia AI-fraaseja ei löytynyt.';
            box.classList.remove('has-warnings');
            return;
        }

        var heading = document.createElement('strong');
        heading.textContent = title + ': ' + analysis.total;
        box.appendChild(heading);

        if (analysis.items && analysis.items.length) {
            var list = document.createElement('ul');
            analysis.items.slice(0, 8).forEach(function (item) {
                var li = document.createElement('li');
                li.textContent = item.phrase + ' (' + item.count + ')';
                list.appendChild(li);
            });
            box.appendChild(list);
        }
        box.classList.add('has-warnings');
    }


    function renderSafetyChecklist(data) {
        var box = byId('humantone-safety-checklist');
        if (!box) return;
        box.innerHTML = '';

        var items = data && data.safetyChecklist ? data.safetyChecklist : [];
        if (!items.length) {
            return;
        }

        var title = document.createElement('h4');
        title.textContent = 'Suojattujen elementtien tarkistuslista';
        box.appendChild(title);

        var summary = data.summary || null;
        if (!summary) {
            var ok = 0, failed = 0, skipped = 0;
            (data.results || []).forEach(function (item) {
                if (item.success) { ok++; }
                else if (item.skipped) { skipped++; }
                else { failed++; }
            });
            summary = { ok: ok, skipped: skipped, failed: failed, total: (data.results || []).length };
        }
        var summaryTable = document.createElement('table');
        summaryTable.className = 'widefat humantone-bulk-summary-table';
        summaryTable.innerHTML = '<thead><tr><th>Tila</th><th>Määrä</th></tr></thead><tbody>' +
            '<tr><td>Onnistui</td><td>' + (summary.ok || 0) + '</td></tr>' +
            '<tr><td>Ohitettu</td><td>' + (summary.skipped || 0) + '</td></tr>' +
            '<tr><td>Virheitä</td><td>' + (summary.failed || 0) + '</td></tr>' +
            '<tr><td>Yhteensä</td><td>' + (summary.total || 0) + '</td></tr>' +
            '</tbody>';
        box.appendChild(summaryTable);

        var problemItems = (data.results || []).filter(function (item) { return !item.success || item.skipped || (item.warningCount && parseInt(item.warningCount, 10) > 0); });
        if (problemItems.length) {
            var details = document.createElement('details');
            details.className = 'humantone-bulk-problem-details';
            details.open = true;
            var summaryEl = document.createElement('summary');
            summaryEl.textContent = 'Virheet, ohitukset ja varoitukset (' + problemItems.length + ')';
            details.appendChild(summaryEl);
            var list = document.createElement('ul');
            problemItems.forEach(function (item) {
                var li = document.createElement('li');
                var prefix = item.success ? '⚠️ ' : (item.skipped ? '⚠️ ' : '❌ ');
                li.textContent = prefix + '"' + (item.title || item.sourceId) + '" – ' + (item.message || (item.warningCount ? ('Varoituksia: ' + item.warningCount) : 'Tarkista rivi.'));
                list.appendChild(li);
            });
            details.appendChild(list);
            box.appendChild(details);
        }

        var table = document.createElement('table');
        table.className = 'widefat striped humantone-safety-table';
        table.innerHTML = '<thead><tr><th>Kohde</th><th>Alkuperäinen</th><th>Muokattu / tallennettava</th><th>Tila</th></tr></thead><tbody></tbody>';
        var tbody = table.querySelector('tbody');

        items.forEach(function (item) {
            var tr = document.createElement('tr');
            tr.className = item.status === 'blocked' ? 'humantone-safety-blocked' : (item.status === 'warning' ? 'humantone-stat-changed' : '');

            var label = document.createElement('td');
            label.textContent = item.label || item.key || '';
            var original = document.createElement('td');
            original.textContent = item.original;
            var rewritten = document.createElement('td');
            rewritten.textContent = item.rewritten;
            var status = document.createElement('td');
            status.textContent = (item.status === 'blocked' ? 'Estetty: ' : (item.status === 'warning' ? 'Tarkista: ' : 'OK: ')) + (item.message || 'Säilyy');

            tr.appendChild(label);
            tr.appendChild(original);
            tr.appendChild(rewritten);
            tr.appendChild(status);
            tbody.appendChild(tr);
        });

        box.appendChild(table);

        if (data.safeToSave === false && data.canSave !== false && !data.previewLocked) {
            var notice = document.createElement('div');
            notice.className = 'notice notice-error inline humantone-safe-save-notice';
            notice.innerHTML = '<p><strong>Turvallinen tallennus estää tallennuksen.</strong> Muokatusta sisällöstä näyttää kadonneen suojattuja elementtejä. Korjaa sisältö käsin tai muuta asetusta kohdassa Asetukset → WP Sanaseppä → Turvallinen tallennus.</p>';
            box.appendChild(notice);
        }

        if (data.pageBuilder && data.pageBuilder.blockUpdateOriginal) {
            var builderNotice = document.createElement('div');
            builderNotice.className = 'notice notice-warning inline humantone-safe-save-notice';
            builderNotice.innerHTML = '<p><strong>Sivunrakentaja havaittu:</strong> ' + (data.pageBuilder.builders || []).join(', ') + '. Alkuperäisen korvaaminen on estetty turvallisuussyistä. Voit tallentaa muokatun version uutena luonnoksena.</p>';
            box.appendChild(builderNotice);
        }
    }

    function renderStats(data) {
        var panel = byId('humantone-compare-panel');
        var statsBox = byId('humantone-stats-table');
        var warningBox = byId('humantone-warnings');
        if (!panel || !statsBox || !warningBox || !data) return;

        var original = data.originalStats || {};
        var rewritten = data.rewrittenStats || {};
        var rows = [
            ['Sanat', 'words'],
            ['Merkit', 'characters'],
            ['Otsikot', 'headings'],
            ['Linkit', 'links'],
            ['Kuvat', 'images'],
            ['Lyhytkoodit', 'shortcodes'],
            ['WordPress-lohkot', 'blocks'],
            ['Title Case -otsikot', 'titleCaseHeadings'],
            ['Mahdolliset AI-fraasit', 'aiPhrases']
        ];

        var html = '<table class="widefat striped humantone-stats"><thead><tr><th>Kohde</th><th>Alkuperäinen</th><th>Muokattu</th></tr></thead><tbody>';
        rows.forEach(function (row) {
            var label = row[0];
            var key = row[1];
            var changed = Number(original[key] || 0) !== Number(rewritten[key] || 0);
            html += '<tr class="' + (changed ? 'humantone-stat-changed' : '') + '"><td>' + label + '</td><td>' + (original[key] || 0) + '</td><td>' + (rewritten[key] || 0) + '</td></tr>';
        });
        html += '</tbody></table>';
        statsBox.innerHTML = html;

        warningBox.innerHTML = '';
        var aiBox = byId('humantone-ai-phrases');
        if (aiBox) {
            var before = data.originalAiPhraseAnalysis ? data.originalAiPhraseAnalysis.total : (original.aiPhrases || 0);
            var after = data.rewrittenAiPhraseAnalysis ? data.rewrittenAiPhraseAnalysis.total : (rewritten.aiPhrases || 0);
            aiBox.innerHTML = '<strong>AI-fraasit:</strong> ' + before + ' → ' + after;
            if (data.rewrittenAiPhraseAnalysis && data.rewrittenAiPhraseAnalysis.items && data.rewrittenAiPhraseAnalysis.items.length) {
                var phraseList = document.createElement('ul');
                data.rewrittenAiPhraseAnalysis.items.slice(0, 8).forEach(function (item) {
                    var li = document.createElement('li');
                    li.textContent = item.phrase + ' (' + item.count + ')';
                    phraseList.appendChild(li);
                });
                aiBox.appendChild(phraseList);
            }
            aiBox.classList.toggle('has-warnings', after > 0);
        }

        renderSafetyChecklist(data);

        if (data.warnings && data.warnings.length) {
            var list = document.createElement('ul');
            data.warnings.forEach(function (warning) {
                var item = document.createElement('li');
                item.textContent = (warning.blocking ? '[Tallennus estetty] ' : '') + warning.message + ' (' + warning.original + ' → ' + warning.rewritten + ')';
                list.appendChild(item);
            });
            var title = document.createElement('strong');
            title.textContent = 'Tarkista ennen tallennusta:';
            warningBox.appendChild(title);
            warningBox.appendChild(list);
            warningBox.classList.add('has-warnings');
            warningBox.classList.toggle('has-blocking-warnings', data.safeToSave === false);
        } else {
            warningBox.textContent = 'Rakenne näyttää säilyneen: otsikoiden, linkkien, kuvien, lyhytkoodien ja lohkojen määrät vastaavat alkuperäistä.';
            warningBox.classList.remove('has-warnings');
            warningBox.classList.remove('has-blocking-warnings');
        }

        panel.hidden = false;
    }

    function rewriteText() {
        var input = byId('humantone-input');
        var output = byId('humantone-output');
        var mode = byId('humantone-mode');
        var contentPurpose = byId('humantone-content-purpose');
        var cleanAiPhrases = byId('humantone-clean-ai-phrases');
        var profile = byId('humantone-profile');
        var copy = byId('humantone-copy');
        var singleAiPhrases = byId('humantone-single-ai-phrases');

        if (!input || !output || !mode) return;

        var text = input.value.trim();
        if (!text) {
            setMessage(HumanToneTool.messages.emptyText, 'error');
            return;
        }

        setMessage('', '');
        output.value = '';
        if (singleAiPhrases) singleAiPhrases.innerHTML = '';
        if (copy) copy.disabled = true;
        setLoading(true);

        apiFetch(HumanToneTool.restUrl, {
            method: 'POST',
            body: JSON.stringify({
                text: text,
                mode: mode.value,
                content_type: contentPurpose ? contentPurpose.value : 'general',
                clean_ai_phrases: cleanAiPhrases ? cleanAiPhrases.checked : false,
                profile_id: profile ? profile.value : ''
            })
        })
            .then(function (data) {
                finishPostProgress(true);
                output.value = data.text || '';
                renderAiPhraseAnalysis('humantone-single-ai-phrases', data.aiPhraseAnalysis, 'Mahdollisia AI-fraaseja ehdotuksessa');
                if (copy) copy.disabled = !output.value;
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setLoading(false);
            });
    }

    function copyOutput() {
        var output = byId('humantone-output');
        if (!output || !output.value) return;

        output.select();
        output.setSelectionRange(0, output.value.length);

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(output.value).then(function () {
                setMessage(HumanToneTool.messages.copied, 'success');
            });
            return;
        }

        document.execCommand('copy');
        setMessage(HumanToneTool.messages.copied, 'success');
    }

    function clearFields() {
        var input = byId('humantone-input');
        var output = byId('humantone-output');
        var copy = byId('humantone-copy');
        if (input) input.value = '';
        if (output) output.value = '';
        if (copy) copy.disabled = true;
        setMessage('', '');
    }

    function loadPosts() {
        var type = byId('humantone-post-type');
        var search = byId('humantone-post-search');
        var select = byId('humantone-post-select');
        var button = byId('humantone-load-posts');

        if (!type || !select) return;

        select.innerHTML = '';
        var loadingOption = document.createElement('option');
        loadingOption.value = '';
        loadingOption.textContent = HumanToneTool.messages.loadingPosts;
        select.appendChild(loadingOption);
        setButtonLoading(button, HumanToneTool.messages.loadingPosts, true, 'Hae');
        setMessage('', '');
        resetComparePanel();

        var url = new URL(HumanToneTool.postsUrl);
        url.searchParams.set('type', type.value);
        if (search && search.value.trim()) {
            url.searchParams.set('search', search.value.trim());
        }

        apiFetch(url.toString(), { method: 'GET' })
            .then(function (data) {
                select.innerHTML = '';
                if (!data.posts || !data.posts.length) {
                    var empty = document.createElement('option');
                    empty.value = '';
                    empty.textContent = HumanToneTool.messages.noPosts;
                    select.appendChild(empty);
                    return;
                }

                data.posts.forEach(function (post) {
                    var option = document.createElement('option');
                    option.value = post.id;
                    option.textContent = post.title + ' [' + post.status + ', muokattu ' + post.modified + ']';
                    select.appendChild(option);
                });
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.loadingPosts, false, 'Hae');
            });
    }


    function readableContent(value) {
        value = String(value || '');
        if (!value) return '';
        var looksLikeHtml = /<[^>]+>/.test(value) || /<!--\s*wp:/.test(value);
        if (!looksLikeHtml) return value;
        var cleaned = value.replace(/<!--\s*\/??wp:[\s\S]*?-->/g, '\n');
        var element = document.createElement('div');
        element.innerHTML = cleaned;
        Array.prototype.slice.call(element.querySelectorAll('script,style,noscript,svg')).forEach(function (node) {
            node.parentNode.removeChild(node);
        });
        return (element.textContent || element.innerText || '')
            .replace(/\u00a0/g, ' ')
            .replace(/[ \t]+/g, ' ')
            .replace(/\n\s*\n\s*\n+/g, '\n\n')
            .trim();
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function textToPreviewHtml(value) {
        value = String(value || '').trim();
        if (!value) return '';
        return value.split(/\n{2,}/).map(function (paragraph) {
            paragraph = paragraph.trim();
            return paragraph ? '<p>' + escapeHtml(paragraph).replace(/\n/g, '<br>') + '</p>' : '';
        }).join('');
    }

    function setFormattedPreview(id, html, fallbackText) {
        var element = byId(id);
        if (!element) return;
        var content = String(html || '').trim();
        if (!content && fallbackText) {
            content = textToPreviewHtml(fallbackText);
        }
        element.innerHTML = content || '<p class="humantone-preview-empty">Sisältöä ei ole vielä näytettävänä.</p>';
    }

    function clearPostPreviews() {
        setFormattedPreview('humantone-post-original-preview', '', '');
        setFormattedPreview('humantone-post-output-preview', '', '');
    }

    function selectedPostId() {
        var select = byId('humantone-post-select');
        return select ? select.value : '';
    }

    function loadPostContent() {
        var postId = selectedPostId();
        var original = byId('humantone-post-original');
        var output = byId('humantone-post-output');
        var editLink = byId('humantone-edit-link');
        var button = byId('humantone-load-post-content');

        if (!postId) {
            setMessage(HumanToneTool.messages.selectPost, 'error');
            return;
        }

        if (original) original.value = '';
        if (output) output.value = '';
        clearPostPreviews();
        if (editLink) editLink.style.display = 'none';
        resetComparePanel();
        setButtonLoading(button, HumanToneTool.messages.loadingPost, true, 'Näytä sisältö');
        setMessage('', '');

        apiFetch(HumanToneTool.postUrlBase + postId, { method: 'GET' })
            .then(function (data) {
                if (original) original.value = data.readableContent || readableContent(data.content || '');
                setFormattedPreview('humantone-post-original-preview', data.previewHtml || data.content || '', original ? original.value : '');
                setFormattedPreview('humantone-post-output-preview', '', '');
                if (editLink && data.editLink) {
                    editLink.href = data.editLink;
                    editLink.style.display = 'inline-block';
                }
                var phraseTotal = data.aiPhraseAnalysis && data.aiPhraseAnalysis.total ? data.aiPhraseAnalysis.total : 0;
                setMessage('Sisältö haettu: ' + (data.length || 0) + ' merkkiä. Mahdollisia AI-fraaseja: ' + phraseTotal + '.', 'success');
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.loadingPost, false, 'Näytä sisältö');
            });
    }

    function rewritePost() {
        var postId = selectedPostId();
        var mode = byId('humantone-post-mode');
        var contentPurpose = byId('humantone-post-content-purpose');
        var cleanAiPhrases = byId('humantone-post-clean-ai-phrases');
        var profile = byId('humantone-post-profile');
        var output = byId('humantone-post-output');
        var button = byId('humantone-rewrite-post');

        if (!postId) {
            setMessage(HumanToneTool.messages.selectPost, 'error');
            return;
        }
        if (postRewriteInFlight) {
            setMessage('Käsittely on jo käynnissä. Odota vastausta tai lataa sivu uudelleen, jos selain näyttää jääneen jumiin.', 'error');
            return;
        }

        try {

        resetPostProgress();
        if (output) {
            output.value = '';
            output.readOnly = false;
        }
        clearPostPreviews();
        lastPreviewPostContent = '';
        resetComparePanel();
        setMessage(HumanToneTool.messages.workingPost, 'success');
        setPostRewriteBusy(true);
        showPostProgress();
        clearPostRewriteWatchdog();
        postRewriteWatchdog = window.setTimeout(function () {
            finishPostProgress(false);
            resetPostRewriteButton();
            setMessage('Käsittely kesti poikkeuksellisen pitkään tai selain ei saanut vastausta. Painike palautettiin käyttöön. Voit yrittää uudelleen tai käsitellä lyhyemmän sisällön.', 'error');
        }, 300000);
        if (postRewriteResetTimer) window.clearInterval(postRewriteResetTimer);
        postRewriteResetTimer = window.setInterval(function () {
            var currentButton = byId('humantone-rewrite-post');
            if (currentButton && postRewriteInFlight) {
                currentButton.disabled = false;
                currentButton.removeAttribute('disabled');
                currentButton.classList.add('is-busy');
            }
        }, 1500);

        apiFetch(HumanToneTool.postUrlBase + postId + '/rewrite', {
            method: 'POST',
            body: JSON.stringify({
                mode: mode ? mode.value : 'natural',
                content_type: contentPurpose ? contentPurpose.value : 'general',
                clean_ai_phrases: cleanAiPhrases ? cleanAiPhrases.checked : false,
                profile_id: profile ? profile.value : '',
                save_mode: 'preview'
            })
        })
            .then(function (data) {
                try {
                finishPostProgress(true);
                if (data.previewLocked) {
                    if (output) {
                        output.value = (data.rewrittenReadableContent || data.previewContent || '') + (data.previewNotice ? '\n\n' + data.previewNotice : '');
                        output.readOnly = true;
                    }
                    var lockedOriginalBox = byId('humantone-post-original');
                    if (lockedOriginalBox) {
                        lockedOriginalBox.value = data.originalReadableContent || readableContent(data.originalContent || '');
                    }
                    setFormattedPreview('humantone-post-original-preview', data.originalPreviewHtml || data.originalContent || '', lockedOriginalBox ? lockedOriginalBox.value : '');
                    setFormattedPreview('humantone-post-output-preview', data.rewrittenPreviewHtml || '', output ? output.value : '');
                    lastPreviewPostId = '';
                    lastPreviewPostContent = '';
                    setSaveButtonsEnabled(false);
                    applyPageBuilderGuard(data);
                    renderStats(data);
                    renderLockedPostPreview('humantone-post-diff', data);
                    setMessage(data.message || 'Demoesikatselu valmis. Koko sisällön käyttö ja tallennus vaativat Pro-lisenssin.', 'success');
                    return;
                }

                lastPreviewPostContent = data.content || '';
                if (output) {
                    output.value = data.rewrittenReadableContent || readableContent(data.content || '');
                    output.readOnly = true;
                }
                var originalBox = byId('humantone-post-original');
                if (originalBox) {
                    originalBox.value = data.originalReadableContent || readableContent(data.originalContent || '');
                }
                setFormattedPreview('humantone-post-original-preview', data.originalPreviewHtml || data.originalContent || '', originalBox ? originalBox.value : '');
                setFormattedPreview('humantone-post-output-preview', data.rewrittenPreviewHtml || data.content || '', output ? output.value : '');
                lastPreviewPostId = postId;
                setSaveButtonsEnabled(!!(data.content) && data.safeToSave !== false && data.canSave !== false);
                applyPageBuilderGuard(data);
                renderStats(data);
                renderDiffPanel('humantone-post-diff', data.originalReadableContent || readableContent(data.originalContent || (byId('humantone-post-original') || {}).value || ''), data.rewrittenReadableContent || readableContent(data.content || ''), 'Ennen–jälkeen-muutosnäkymä');
                setMessage(data.safeToSave === false ? 'Esikatselu valmis, mutta turvallinen tallennus estää tallennuksen, koska suojattuja elementtejä näyttää kadonneen.' : (data.message || 'Esikatselu valmis. Tarkista vertailu ja muutosnäkymä ennen tallennusta.'), data.safeToSave === false ? 'error' : 'success');
                } catch (handlerError) {
                    finishPostProgress(false);
                    setMessage('Esikatselun näyttäminen epäonnistui, vaikka palvelin saattoi palauttaa vastauksen. Virhe: ' + (handlerError && handlerError.message ? handlerError.message : handlerError), 'error');
                    throw handlerError;
                }
            })
            .catch(function (error) {
                finishPostProgress(false);
                resetPostRewriteButton();
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                clearPostRewriteWatchdog();
                resetPostRewriteButton();
            });
        } catch (syncError) {
            finishPostProgress(false);
            clearPostRewriteWatchdog();
            resetPostRewriteButton();
            setMessage('Käsittely ei käynnistynyt selaimessa. Virhe: ' + (syncError && syncError.message ? syncError.message : syncError), 'error');
        }
    }

    function savePostVersion(saveMode) {
        var postId = lastPreviewPostId || selectedPostId();
        var output = byId('humantone-post-output');
        var editLink = byId('humantone-edit-link');
        var button = saveMode === 'update_original' ? byId('humantone-update-original') : byId('humantone-save-draft');
        var normalText = saveMode === 'update_original' ? 'Korvaa alkuperäinen' : 'Tallenna uutena luonnoksena';

        if (!postId) {
            setMessage(HumanToneTool.messages.selectPost, 'error');
            return;
        }
        if (!lastPreviewPostContent || !lastPreviewPostContent.trim()) {
            setMessage('Muokattu sisältö puuttuu. Luo ensin esikatselu.', 'error');
            return;
        }
        if (saveMode === 'update_original' && lastPreviewPageBuilderBlocksUpdate) {
            setMessage('Alkuperäisen korvaaminen on estetty, koska sisältö käyttää sivunrakentajaa. Tallenna muokattu versio uutena luonnoksena.', 'error');
            return;
        }
        if (saveMode === 'update_original' && !window.confirm(HumanToneTool.messages.confirmUpdate)) {
            return;
        }

        setButtonLoading(button, HumanToneTool.messages.savingPost, true, normalText);
        setMessage(HumanToneTool.messages.savingPost, 'success');

        apiFetch(HumanToneTool.postUrlBase + postId + HumanToneTool.postSaveUrlSuffix, {
            method: 'POST',
            body: JSON.stringify({
                content: lastPreviewPostContent,
                save_mode: saveMode
            })
        })
            .then(function (data) {
                if (editLink && data.editLink) {
                    editLink.href = data.editLink;
                    editLink.style.display = 'inline-block';
                }
                applyPageBuilderGuard(data);
                renderStats(data);
                setMessage(data.message || 'Tallennettu.', 'success');
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.savingPost, false, normalText);
            });
    }


    function renderBulkList(posts) {
        var list = byId('humantone-bulk-list');
        if (!list) return;
        list.innerHTML = '';

        if (!posts || !posts.length) {
            list.textContent = HumanToneTool.messages.noPosts;
            return;
        }

        var table = document.createElement('table');
        table.className = 'widefat striped humantone-bulk-table';
        table.innerHTML = '<thead><tr><th></th><th>Otsikko</th><th>Tila</th><th>Tyyppi</th><th>Muokattu</th><th>Sivunrakentaja</th></tr></thead><tbody></tbody>';
        var tbody = table.querySelector('tbody');

        posts.forEach(function (post) {
            var tr = document.createElement('tr');
            var checkboxTd = document.createElement('td');
            var checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'humantone-bulk-checkbox';
            checkbox.value = post.id;
            checkboxTd.appendChild(checkbox);

            var title = document.createElement('td');
            title.textContent = post.title;
            var status = document.createElement('td');
            status.textContent = post.status;
            var type = document.createElement('td');
            type.textContent = post.type;
            var modified = document.createElement('td');
            modified.textContent = post.modified;
            var builder = document.createElement('td');
            builder.textContent = post.pageBuilder && post.pageBuilder.detected ? (post.pageBuilder.builders || []).join(', ') : 'Ei havaittu';

            tr.appendChild(checkboxTd);
            tr.appendChild(title);
            tr.appendChild(status);
            tr.appendChild(type);
            tr.appendChild(modified);
            tr.appendChild(builder);
            tbody.appendChild(tr);
        });

        list.appendChild(table);
    }

    function loadBulkPosts() {
        var type = byId('humantone-bulk-post-type');
        var search = byId('humantone-bulk-search');
        var button = byId('humantone-bulk-load');
        var results = byId('humantone-bulk-results');
        if (results) results.innerHTML = '';

        setButtonLoading(button, HumanToneTool.messages.loadingPosts, true, 'Hae');
        setMessage('', '');

        var url = new URL(HumanToneTool.postsUrl);
        url.searchParams.set('type', type ? type.value : 'post');
        if (search && search.value.trim()) {
            url.searchParams.set('search', search.value.trim());
        }

        apiFetch(url.toString(), { method: 'GET' })
            .then(function (data) {
                renderBulkList(data.posts || []);
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.loadingPosts, false, 'Hae');
            });
    }

    function selectedBulkIds() {
        return Array.prototype.slice.call(document.querySelectorAll('.humantone-bulk-checkbox:checked')).map(function (checkbox) {
            return checkbox.value;
        });
    }

    function selectVisibleBulkPosts(checked) {
        Array.prototype.slice.call(document.querySelectorAll('.humantone-bulk-checkbox')).forEach(function (checkbox) {
            checkbox.checked = checked;
        });
    }

    function escapeHtml(text) {
        return String(text || '').replace(/[&<>"']/g, function (ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[ch];
        });
    }

    function formatWarnings(item) {
        var warnings = Array.isArray(item.warnings) ? item.warnings : [];
        if (!warnings.length) return '';
        return warnings.map(function (warning) {
            if (typeof warning === 'string') return warning;
            if (warning && warning.message) return warning.message;
            return String(warning || '');
        }).filter(Boolean).join('\n');
    }

    function setupSyncedScroll(container) {
        var toggle = container.querySelector('.humantone-sync-scroll-toggle');
        if (!toggle) return;
        var panes = Array.prototype.slice.call(container.querySelectorAll('.humantone-sync-scroll-pane'));
        var syncing = false;

        function syncFrom(source) {
            if (!toggle.checked || syncing) return;
            var maxSource = Math.max(1, source.scrollHeight - source.clientHeight);
            var ratio = source.scrollTop / maxSource;
            syncing = true;
            panes.forEach(function (pane) {
                if (pane === source) return;
                var maxPane = Math.max(0, pane.scrollHeight - pane.clientHeight);
                pane.scrollTop = ratio * maxPane;
            });
            window.setTimeout(function () { syncing = false; }, 0);
        }

        panes.forEach(function (pane) {
            pane.addEventListener('scroll', function () { syncFrom(pane); }, { passive: true });
        });
    }

    function getAcceptableDryRunItems(items) {
        return (items || []).filter(function (item) {
            return item && item.success && item.saveMode === 'dry_run' && item.changed && item.sourceId && item.rewrittenContent;
        });
    }

    function acceptDryRunItems(items, onProgress) {
        var list = getAcceptableDryRunItems(items);
        var done = 0;
        var failed = 0;
        var errors = [];
        if (!list.length) {
            setMessage('Hyväksyttäviä dry run -ehdotuksia ei löytynyt.', 'warning');
            return Promise.resolve({ ok: 0, failed: 0, errors: [] });
        }
        return list.reduce(function (promise, item) {
            return promise.then(function () {
                if (typeof onProgress === 'function') onProgress(done, list.length, item);
                return apiFetch(HumanToneTool.postUrlBase + encodeURIComponent(item.sourceId) + '/save', {
                    method: 'POST',
                    body: JSON.stringify({ content: item.rewrittenContent, save_mode: 'update_original' }),
                    timeoutMs: 240000
                }).then(function (data) {
                    done++;
                    item.saveMode = 'update_original';
                    item.resultLabel = data.message || 'Alkuperäinen päivitettiin';
                    item.editLink = data.editLink || item.editLink;
                    if (typeof onProgress === 'function') onProgress(done, list.length, item);
                }).catch(function (error) {
                    failed++;
                    errors.push('"' + (item.title || item.sourceId) + '" – ' + (error.message || 'Tallennus epäonnistui.'));
                    if (typeof onProgress === 'function') onProgress(done, list.length, item);
                });
            });
        }, Promise.resolve()).then(function () {
            return { ok: done, failed: failed, errors: errors };
        });
    }

    function openDryRunPreview(item) {
        var old = document.querySelector('.humantone-dryrun-modal');
        if (old) old.remove();

        var originalText = item.originalReadableContent || item.originalPreview || '';
        var rewrittenText = item.rewrittenReadableContent || item.rewrittenPreview || '';
        var originalHtml = item.originalContent || '';
        var rewrittenHtml = item.rewrittenContent || '';
        var originalVisual = item.originalPreviewHtml || '';
        var rewrittenVisual = item.rewrittenPreviewHtml || '';

        var overlay = document.createElement('div');
        overlay.className = 'humantone-dryrun-modal';
        overlay.innerHTML = '<div class="humantone-dryrun-dialog" role="dialog" aria-modal="true" aria-label="Dry run -esikatselu">' +
            '<button type="button" class="button-link humantone-dryrun-close" aria-label="Sulje">×</button>' +
            '<h2>Esikatsele ehdotus</h2>' +
            '<p><strong>' + escapeHtml(item.title || '') + '</strong></p>' +
            (formatWarnings(item) ? '<div class="notice notice-warning inline"><p><strong>Varoitukset</strong><br>' + escapeHtml(formatWarnings(item)).replace(/\n/g, '<br>') + '</p></div>' : '') +
            '<p class="humantone-sync-scroll-control"><label><input type="checkbox" class="humantone-sync-scroll-toggle" checked> Synkronoi vieritys</label></p>' +
            '<h3>Luettava tekstiversio</h3>' +
            '<div class="humantone-dryrun-columns humantone-dryrun-readable">' +
            '<section><h4>Alkuperäinen</h4><pre class="humantone-sync-scroll-pane"></pre></section>' +
            '<section><h4>Sanasepän ehdotus</h4><pre class="humantone-sync-scroll-pane"></pre></section>' +
            '</div>' +
            '<details class="humantone-dryrun-details" open><summary>Visuaalinen esikatselu</summary>' +
            '<div class="humantone-dryrun-columns humantone-dryrun-visual">' +
            '<section><h4>Alkuperäinen</h4><div class="humantone-formatted-preview humantone-dryrun-html-preview humantone-sync-scroll-pane"></div></section>' +
            '<section><h4>Sanasepän ehdotus</h4><div class="humantone-formatted-preview humantone-dryrun-html-preview humantone-sync-scroll-pane"></div></section>' +
            '</div>' +
            '</details>' +
            '<details class="humantone-dryrun-details"><summary>Näytä HTML-koodi</summary>' +
            '<div class="humantone-dryrun-columns humantone-dryrun-code">' +
            '<section><h4>Alkuperäinen HTML</h4><textarea class="humantone-sync-scroll-pane" readonly></textarea></section>' +
            '<section><h4>Sanasepän ehdotus HTML</h4><textarea class="humantone-sync-scroll-pane" readonly></textarea></section>' +
            '</div>' +
            '</details>' +
            '<p class="humantone-dryrun-actions"><button type="button" class="button button-primary humantone-dryrun-accept">Hyväksy ehdotus alkuperäisen päälle</button> <a class="button" target="_blank" rel="noopener">Avaa alkuperäinen</a> <button type="button" class="button humantone-dryrun-close2">Sulje</button></p>' +
            '</div>';
        var pres = overlay.querySelectorAll('.humantone-dryrun-readable pre');
        pres[0].textContent = originalText;
        pres[1].textContent = rewrittenText;
        var previews = overlay.querySelectorAll('.humantone-dryrun-html-preview');
        previews[0].innerHTML = originalVisual || '<p class="humantone-preview-empty">Esikatselua ei ole saatavilla.</p>';
        previews[1].innerHTML = rewrittenVisual || '<p class="humantone-preview-empty">Esikatselua ei ole saatavilla.</p>';
        var textareas = overlay.querySelectorAll('.humantone-dryrun-code textarea');
        textareas[0].value = originalHtml;
        textareas[1].value = rewrittenHtml;
        var openLink = overlay.querySelector('a.button');
        if (item.editLink) openLink.href = item.editLink; else openLink.style.display = 'none';
        function close() { overlay.remove(); }
        overlay.querySelector('.humantone-dryrun-close').addEventListener('click', close);
        overlay.querySelector('.humantone-dryrun-close2').addEventListener('click', close);
        overlay.addEventListener('click', function (event) { if (event.target === overlay) close(); });
        overlay.querySelector('.humantone-dryrun-accept').addEventListener('click', function () {
            acceptDryRunSuggestion(item, overlay);
        });
        document.body.appendChild(overlay);
        setupSyncedScroll(overlay);
    }

    function acceptDryRunSuggestion(item, overlay) {
        if (!item || !item.sourceId || !item.rewrittenContent) {
            setMessage('Ehdotettua sisältöä ei löytynyt raportista. Aja dry run uudelleen.', 'error');
            return;
        }
        if (!window.confirm('Korvataanko alkuperäisen artikkelin/sivun sisältö tällä Sanasepän ehdotuksella? Otsikko, artikkelikuva, kategoriat ja metatiedot säilytetään.')) {
            return;
        }
        var btn = overlay ? overlay.querySelector('.humantone-dryrun-accept') : null;
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Tallennetaan…';
        }
        acceptDryRunItems([item]).then(function (result) {
            if (result.failed) {
                setMessage(result.errors.join('\n') || 'Tallennus epäonnistui.', 'error');
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = 'Hyväksy ehdotus alkuperäisen päälle';
                }
                return;
            }
            setMessage('Ehdotus tallennettiin alkuperäisen päälle.', 'success');
            if (overlay) overlay.remove();
        });
    }

    function renderBulkResults(data) {
        var box = byId('humantone-bulk-results');
        if (!box) return;
        box.innerHTML = '';

        var title = document.createElement('h3');
        title.textContent = data.message || 'Joukkokäsittely valmis.';
        box.appendChild(title);

        var summary = data.summary || null;
        if (!summary) {
            var ok = 0, failed = 0, skipped = 0;
            (data.results || []).forEach(function (item) {
                if (item.success) { ok++; }
                else if (item.skipped) { skipped++; }
                else { failed++; }
            });
            summary = { ok: ok, skipped: skipped, failed: failed, total: (data.results || []).length };
        }
        var summaryTable = document.createElement('table');
        summaryTable.className = 'widefat humantone-bulk-summary-table';
        summaryTable.innerHTML = '<thead><tr><th>Tila</th><th>Määrä</th></tr></thead><tbody>' +
            '<tr><td>Onnistui</td><td>' + (summary.ok || 0) + '</td></tr>' +
            '<tr><td>Ohitettu</td><td>' + (summary.skipped || 0) + '</td></tr>' +
            '<tr><td>Virheitä</td><td>' + (summary.failed || 0) + '</td></tr>' +
            '<tr><td>Yhteensä</td><td>' + (summary.total || 0) + '</td></tr>' +
            '</tbody>';
        box.appendChild(summaryTable);

        var problemItems = (data.results || []).filter(function (item) { return !item.success || item.skipped || (item.warningCount && parseInt(item.warningCount, 10) > 0); });
        if (problemItems.length) {
            var details = document.createElement('details');
            details.className = 'humantone-bulk-problem-details';
            details.open = true;
            var summaryEl = document.createElement('summary');
            summaryEl.textContent = 'Virheet, ohitukset ja varoitukset (' + problemItems.length + ')';
            details.appendChild(summaryEl);
            var list = document.createElement('ul');
            problemItems.forEach(function (item) {
                var li = document.createElement('li');
                var prefix = item.success ? '⚠️ ' : (item.skipped ? '⚠️ ' : '❌ ');
                var warningText = formatWarnings(item);
                li.textContent = prefix + '"' + (item.title || item.sourceId) + '" – ' + (item.message || warningText || (item.warningCount ? ('Varoituksia: ' + item.warningCount) : 'Tarkista rivi.'));
                list.appendChild(li);
            });
            details.appendChild(list);
            box.appendChild(details);
        }

        var acceptableDryRunItems = getAcceptableDryRunItems(data.results || []);
        if (acceptableDryRunItems.length) {
            var massBox = document.createElement('div');
            massBox.className = 'humantone-dryrun-mass-actions';
            massBox.innerHTML = '<strong>Dry run -hyväksyntä:</strong> ' +
                '<button type="button" class="button humantone-dryrun-select-all">Valitse kaikki</button> ' +
                '<button type="button" class="button humantone-dryrun-select-none">Poista valinnat</button> ' +
                '<button type="button" class="button button-primary humantone-dryrun-accept-selected">Hyväksy valitut</button> ' +
                '<button type="button" class="button button-primary humantone-dryrun-accept-all">Hyväksy kaikki onnistuneet</button> ' +
                '<span class="humantone-dryrun-mass-status"></span>';
            box.appendChild(massBox);
        }

        var table = document.createElement('table');
        table.className = 'widefat striped humantone-bulk-results-table';
        table.innerHTML = '<thead><tr><th class="humantone-dryrun-select-col">Valitse</th><th>Alkuperäinen</th><th>Tulos</th><th>Huomiot</th><th>Toiminnot</th></tr></thead><tbody></tbody>';
        var tbody = table.querySelector('tbody');

        (data.results || []).forEach(function (item) {
            var tr = document.createElement('tr');
            tr.className = item.success ? 'humantone-bulk-success' : 'humantone-bulk-failed';

            var selectCell = document.createElement('td');
            selectCell.className = 'humantone-dryrun-select-col';
            if (item.success && item.saveMode === 'dry_run' && item.changed && item.rewrittenContent) {
                var checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'humantone-dryrun-accept-checkbox';
                checkbox.checked = true;
                selectCell.appendChild(checkbox);
            } else {
                selectCell.textContent = '-';
            }

            var original = document.createElement('td');
            original.textContent = item.title || item.sourceId;

            var result = document.createElement('td');
            result.textContent = item.success ? (item.resultLabel || 'Onnistui') : 'Epäonnistui';

            var notes = document.createElement('td');
            var warningText = formatWarnings(item);
            notes.textContent = item.success ? ((item.saveMode === 'dry_run' ? (item.changed ? 'Muutoksia löytyi. ' : 'Ei muutoksia. ') : '') + (warningText ? warningText : ('Varoituksia: ' + (item.warningCount || 0)))) : (item.message || 'Virhe');

            var actions = document.createElement('td');
            if (item.success && item.saveMode === 'dry_run') {
                var previewBtn = document.createElement('button');
                previewBtn.type = 'button';
                previewBtn.className = 'button button-small';
                previewBtn.textContent = 'Esikatsele ehdotus';
                previewBtn.addEventListener('click', function () { openDryRunPreview(item); });
                actions.appendChild(previewBtn);
                actions.appendChild(document.createTextNode(' '));

                if (item.changed && item.rewrittenContent) {
                    var acceptBtn = document.createElement('button');
                    acceptBtn.type = 'button';
                    acceptBtn.className = 'button button-small button-primary';
                    acceptBtn.textContent = 'Hyväksy tämä';
                    acceptBtn.addEventListener('click', function () { openDryRunPreview(item); });
                    actions.appendChild(acceptBtn);
                    actions.appendChild(document.createTextNode(' '));
                }
                if (item.editLink) {
                    var originalLink = document.createElement('a');
                    originalLink.href = item.editLink;
                    originalLink.target = '_blank';
                    originalLink.rel = 'noopener';
                    originalLink.textContent = 'Avaa alkuperäinen';
                    actions.appendChild(originalLink);
                }
            } else if (item.success && item.editLink) {
                var a = document.createElement('a');
                a.href = item.editLink;
                a.target = '_blank';
                a.rel = 'noopener';
                a.textContent = item.saveMode === 'update_original' ? 'Avaa alkuperäinen' : 'Avaa luonnos';
                actions.appendChild(a);
            } else {
                actions.textContent = '-';
            }

            tr._humantoneDryRunItem = item;
            tr.appendChild(selectCell);
            tr.appendChild(original);
            tr.appendChild(result);
            tr.appendChild(notes);
            tr.appendChild(actions);
            tbody.appendChild(tr);
        });

        box.appendChild(table);

        var massActions = box.querySelector('.humantone-dryrun-mass-actions');
        if (massActions) {
            var status = massActions.querySelector('.humantone-dryrun-mass-status');
            function checkedItems() {
                return Array.prototype.slice.call(tbody.querySelectorAll('.humantone-dryrun-accept-checkbox:checked')).map(function (checkbox) {
                    var row = checkbox.closest('tr');
                    return row ? row._humantoneDryRunItem : null;
                }).filter(Boolean);
            }
            function setSelectedAll(checked) {
                Array.prototype.slice.call(tbody.querySelectorAll('.humantone-dryrun-accept-checkbox')).forEach(function (checkbox) {
                    checkbox.checked = checked;
                });
            }
            function runMassAccept(items, label) {
                items = getAcceptableDryRunItems(items);
                if (!items.length) {
                    setMessage('Valitse vähintään yksi hyväksyttävä dry run -ehdotus.', 'warning');
                    return;
                }
                var confirmText = label + ' (' + items.length + ' kpl)?\n\n' +
                    'Tämä tallentaa valitut Sanasepän ehdotukset alkuperäisten sisältöjen päälle.\n' +
                    'Otsikko, artikkelikuva, kategoriat ja metatiedot säilytetään.\n\n' +
                    'Varmista, että olet esikatsellut tulokset ennen jatkamista.';
                if (!window.confirm(confirmText)) {
                    return;
                }
                Array.prototype.slice.call(massActions.querySelectorAll('button')).forEach(function (button) { button.disabled = true; });
                status.textContent = 'Tallennetaan 0/' + items.length + '…';
                acceptDryRunItems(items, function (done, total) {
                    status.textContent = 'Tallennetaan ' + done + '/' + total + '…';
                }).then(function (result) {
                    status.textContent = 'Valmis: ' + result.ok + ' tallennettu, virheitä ' + result.failed + '.';
                    if (result.failed) {
                        setMessage('Osa tallennuksista epäonnistui:\n' + result.errors.join('\n'), 'error');
                    } else {
                        setMessage('Valitut dry run -ehdotukset tallennettiin alkuperäisten päälle.', 'success');
                    }
                    renderBulkResults(data);
                });
            }
            massActions.querySelector('.humantone-dryrun-select-all').addEventListener('click', function () { setSelectedAll(true); });
            massActions.querySelector('.humantone-dryrun-select-none').addEventListener('click', function () { setSelectedAll(false); });
            massActions.querySelector('.humantone-dryrun-accept-selected').addEventListener('click', function () { runMassAccept(checkedItems(), 'Hyväksytäänkö valitut dry run -ehdotukset'); });
            massActions.querySelector('.humantone-dryrun-accept-all').addEventListener('click', function () { runMassAccept(acceptableDryRunItems, 'Hyväksytäänkö kaikki onnistuneet dry run -ehdotukset'); });
        }
    }

    function updateBulkProgress(done, total, text) {
        var card = byId('humantone-bulk-progress');
        var fill = byId('humantone-bulk-progress-fill');
        var pct = byId('humantone-bulk-progress-percent');
        var progressBar = card ? card.querySelector('.humantone-progress-bar') : null;
        var progressText = byId('humantone-bulk-progress-text');
        var percent = total > 0 ? Math.round((done / total) * 100) : 0;
        percent = Math.max(0, Math.min(100, percent));
        if (card) card.hidden = false;
        if (fill) fill.style.width = percent + '%';
        if (pct) pct.textContent = percent + '%';
        if (progressBar) progressBar.setAttribute('aria-valuenow', String(percent));
        if (progressText) progressText.textContent = text || ('Käsitelty ' + done + '/' + total + ' sisältöä.');
    }

    function finishBulkProgress(success, message) {
        var card = byId('humantone-bulk-progress');
        if (!card) return;
        card.classList.toggle('has-error', !success);
        updateBulkProgress(1, 1, message || (success ? 'Joukkokäsittely valmis.' : 'Joukkokäsittely keskeytyi.'));
        if (success) {
            window.setTimeout(function () {
                card.hidden = true;
                card.classList.remove('has-error');
                updateBulkProgress(0, 1, '');
            }, 1800);
        }
    }

    function runBulkRewrite() {
        var ids = selectedBulkIds();
        var mode = byId('humantone-bulk-mode');
        var contentPurpose = byId('humantone-bulk-content-purpose');
        var profile = byId('humantone-bulk-profile');
        var cleanAiPhrases = byId('humantone-bulk-clean-ai-phrases');
        var saveMode = byId('humantone-bulk-save-mode');
        var button = byId('humantone-bulk-run');
        var results = byId('humantone-bulk-results');

        if (!ids.length) {
            setMessage(HumanToneTool.messages.bulkSelect, 'error');
            return;
        }
        var bulkMaxItems = HumanToneTool.limits && HumanToneTool.limits.bulk_max_items ? parseInt(HumanToneTool.limits.bulk_max_items, 10) : 10;
        if (ids.length > bulkMaxItems) {
            setMessage(HumanToneTool.messages.bulkLimit, 'error');
            return;
        }

        if (results) results.innerHTML = '';
        setMessage(HumanToneTool.messages.bulkWorking, 'success');
        setButtonLoading(button, HumanToneTool.messages.bulkWorking, true, 'Suorita joukkokäsittely');
        updateBulkProgress(0, ids.length, 'Aloitetaan joukkokäsittely. Sisällöt käsitellään yksi kerrallaan, jotta eteneminen näkyy ja pitkät ajot eivät vaikuta jumittuneilta.');

        var aggregate = {
            success: true,
            created: 0,
            updated: 0,
            dryRun: 0,
            saveMode: saveMode ? saveMode.value : 'draft_copy',
            total: ids.length,
            results: [],
            ok: 0,
            failed: 0,
            skipped: 0
        };

        function runOne(index) {
            if (index >= ids.length) {
                aggregate.message = aggregate.saveMode === 'dry_run'
                    ? ('Dry run valmis. Tarkistettuja sisältöjä: ' + aggregate.dryRun + '/' + aggregate.total + '. Mitään ei tallennettu.')
                    : (aggregate.saveMode === 'update_original'
                        ? ('Joukkokäsittely valmis. Päivitettyjä alkuperäisiä: ' + aggregate.updated + '/' + aggregate.total + '.')
                        : ('Joukkokäsittely valmis. Luotuja luonnoksia: ' + aggregate.created + '/' + aggregate.total + '.'));
                aggregate.summary = {
                    ok: aggregate.ok,
                    skipped: aggregate.skipped,
                    failed: aggregate.failed,
                    total: aggregate.total
                };
                renderBulkResults(aggregate);
                loadHistory();
                setMessage(aggregate.message, 'success');
                finishBulkProgress(true, aggregate.message);
                return Promise.resolve();
            }

            updateBulkProgress(index, ids.length, 'Käsitellään sisältöä ' + (index + 1) + '/' + ids.length + '...');
            return apiFetch(HumanToneTool.bulkUrl, {
                method: 'POST',
                body: JSON.stringify({
                    post_ids: [ids[index]],
                    mode: mode ? mode.value : 'natural',
                    content_type: contentPurpose ? contentPurpose.value : 'general',
                    profile_id: profile ? profile.value : '',
                    save_mode: aggregate.saveMode,
                    clean_ai_phrases: cleanAiPhrases ? cleanAiPhrases.checked : false
                })
            })
                .then(function (data) {
                    aggregate.created += data && data.created ? parseInt(data.created, 10) : 0;
                    aggregate.updated += data && data.updated ? parseInt(data.updated, 10) : 0;
                    aggregate.dryRun += data && data.dryRun ? parseInt(data.dryRun, 10) : 0;
                    if (data && data.results && data.results.length) {
                        data.results.forEach(function (item) {
                            if (item.success) { aggregate.ok++; }
                            else if (item.skipped) { aggregate.skipped++; }
                            else { aggregate.failed++; }
                        });
                        aggregate.results = aggregate.results.concat(data.results);
                    }
                    updateBulkProgress(index + 1, ids.length, 'Valmis ' + (index + 1) + '/' + ids.length + '.');
                })
                .catch(function (error) {
                    aggregate.failed++;
                    aggregate.results.push({
                        sourceId: ids[index],
                        success: false,
                        title: ids[index],
                        message: error && error.message ? error.message : HumanToneTool.messages.failed
                    });
                    updateBulkProgress(index + 1, ids.length, 'Valmis ' + (index + 1) + '/' + ids.length + ', mukana virheitä.');
                })
                .then(function () {
                    return runOne(index + 1);
                });
        }

        runOne(0)
            .catch(function (error) {
                finishBulkProgress(false, error && error.message ? error.message : HumanToneTool.messages.failed);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.bulkWorking, false, 'Suorita joukkokäsittely');
            });
    }


    function getBulkPayload(ids) {
        var mode = byId('humantone-bulk-mode');
        var contentPurpose = byId('humantone-bulk-content-purpose');
        var profile = byId('humantone-bulk-profile');
        var cleanAiPhrases = byId('humantone-bulk-clean-ai-phrases');
        var saveMode = byId('humantone-bulk-save-mode');
        return {
            post_ids: ids,
            mode: mode ? mode.value : 'natural',
            content_type: contentPurpose ? contentPurpose.value : 'general',
            profile_id: profile ? profile.value : '',
            save_mode: saveMode ? saveMode.value : 'draft_copy',
            clean_ai_phrases: cleanAiPhrases ? cleanAiPhrases.checked : false
        };
    }

    function renderBulkJobStatus(job) {
        var box = byId('humantone-bulk-job-status');
        if (!box || !job) return;
        if (job.found === false) {
            box.innerHTML = '<div class="notice notice-info inline"><p>Viimeisintä tausta-ajoa ei löytynyt.</p></div>';
            return;
        }
        var total = parseInt(job.total || 0, 10);
        var done = parseInt(job.done || 0, 10);
        var percent = total ? Math.round((done / total) * 100) : 0;
        var summary = job.summary || { ok: 0, skipped: 0, failed: 0, total: total };
        var statusLabel = job.status === 'done' ? 'Valmis' : (job.status === 'failed' ? 'Epäonnistui' : (job.status === 'queued' ? 'Jonossa' : 'Käynnissä'));
        var html = '<div class="humantone-card-inner humantone-bulk-job-card">' +
            '<h3>Viimeisin tausta-ajo</h3>' +
            '<p><strong>Tila:</strong> ' + escapeHtml(statusLabel) + ' — ' + done + '/' + total + ' (' + percent + '%)</p>' +
            '<p><strong>Aloitettu:</strong> ' + escapeHtml(job.started_at || job.created_at || '-') + ' <strong>Päivitetty:</strong> ' + escapeHtml(job.updated_at || '-') + '</p>' +
            '<div class="humantone-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + percent + '"><div class="humantone-progress-fill" style="width:' + percent + '%"></div></div>' +
            '<table class="widefat humantone-bulk-summary-table"><tbody>' +
            '<tr><th>Onnistui</th><td>' + parseInt(summary.ok || 0, 10) + '</td></tr>' +
            '<tr><th>Ohitettu</th><td>' + parseInt(summary.skipped || 0, 10) + '</td></tr>' +
            '<tr><th>Virheitä</th><td>' + parseInt(summary.failed || 0, 10) + '</td></tr>' +
            '</tbody></table>' +
            '<p>' + escapeHtml(job.message || '') + '</p>' +
            '</div>';
        box.innerHTML = html;
        if (job.results && job.results.length) {
            renderBulkResults({
                success: true,
                saveMode: job.args && job.args.save_mode ? job.args.save_mode : 'draft_copy',
                total: total,
                summary: summary,
                results: job.results,
                message: job.message || ''
            });
        }
    }

    function pollBulkJob(jobId) {
        if (!jobId || !HumanToneTool.bulkJobUrl) return;
        return apiFetch(HumanToneTool.bulkJobUrl + '/' + encodeURIComponent(jobId), { method: 'GET' })
            .then(function (job) {
                renderBulkJobStatus(job);
                updateBulkProgress(job.done || 0, job.total || 1, job.message || 'Tausta-ajo käynnissä...');
                if (job.status === 'done' || job.status === 'failed') {
                    finishBulkProgress(job.status === 'done', job.message || 'Tausta-ajo valmis.');
                    loadHistory();
                    return job;
                }
                window.setTimeout(function () { pollBulkJob(jobId); }, 3000);
                return job;
            })
            .catch(function (error) {
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
                finishBulkProgress(false, error && error.message ? error.message : HumanToneTool.messages.failed);
            });
    }

    function startBulkBackgroundJob() {
        var ids = selectedBulkIds();
        var button = byId('humantone-bulk-queue-run');
        var results = byId('humantone-bulk-results');
        if (!ids.length) {
            setMessage(HumanToneTool.messages.bulkSelect, 'error');
            return;
        }
        var bulkMaxItems = HumanToneTool.limits && HumanToneTool.limits.bulk_max_items ? parseInt(HumanToneTool.limits.bulk_max_items, 10) : 10;
        if (ids.length > bulkMaxItems) {
            setMessage(HumanToneTool.messages.bulkLimit, 'error');
            return;
        }
        if (results) results.innerHTML = '';
        setButtonLoading(button, 'Käynnistetään tausta-ajo...', true, 'Käynnistä tausta-ajona');
        setMessage('Tausta-ajo käynnistetään. WordPress käsittelee sisällöt jonossa WP-Cronin kautta.', 'success');
        updateBulkProgress(0, ids.length, 'Tausta-ajo jonossa...');
        return apiFetch(HumanToneTool.bulkJobUrl, {
            method: 'POST',
            body: JSON.stringify(getBulkPayload(ids))
        })
            .then(function (job) {
                renderBulkJobStatus(job);
                pollBulkJob(job.id);
            })
            .catch(function (error) {
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
                finishBulkProgress(false, error && error.message ? error.message : HumanToneTool.messages.failed);
            })
            .finally(function () {
                setButtonLoading(button, 'Käynnistetään tausta-ajo...', false, 'Käynnistä tausta-ajona');
            });
    }

    function loadLastBulkJob() {
        if (!HumanToneTool.bulkLastJobUrl) return;
        return apiFetch(HumanToneTool.bulkLastJobUrl, { method: 'GET' })
            .then(function (job) {
                renderBulkJobStatus(job);
                if (job && job.id && job.status !== 'done' && job.status !== 'failed') {
                    pollBulkJob(job.id);
                }
            })
            .catch(function () {});
    }


    function selectedProductId() {
        var select = byId('humantone-product-select');
        return select ? select.value : '';
    }

    function setProductSaveButtonsEnabled(enabled) {
        var draft = byId('humantone-save-product-draft');
        var update = byId('humantone-update-product');
        if (draft) draft.disabled = !enabled;
        if (update) update.disabled = !enabled;
    }

    function resetProductPreview() {
        var output = byId('humantone-product-output');
        var warnings = byId('humantone-product-warnings');
        var diff = byId('humantone-product-diff');
        if (output) output.value = '';
        if (warnings) warnings.innerHTML = '';
        if (diff) { diff.innerHTML = ''; diff.hidden = true; }
        setProductSaveButtonsEnabled(false);
        lastPreviewProductId = '';
    }

    function renderProductFacts(data) {
        var factsBox = byId('humantone-product-facts');
        var warningBox = byId('humantone-product-warnings');
        if (!factsBox || !data) return;
        factsBox.innerHTML = '';
        if (warningBox) warningBox.innerHTML = '';

        var meta = data.productMeta || (currentProductData ? currentProductData.productMeta : {}) || {};
        var facts = data.originalFacts || (data.field === 'short' && currentProductData ? currentProductData.shortFacts : (currentProductData ? currentProductData.longFacts : null));
        var html = '<h3>Tuotetietojen tarkistus</h3>';
        html += '<table class="widefat striped humantone-stats"><tbody>';
        html += '<tr><td>SKU</td><td>' + (meta.SKU || '-') + '</td></tr>';
        html += '<tr><td>Hinta</td><td>' + (meta.Hinta || '-') + '</td></tr>';
        html += '<tr><td>Mitat</td><td>' + [meta.Pituus, meta.Leveys, meta.Korkeus].filter(Boolean).join(' × ') + '</td></tr>';
        html += '<tr><td>Paino</td><td>' + (meta.Paino || '-') + '</td></tr>';
        if (facts) {
            html += '<tr><td>Kuvauksesta tunnistetut numeroarvot</td><td>' + ((facts.numbers || []).join(', ') || '-') + '</td></tr>';
            html += '<tr><td>Kuvauksesta tunnistetut koodit</td><td>' + ((facts.codes || []).join(', ') || '-') + '</td></tr>';
        }
        html += '</tbody></table>';
        factsBox.innerHTML = html;

        if (warningBox && data.warnings) {
            if (data.warnings.length) {
                var title = document.createElement('strong');
                title.textContent = 'Tarkista tuotetiedot ennen tallennusta:';
                var list = document.createElement('ul');
                data.warnings.forEach(function (warning) {
                    var li = document.createElement('li');
                    li.textContent = warning.message + (warning.missing && warning.missing.length ? ' Puuttuvat: ' + warning.missing.join(', ') : '');
                    list.appendChild(li);
                });
                warningBox.appendChild(title);
                warningBox.appendChild(list);
                warningBox.classList.add('has-warnings');
            warningBox.classList.toggle('has-blocking-warnings', data.safeToSave === false);
            } else {
                warningBox.textContent = 'Tuotetietojen tarkistus ei löytänyt puuttuvia numeroita, koodeja tai tunnisteita.';
                warningBox.classList.remove('has-warnings');
            warningBox.classList.remove('has-blocking-warnings');
            }
        }
    }

    function loadProducts() {
        var search = byId('humantone-product-search');
        var select = byId('humantone-product-select');
        var button = byId('humantone-load-products');
        if (!select || !HumanToneTool.productsUrl) return;

        select.innerHTML = '';
        var loading = document.createElement('option');
        loading.value = '';
        loading.textContent = HumanToneTool.messages.loadingProducts || 'Haetaan tuotteita...';
        select.appendChild(loading);
        setButtonLoading(button, HumanToneTool.messages.loadingProducts || 'Haetaan tuotteita...', true, 'Hae tuotteet');
        resetProductPreview();
        currentProductData = null;

        var original = byId('humantone-product-original');
        if (original) original.value = '';

        var url = new URL(HumanToneTool.productsUrl);
        if (search && search.value.trim()) {
            url.searchParams.set('search', search.value.trim());
        }

        apiFetch(url.toString(), { method: 'GET' })
            .then(function (data) {
                select.innerHTML = '';
                if (data.active === false) {
                    var inactive = document.createElement('option');
                    inactive.value = '';
                    inactive.textContent = data.message || 'WooCommerce ei ole käytössä.';
                    select.appendChild(inactive);
                    setMessage(data.message || 'WooCommerce ei ole käytössä.', 'error');
                    return;
                }
                if (!data.products || !data.products.length) {
                    var empty = document.createElement('option');
                    empty.value = '';
                    empty.textContent = 'Tuotteita ei löytynyt.';
                    select.appendChild(empty);
                    return;
                }
                data.products.forEach(function (product) {
                    var option = document.createElement('option');
                    option.value = product.id;
                    var suffix = [];
                    if (product.sku) suffix.push('SKU ' + product.sku);
                    if (product.price) suffix.push(product.price);
                    suffix.push(product.status);
                    option.textContent = product.title + ' [' + suffix.join(', ') + ']';
                    select.appendChild(option);
                });
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.loadingProducts || 'Haetaan tuotteita...', false, 'Hae tuotteet');
            });
    }

    function getSelectedProductContent(data) {
        var field = byId('humantone-product-field');
        return field && field.value === 'short' ? (data.shortDescription || '') : (data.longDescription || '');
    }

    function loadProductContent() {
        var productId = selectedProductId();
        var original = byId('humantone-product-original');
        var editLink = byId('humantone-product-edit-link');
        var button = byId('humantone-load-product-content');
        if (!productId) {
            setMessage(HumanToneTool.messages.selectProduct || 'Valitse ensin tuote.', 'error');
            return;
        }
        resetProductPreview();
        if (original) original.value = '';
        if (editLink) editLink.style.display = 'none';
        setButtonLoading(button, HumanToneTool.messages.loadingPost, true, 'Näytä tuotekuvaus');

        apiFetch(HumanToneTool.productUrlBase + productId, { method: 'GET' })
            .then(function (data) {
                currentProductData = data;
                if (original) original.value = getSelectedProductContent(data);
                if (editLink && data.editLink) {
                    editLink.href = data.editLink;
                    editLink.style.display = 'inline-block';
                }
                renderProductFacts(data);
                setMessage('Tuotekuvaus haettu. Tarkista alkuperäinen teksti ja valitse muokkaustapa.', 'success');
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.loadingPost, false, 'Näytä tuotekuvaus');
            });
    }

    function rewriteProduct() {
        var productId = selectedProductId();
        var field = byId('humantone-product-field');
        var mode = byId('humantone-product-mode');
        var profile = byId('humantone-product-profile');
        var cleanAiPhrases = byId('humantone-product-clean-ai-phrases');
        var output = byId('humantone-product-output');
        var button = byId('humantone-rewrite-product');
        if (!productId) {
            setMessage(HumanToneTool.messages.selectProduct || 'Valitse ensin tuote.', 'error');
            return;
        }
        resetProductPreview();
        setMessage(HumanToneTool.messages.workingProduct || 'Muokataan tuotekuvausta...', 'success');
        setButtonLoading(button, HumanToneTool.messages.workingProduct || 'Muokataan tuotekuvausta...', true, 'Muokkaa tuotekuvaus esikatseluun');

        apiFetch(HumanToneTool.productUrlBase + productId + '/rewrite', {
            method: 'POST',
            body: JSON.stringify({
                field: field ? field.value : 'long',
                mode: mode ? mode.value : 'natural',
                profile_id: profile ? profile.value : '',
                save_mode: saveMode ? saveMode.value : 'draft_copy',
                clean_ai_phrases: cleanAiPhrases ? cleanAiPhrases.checked : false
            })
        })
            .then(function (data) {
                if (output) output.value = data.content || '';
                lastPreviewProductId = productId;
                setProductSaveButtonsEnabled(!!data.content);
                renderProductFacts(data);
                renderDiffPanel('humantone-product-diff', (byId('humantone-product-original') || {}).value || '', data.content || '', 'Tuotekuvauksen muutosnäkymä');
                setMessage(data.message || 'Tuotekuvauksen esikatselu valmis. Tarkista myös muutosnäkymä ennen tallennusta.', 'success');
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.workingProduct || 'Muokataan tuotekuvausta...', false, 'Muokkaa tuotekuvaus esikatseluun');
            });
    }

    function saveProductVersion(saveMode) {
        var productId = lastPreviewProductId || selectedProductId();
        var field = byId('humantone-product-field');
        var output = byId('humantone-product-output');
        var editLink = byId('humantone-product-edit-link');
        var button = saveMode === 'update_original' ? byId('humantone-update-product') : byId('humantone-save-product-draft');
        var normalText = saveMode === 'update_original' ? 'Päivitä alkuperäinen tuote' : 'Tallenna uutena luonnostuotteena';
        if (!productId) {
            setMessage(HumanToneTool.messages.selectProduct || 'Valitse ensin tuote.', 'error');
            return;
        }
        if (!output || !output.value.trim()) {
            setMessage('Muokattu tuotekuvaus puuttuu. Luo ensin esikatselu.', 'error');
            return;
        }
        if (saveMode === 'update_original' && !window.confirm(HumanToneTool.messages.confirmProductUpdate || 'Päivitetäänkö alkuperäinen tuote?')) {
            return;
        }
        setButtonLoading(button, HumanToneTool.messages.savingProduct || 'Tallennetaan tuotekuvausta...', true, normalText);
        apiFetch(HumanToneTool.productUrlBase + productId + HumanToneTool.productSaveUrlSuffix, {
            method: 'POST',
            body: JSON.stringify({
                field: field ? field.value : 'long',
                content: output.value,
                save_mode: saveMode
            })
        })
            .then(function (data) {
                if (editLink && data.editLink) {
                    editLink.href = data.editLink;
                    editLink.style.display = 'inline-block';
                }
                renderProductFacts(data);
                setMessage(data.message || 'Tuotekuvaus tallennettu.', 'success');
                loadHistory();
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            })
            .finally(function () {
                setButtonLoading(button, HumanToneTool.messages.savingProduct || 'Tallennetaan tuotekuvausta...', false, normalText);
            });
    }


    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char];
        });
    }

    function diffTokenize(text) {
        return String(text || '').match(/\s+|[^\s]+/g) || [];
    }

    function isWordToken(token) {
        return /\S/.test(token || '');
    }

    function wordCountFromTokens(tokens) {
        return tokens.filter(isWordToken).length;
    }

    function simpleMiddleDiff(a, b) {
        var start = 0;
        while (start < a.length && start < b.length && a[start] === b[start]) start++;

        var endA = a.length - 1;
        var endB = b.length - 1;
        while (endA >= start && endB >= start && a[endA] === b[endB]) {
            endA--;
            endB--;
        }

        var ops = [];
        if (start > 0) ops.push({ type: 'same', tokens: a.slice(0, start) });
        if (endA >= start) ops.push({ type: 'del', tokens: a.slice(start, endA + 1) });
        if (endB >= start) ops.push({ type: 'ins', tokens: b.slice(start, endB + 1) });
        if (endA + 1 < a.length) ops.push({ type: 'same', tokens: a.slice(endA + 1) });
        return ops;
    }

    function lcsDiff(a, b) {
        var n = a.length;
        var m = b.length;
        if (!n && !m) return [];
        if (n * m > 500000) return simpleMiddleDiff(a, b);

        var previous = new Array(m + 1).fill(0);
        var table = [];
        var i, j, current;
        for (i = 1; i <= n; i++) {
            current = new Array(m + 1).fill(0);
            for (j = 1; j <= m; j++) {
                current[j] = a[i - 1] === b[j - 1] ? previous[j - 1] + 1 : Math.max(previous[j], current[j - 1]);
            }
            table.push(current);
            previous = current;
        }

        var ops = [];
        function push(type, token) {
            var last = ops[ops.length - 1];
            if (last && last.type === type) {
                last.tokens.unshift(token);
            } else {
                ops.push({ type: type, tokens: [token] });
            }
        }

        i = n;
        j = m;
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && a[i - 1] === b[j - 1]) {
                push('same', a[i - 1]);
                i--;
                j--;
            } else if (j > 0 && (i === 0 || (table[i - 1] ? table[i - 1][j] : 0) < (table[i] ? table[i][j - 1] : 0))) {
                push('ins', b[j - 1]);
                j--;
            } else if (i > 0) {
                push('del', a[i - 1]);
                i--;
            }
        }
        return ops.reverse();
    }


    function renderLockedPostPreview(containerId, data) {
        var box = byId(containerId);
        if (!box) return;
        var license = HumanToneTool.license || {};
        var expired = license.status === 'expired';
        var lockedTitle = expired ? 'Lisenssi on vanhentunut.' : 'Pro vaaditaan koko sisältöön.';
        var lockedMessage = expired ? (license.proUnavailableMessage || license.message || 'Lisenssi on vanhentunut. Pro-toiminnot ovat pois käytöstä, mutta asetukset ja aiemmat sisällöt säilyvät.') : 'Koko muokattu sisältö, luonnokseksi tallennus ja alkuperäisen korvaaminen avautuvat Pro-lisenssillä.';
        box.innerHTML = '<h3>Demoesikatselu</h3>' +
            '<p class="description">Free-tilassa koko muokattua artikkelia tai sivua ei näytetä kopioitavana sisältönä. Näet kuitenkin muutosyhteenvedon ja lyhyen tekstinäytteen laadun arviointia varten.</p>' +
            '<div class="humantone-pro-notice humantone-card-inner' + (expired ? ' humantone-license-expired-notice' : '') + '"><strong>' + escapeHtml(lockedTitle) + '</strong> ' + escapeHtml(lockedMessage) + '</div>';
        box.hidden = false;
    }

    function renderDiffPanel(containerId, originalText, rewrittenText, title) {
        var box = byId(containerId);
        if (!box) return;
        box.innerHTML = '';
        box.hidden = true;

        originalText = String(originalText || '');
        rewrittenText = String(rewrittenText || '');
        if (!originalText && !rewrittenText) return;

        var originalTokens = diffTokenize(originalText);
        var rewrittenTokens = diffTokenize(rewrittenText);
        var ops = lcsDiff(originalTokens, rewrittenTokens);
        var added = 0;
        var removed = 0;
        var unchanged = 0;

        var html = '';
        ops.forEach(function (op) {
            var text = op.tokens.join('');
            var count = wordCountFromTokens(op.tokens);
            if (op.type === 'ins') {
                added += count;
                html += '<ins>' + escapeHtml(text) + '</ins>';
            } else if (op.type === 'del') {
                removed += count;
                html += '<del>' + escapeHtml(text) + '</del>';
            } else {
                unchanged += count;
                html += escapeHtml(text);
            }
        });

        var total = added + removed + unchanged;
        var changedPercent = total ? Math.round(((added + removed) / total) * 100) : 0;
        box.innerHTML = '<h3>' + escapeHtml(title || 'Muutosnäkymä') + '</h3>' +
            '<p class="description">Vihreä = lisätty, punainen = poistettu. Näkymä auttaa tarkistamaan tekstimuutokset ennen tallennusta.</p>' +
            '<div class="humantone-diff-summary">Lisättyjä sanoja: <strong>' + added + '</strong> &nbsp; Poistettuja sanoja: <strong>' + removed + '</strong> &nbsp; Arvioitu muutos: <strong>' + changedPercent + '%</strong></div>' +
            '<pre class="humantone-diff-output">' + html + '</pre>';
        box.hidden = false;
    }

    function renderHistory(data) {
        var box = byId('humantone-history-list');
        if (!box) return;
        var items = Array.isArray(data) ? data : ((data && data.items) || []);
        var total = data && typeof data.total !== 'undefined' ? parseInt(data.total, 10) : items.length;
        var storedTotal = data && typeof data.storedTotal !== 'undefined' ? parseInt(data.storedTotal, 10) : total;
        var maxItems = data && data.maxItems ? parseInt(data.maxItems, 10) : 100;
        var limit = data && data.limit ? parseInt(data.limit, 10) : items.length;

        if (!items.length) {
            box.innerHTML = '<p>Historiaa ei vielä ole. Kun tallennat WP Sanasepän muokkauksia, ne näkyvät tässä.</p>';
            return;
        }

        var html = '<div class="humantone-history-summary">Näytetään <strong>' + escapeHtml(items.length) + '</strong> / ' + escapeHtml(total || items.length) + ' näkyvää historiariviä. Tallennettuja rivejä yhteensä: <strong>' + escapeHtml(storedTotal || total || items.length) + '</strong>. Enimmäismäärä: ' + escapeHtml(maxItems) + '.</div>';
        if (total > limit) {
            html += '<p class="description">Valitse yläpuolelta suurempi määrä, jos haluat nähdä lisää historiarivejä.</p>';
        }
        html += '<table class="widefat striped humantone-history-table"><thead><tr>' +
            '<th>Aika</th><th>Sisältö</th><th>Tyyppi</th><th>Toiminto</th><th>Profiili</th><th>Varoitukset</th><th>Linkit</th><th>Palautus</th>' +
            '</tr></thead><tbody>';

        items.forEach(function (item) {
            var links = [];
            if (item.sourceEditLink) links.push('<a href="' + escapeHtml(item.sourceEditLink) + '" target="_blank" rel="noopener">Alkuperäinen</a>');
            if (item.targetEditLink) links.push('<a href="' + escapeHtml(item.targetEditLink) + '" target="_blank" rel="noopener">Muokattu</a>');
            var restore = item.canRestore ? '<button class="button humantone-restore-history" data-history-id="' + escapeHtml(item.id) + '">Palauta</button>' : (item.restoredAt ? 'Palautettu ' + escapeHtml(item.restoredAt) : 'Ei palautettavissa');
            html += '<tr>' +
                '<td>' + escapeHtml(item.createdAt) + '<br><small>' + escapeHtml(item.userName) + '</small></td>' +
                '<td><strong>' + escapeHtml(item.sourceTitle || '(ei otsikkoa)') + '</strong><br><small>ID ' + escapeHtml(item.sourcePostId) + '</small></td>' +
                '<td>' + escapeHtml(item.postType) + (item.field && item.field !== 'content' ? '<br><small>' + escapeHtml(item.field) + '</small>' : '') + '</td>' +
                '<td>' + escapeHtml(item.saveMode || item.action) + '<br><small>' + escapeHtml(item.mode || '') + '</small></td>' +
                '<td>' + escapeHtml(item.profileName || '-') + '</td>' +
                '<td>' + escapeHtml(item.warningCount || 0) + '</td>' +
                '<td>' + links.join('<br>') + '</td>' +
                '<td>' + restore + '</td>' +
                '</tr>';
        });
        html += '</tbody></table>';
        box.innerHTML = html;

        Array.prototype.forEach.call(box.querySelectorAll('.humantone-restore-history'), function (button) {
            button.addEventListener('click', function () {
                restoreHistoryItem(button.getAttribute('data-history-id'));
            });
        });
    }

    function getHistoryLimit() {
        var select = byId('humantone-history-limit');
        var limit = select ? parseInt(select.value, 10) : 25;
        return limit && limit > 0 ? limit : 25;
    }

    function loadHistory() {
        var box = byId('humantone-history-list');
        if (box) box.innerHTML = '<p>' + (HumanToneTool.messages.loadingHistory || 'Haetaan historiaa...') + '</p>';
        apiFetch(HumanToneTool.historyUrl + '?limit=' + encodeURIComponent(getHistoryLimit()), { method: 'GET' })
            .then(function (data) {
                renderHistory(data || {});
            })
            .catch(function (error) {
                if (box) box.innerHTML = '<p class="humantone-error">' + escapeHtml(error && error.message ? error.message : HumanToneTool.messages.failed) + '</p>';
            });
    }

    function pruneHistory() {
        if (!window.confirm(HumanToneTool.messages.confirmPruneHistory || 'Poistetaanko vanhat historiarivit?')) {
            return;
        }
        apiFetch(HumanToneTool.historyUrl + HumanToneTool.historyPruneSuffix, {
            method: 'POST',
            data: { keep: 50 }
        })
            .then(function (data) {
                setMessage(data.message || 'Historia siivottiin.', 'success');
                loadHistory();
            })
            .catch(function (error) {
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            });
    }

    function restoreHistoryItem(id) {
        if (!id) return;
        if (!window.confirm(HumanToneTool.messages.confirmRestore || 'Palautetaanko alkuperäinen versio?')) {
            return;
        }
        apiFetch(HumanToneTool.historyUrl + '/' + encodeURIComponent(id) + HumanToneTool.historyRestoreSuffix, { method: 'POST' })
            .then(function (data) {
                setMessage(data.message || 'Alkuperäinen versio palautettiin.', 'success');
                loadHistory();
            })
            .catch(function (error) {
                finishPostProgress(false);
                setMessage(error && error.message ? error.message : HumanToneTool.messages.failed, 'error');
            });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var rewrite = byId('humantone-rewrite');
        var copy = byId('humantone-copy');
        var clear = byId('humantone-clear');
        var loadPostsButton = byId('humantone-load-posts');
        var loadPostContentButton = byId('humantone-load-post-content');
        var rewritePostButton = byId('humantone-rewrite-post');
        var saveDraftButton = byId('humantone-save-draft');
        var updateOriginalButton = byId('humantone-update-original');
        var postType = byId('humantone-post-type');
        var postSearch = byId('humantone-post-search');
        var postSelect = byId('humantone-post-select');
        var bulkLoadButton = byId('humantone-bulk-load');
        var bulkRunButton = byId('humantone-bulk-run');
        var bulkQueueRunButton = byId('humantone-bulk-queue-run');
        var bulkLastJobButton = byId('humantone-bulk-last-job');
        var bulkSelectAllButton = byId('humantone-bulk-select-all');
        var bulkClearButton = byId('humantone-bulk-clear-selection');
        var bulkPostType = byId('humantone-bulk-post-type');
        var bulkSearch = byId('humantone-bulk-search');
        var productLoadButton = byId('humantone-load-products');
        var productLoadContentButton = byId('humantone-load-product-content');
        var productRewriteButton = byId('humantone-rewrite-product');
        var productSaveDraftButton = byId('humantone-save-product-draft');
        var productUpdateButton = byId('humantone-update-product');
        var productSelect = byId('humantone-product-select');
        var productField = byId('humantone-product-field');
        var productSearch = byId('humantone-product-search');
        var historyLoadButton = byId('humantone-load-history');
        var historyLimitSelect = byId('humantone-history-limit');
        var historyPruneButton = byId('humantone-prune-history');

        if (HumanToneTool.apiStatus && HumanToneTool.apiStatus.blocking) {
            setMessage(HumanToneTool.apiStatus.message || 'OpenAI-yhteys ei toimi. Tarkista API ja malli -asetukset.', 'error');
            ['humantone-rewrite', 'humantone-rewrite-post', 'humantone-bulk-run', 'humantone-rewrite-product'].forEach(function (id) {
                var button = byId(id);
                if (button) {
                    button.disabled = true;
                    button.title = HumanToneTool.apiStatus.message || 'OpenAI-yhteys ei toimi.';
                }
            });
        }

        setupSyncedScroll(document);

        if (rewrite) rewrite.addEventListener('click', rewriteText);
        if (copy) copy.addEventListener('click', copyOutput);
        if (clear) clear.addEventListener('click', clearFields);
        if (loadPostsButton) loadPostsButton.addEventListener('click', loadPosts);
        if (loadPostContentButton) loadPostContentButton.addEventListener('click', loadPostContent);
        resetPostProgress();
        resetPostRewriteButton();
        if (rewritePostButton) {
            rewritePostButton.type = 'button';
            rewritePostButton.disabled = false;
            rewritePostButton.removeAttribute('disabled');
            rewritePostButton.addEventListener('click', rewritePost);
        }
        if (saveDraftButton) saveDraftButton.addEventListener('click', function () { savePostVersion('draft_copy'); });
        if (updateOriginalButton) updateOriginalButton.addEventListener('click', function () { savePostVersion('update_original'); });
        if (postType) postType.addEventListener('change', loadPosts);
        if (postSelect) postSelect.addEventListener('change', function () {
            resetComparePanel();
            var original = byId('humantone-post-original');
            var output = byId('humantone-post-output');
            if (original) original.value = '';
            if (output) output.value = '';
            lastPreviewPostContent = '';
        });
        if (postSearch) {
            postSearch.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    loadPosts();
                }
            });
        }
        if (bulkLoadButton) bulkLoadButton.addEventListener('click', loadBulkPosts);
        if (bulkRunButton) bulkRunButton.addEventListener('click', runBulkRewrite);
        if (bulkQueueRunButton) bulkQueueRunButton.addEventListener('click', startBulkBackgroundJob);
        if (bulkLastJobButton) bulkLastJobButton.addEventListener('click', loadLastBulkJob);
        if (bulkSelectAllButton) bulkSelectAllButton.addEventListener('click', function () { selectVisibleBulkPosts(true); });
        if (bulkClearButton) bulkClearButton.addEventListener('click', function () { selectVisibleBulkPosts(false); });
        if (bulkPostType) bulkPostType.addEventListener('change', loadBulkPosts);
        if (bulkSearch) {
            bulkSearch.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    loadBulkPosts();
                }
            });
        }

        if (historyLoadButton) historyLoadButton.addEventListener('click', loadHistory);
        if (historyLimitSelect) historyLimitSelect.addEventListener('change', loadHistory);
        if (historyPruneButton) historyPruneButton.addEventListener('click', pruneHistory);
        if (productLoadButton) productLoadButton.addEventListener('click', loadProducts);
        if (productLoadContentButton) productLoadContentButton.addEventListener('click', loadProductContent);
        if (productRewriteButton) productRewriteButton.addEventListener('click', rewriteProduct);
        if (productSaveDraftButton) productSaveDraftButton.addEventListener('click', function () { saveProductVersion('draft_copy'); });
        if (productUpdateButton) productUpdateButton.addEventListener('click', function () { saveProductVersion('update_original'); });
        if (productSelect) productSelect.addEventListener('change', function () { currentProductData = null; resetProductPreview(); var original = byId('humantone-product-original'); if (original) original.value = ''; });
        if (productField) productField.addEventListener('change', function () { resetProductPreview(); var original = byId('humantone-product-original'); if (original && currentProductData) original.value = getSelectedProductContent(currentProductData); renderProductFacts(currentProductData); });
        if (productSearch) {
            productSearch.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    loadProducts();
                }
            });
        }

        populateProfileSelect('humantone-profile');
        populateProfileSelect('humantone-post-profile');
        populateProfileSelect('humantone-bulk-profile');
        populateProfileSelect('humantone-product-profile');
        loadHistory();
        loadBulkPosts();
        loadPosts();
    });
})();

// WP Sanaseppä 0.15.0: admin tool tabs
(function () {
    function activateToolTab(tab) {
        document.querySelectorAll('[data-humantone-tool-tab]').forEach(function (button) {
            var isActive = button.getAttribute('data-humantone-tool-tab') === tab;
            button.classList.toggle('nav-tab-active', isActive);
            button.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
        document.querySelectorAll('[data-humantone-tool-panel]').forEach(function (panel) {
            var isActive = panel.getAttribute('data-humantone-tool-panel') === tab;
            panel.hidden = !isActive;
            panel.classList.toggle('humantone-tool-panel-active', isActive);
        });
        try {
            window.localStorage.setItem('humantone_active_tool_tab', tab);
        } catch (e) {}
    }

    document.addEventListener('DOMContentLoaded', function () {
        var buttons = document.querySelectorAll('[data-humantone-tool-tab]');
        if (!buttons.length) {
            return;
        }
        buttons.forEach(function (button) {
            button.addEventListener('click', function () {
                activateToolTab(button.getAttribute('data-humantone-tool-tab'));
            });
        });
        var stored = '';
        try {
            stored = window.localStorage.getItem('humantone_active_tool_tab') || '';
        } catch (e) {}
        var urlTab = '';
        try {
            urlTab = new URLSearchParams(window.location.search).get('tool_tab') || '';
        } catch (e) {}
        activateToolTab(urlTab || stored || 'single');
    });
}());
