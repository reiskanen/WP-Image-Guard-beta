(function (wp) {
    if (!wp || !wp.plugins || !wp.editPost || !wp.element || !wp.components || !wp.apiFetch) {
        return;
    }

    var el = wp.element.createElement;
    var useState = wp.element.useState;
    var registerPlugin = wp.plugins.registerPlugin;
    var PluginSidebar = wp.editPost.PluginSidebar;
    var PluginSidebarMoreMenuItem = wp.editPost.PluginSidebarMoreMenuItem;
    var PanelBody = wp.components.PanelBody;
    var TextareaControl = wp.components.TextareaControl;
    var SelectControl = wp.components.SelectControl;
    var Button = wp.components.Button;
    var Notice = wp.components.Notice;
    var Spinner = wp.components.Spinner;

    function HumanToneSidebar() {
        var _useState = useState('');
        var inputText = _useState[0];
        var setInputText = _useState[1];

        var _useState2 = useState('natural');
        var mode = _useState2[0];
        var setMode = _useState2[1];

        var _useState3 = useState('general');
        var contentPurpose = _useState3[0];
        var setContentPurpose = _useState3[1];

        var _useState8 = useState((window.HumanToneEditor && window.HumanToneEditor.defaultProfile) || '');
        var profileId = _useState8[0];
        var setProfileId = _useState8[1];

        var _useState6 = useState(true);
        var cleanAiPhrases = _useState6[0];
        var setCleanAiPhrases = _useState6[1];

        var _useState7 = useState('');
        var outputText = _useState7[0];
        var setOutputText = _useState7[1];

        var _useState4 = useState(false);
        var isLoading = _useState4[0];
        var setIsLoading = _useState4[1];

        var _useState5 = useState('');
        var error = _useState5[0];
        var setError = _useState5[1];

        function rewriteText() {
            setError('');
            setOutputText('');

            if (!inputText.trim()) {
                setError('Lisää ensin muokattava teksti.');
                return;
            }

            setIsLoading(true);

            wp.apiFetch({
                path: '/humantone/v1/rewrite',
                method: 'POST',
                data: {
                    text: inputText,
                    mode: mode,
                    content_type: contentPurpose,
                    clean_ai_phrases: cleanAiPhrases,
                    profile_id: profileId
                }
            }).then(function (response) {
                setOutputText(response.text || '');
            }).catch(function (err) {
                var message = err && err.message ? err.message : 'Tekstin muokkaus epäonnistui.';
                setError(message);
            }).finally(function () {
                setIsLoading(false);
            });
        }

        function copyOutput() {
            if (!outputText) {
                return;
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(outputText);
            }
        }

        var profileOptions = [];
        if (window.HumanToneEditor && window.HumanToneEditor.profiles && window.HumanToneEditor.profiles.length) {
            profileOptions = window.HumanToneEditor.profiles.map(function (profile) {
                return { label: profile.name, value: profile.id };
            });
        } else {
            profileOptions = [{ label: 'Oletusprofiili', value: '' }];
        }

        var apiStatus = (window.HumanToneEditor && window.HumanToneEditor.apiStatus) || {};
        var apiBlocking = !!apiStatus.blocking;

        return el(
            wp.element.Fragment,
            {},
            el(PluginSidebarMoreMenuItem, { target: 'humantone-sidebar' }, 'WP Sanaseppä'),
            el(
                PluginSidebar,
                {
                    name: 'humantone-sidebar',
                    title: 'WP Sanaseppä',
                    icon: 'edit'
                },
                el(
                    PanelBody,
                    { title: 'Brändiääni-avustaja', initialOpen: true },
                    apiBlocking ? el(Notice, { status: 'error', isDismissible: false }, apiStatus.message || 'OpenAI-yhteys ei toimi. Tarkista WP Sanasepän API ja malli -asetukset.') : null,
                    el('p', { className: 'humantone-help' }, 'Liitä tähän teksti, jonka haluat muokata luonnollisemmaksi tai brändin ääneen sopivaksi.'),
                    error ? el(Notice, { status: 'error', isDismissible: true, onRemove: function () { setError(''); } }, error) : null,
                    el(TextareaControl, {
                        label: 'Muokattava teksti',
                        value: inputText,
                        rows: 8,
                        onChange: setInputText
                    }),
                    el(SelectControl, {
                        label: 'Muokkaustapa',
                        value: mode,
                        options: [
                            { label: 'Luonnollisempi', value: 'natural' },
                            { label: 'Selkeämpi', value: 'clearer' },
                            { label: 'Kielenhuolto', value: 'proofread' },
                            { label: 'Lyhyempi', value: 'shorter' },
                            { label: 'Yksinkertaisempi', value: 'simplify' },
                            { label: 'Asiantuntevampi', value: 'expert' },
                            { label: 'Myyvempi', value: 'sales' },
                            { label: 'Rennompi', value: 'more_casual' },
                            { label: 'Muodollisempi', value: 'more_formal' },
                            { label: 'Lämpimämpi', value: 'warmer' },
                            { label: 'Parempi aloitus', value: 'stronger_intro' },
                            { label: 'Parempi toimintakehotus', value: 'better_cta' },
                            { label: 'Parempi rytmi ja siirtymät', value: 'paragraph_flow' },
                            { label: 'Muuta luetteloksi', value: 'bullets' },
                            { label: 'Poista AI-sävy', value: 'remove_ai_tone' },
                            { label: 'Korjaa otsikoiden kirjainkoko', value: 'fix_heading_case' }
                        ],
                        onChange: setMode
                    }),
                    el(SelectControl, {
                        label: 'Sisällön käyttötarkoitus',
                        value: contentPurpose,
                        options: [
                            { label: 'Yleinen sisältö', value: 'general' },
                            { label: 'Blogiartikkeli', value: 'blog' },
                            { label: 'SEO-artikkeli', value: 'seo' },
                            { label: 'Laskeutumissivu', value: 'landing_page' },
                            { label: 'Tuotekuvaus', value: 'product' },
                            { label: 'Tietosivu', value: 'info_page' },
                            { label: 'Uutinen', value: 'news' },
                            { label: 'Asiantuntijateksti', value: 'expert' }
                        ],
                        onChange: setContentPurpose
                    }),
                    el(SelectControl, {
                        label: 'Brändiprofiili',
                        value: profileId,
                        options: profileOptions,
                        onChange: setProfileId
                    }),
                    el(wp.components.CheckboxControl, {
                        label: 'Siivoa AI-fraasit',
                        checked: cleanAiPhrases,
                        onChange: setCleanAiPhrases
                    }),
                    el(Button, {
                        variant: 'primary',
                        onClick: rewriteText,
                        disabled: isLoading || apiBlocking
                    }, apiBlocking ? 'API-yhteys ei toimi' : (isLoading ? 'Muokataan...' : 'Muokkaa teksti')),
                    isLoading ? el('div', { className: 'humantone-spinner' }, el(Spinner)) : null,
                    outputText ? el(TextareaControl, {
                        label: 'Ehdotus',
                        value: outputText,
                        rows: 10,
                        onChange: setOutputText
                    }) : null,
                    outputText ? el(Button, {
                        variant: 'secondary',
                        onClick: copyOutput
                    }, 'Kopioi ehdotus') : null
                )
            )
        );
    }

    registerPlugin('humantone', {
        render: HumanToneSidebar
    });
})(window.wp);
